import { Sparkles, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ReactNode } from "react";

export function AIInsightCard({
  title = "AI Insights",
  children,
  onRegenerate,
}: {
  title?: string;
  children: ReactNode;
  onRegenerate?: () => void;
}) {
  return (
    <div className="ai-border relative rounded-xl bg-card p-5 shadow-[var(--shadow-card)]">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="grid size-7 place-items-center rounded-full bg-primary-surface text-primary">
            <Sparkles className="size-4" strokeWidth={2} />
          </span>
          <h3 className="text-foreground">{title}</h3>
        </div>
        {onRegenerate ? (
          <Button
            variant="ghost"
            size="sm"
            onClick={onRegenerate}
            className="h-8 text-primary hover:text-primary-dark"
          >
            <RefreshCw className="size-3.5" /> Regenerate
          </Button>
        ) : null}
      </div>
      <div className="text-sm leading-relaxed">{children}</div>
    </div>
  );
}

export function AIInsightBullet({
  severity = "Insight",
  children,
  delay = 0,
}: {
  severity?: "Opportunity" | "Risk" | "Alert" | "Insight";
  children: ReactNode;
  delay?: number;
}) {
  const badge =
    severity === "Risk"
      ? "bg-[oklch(0.96_0.09_85)] text-[oklch(0.4_0.15_65)]"
      : severity === "Alert"
        ? "bg-[oklch(0.94_0.05_25)] text-[oklch(0.4_0.2_25)]"
        : "bg-primary-surface text-[oklch(0.35_0.08_195)]";
  return (
    <div className="fade-in-up flex gap-2 py-2" style={{ animationDelay: `${delay}ms` }}>
      <span
        className={`h-fit shrink-0 rounded-full px-2 py-0.5 text-[11px] font-semibold ${badge}`}
      >
        {severity}
      </span>
      <span className="text-foreground/90">{children}</span>
    </div>
  );
}