import { useSuspenseQuery } from "@tanstack/react-query";
import { currentUserQuery } from "@/lib/operator360/queries";
import { PageHeader } from "./PageHeader";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function ProfileView() {
  const { data: user } = useSuspenseQuery(currentUserQuery);
  if (!user) return null;
  const initials = user.full_name.split(" ").map((s) => s[0]).slice(0, 2).join("").toUpperCase();
  return (
    <div>
      <PageHeader title="Profile" description="Your Operator360 account details." />
      <Card className="p-6">
        <div className="flex items-center gap-4">
          <Avatar className="size-16">
            <AvatarFallback className="bg-primary text-lg text-primary-foreground">{initials}</AvatarFallback>
          </Avatar>
          <div>
            <h2>{user.full_name}</h2>
            <p className="text-sm text-muted-foreground">{user.email}</p>
            <span className="mt-1 inline-block rounded-full bg-primary-surface px-2 py-0.5 text-xs font-semibold text-primary">{user.role}</span>
          </div>
        </div>
      </Card>
    </div>
  );
}