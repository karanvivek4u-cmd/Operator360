import { Card } from "@/components/ui/card";
import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export function KpiCard({
  label,
  value,
  icon: Icon,
  trend,
  className,
}: {
  label: string;
  value: string | number;
  icon?: LucideIcon;
  trend?: { value: string; direction: "up" | "down" | "flat" };
  className?: string;
}) {
  return (
    <Card
      className={cn(
        "relative overflow-hidden border-border p-5 transition-shadow hover:shadow-[var(--shadow-lift)] fade-in-up",
        className
      )}
    >
      <div className="absolute left-0 top-0 h-full w-1 bg-primary" />
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[13px] font-medium text-muted-foreground">{label}</p>
          <p className="mt-2 text-[32px] font-bold leading-none text-foreground tabular-nums">
            {value}
          </p>
          {trend ? (
            <p
              className={cn(
                "mt-2 text-xs font-medium",
                trend.direction === "up" && "text-success",
                trend.direction === "down" && "text-destructive",
                trend.direction === "flat" && "text-muted-foreground"
              )}
            >
              {trend.value}
            </p>
          ) : null}
        </div>
        {Icon ? (
          <div className="grid size-10 place-items-center rounded-lg bg-primary-surface text-primary">
            <Icon className="size-5" strokeWidth={1.75} />
          </div>
        ) : null}
      </div>
    </Card>
  );
}