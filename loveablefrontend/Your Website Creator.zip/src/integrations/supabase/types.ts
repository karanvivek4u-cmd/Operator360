export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      benefits: {
        Row: {
          benefit_id: string
          benefit_name: string
          coverage_amount: number | null
          created_at: string | null
          end_date: string | null
          operator_id: string
          start_date: string | null
          status: Database["public"]["Enums"]["active_status"]
          updated_at: string | null
        }
        Insert: {
          benefit_id?: string
          benefit_name: string
          coverage_amount?: number | null
          created_at?: string | null
          end_date?: string | null
          operator_id: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["active_status"]
          updated_at?: string | null
        }
        Update: {
          benefit_id?: string
          benefit_name?: string
          coverage_amount?: number | null
          created_at?: string | null
          end_date?: string | null
          operator_id?: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["active_status"]
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "benefits_operator_id_fkey"
            columns: ["operator_id"]
            isOneToOne: false
            referencedRelation: "operators"
            referencedColumns: ["operator_id"]
          },
        ]
      }
      customers: {
        Row: {
          address: string | null
          category: Database["public"]["Enums"]["customer_category"]
          city: string | null
          company_name: string
          contact_person: string
          created_at: string | null
          customer_code: string
          customer_id: string
          email: string
          gst_number: string | null
          phone: string | null
          pincode: string | null
          state: string | null
          status: Database["public"]["Enums"]["active_status"]
          updated_at: string | null
        }
        Insert: {
          address?: string | null
          category?: Database["public"]["Enums"]["customer_category"]
          city?: string | null
          company_name: string
          contact_person: string
          created_at?: string | null
          customer_code: string
          customer_id?: string
          email: string
          gst_number?: string | null
          phone?: string | null
          pincode?: string | null
          state?: string | null
          status?: Database["public"]["Enums"]["active_status"]
          updated_at?: string | null
        }
        Update: {
          address?: string | null
          category?: Database["public"]["Enums"]["customer_category"]
          city?: string | null
          company_name?: string
          contact_person?: string
          created_at?: string | null
          customer_code?: string
          customer_id?: string
          email?: string
          gst_number?: string | null
          phone?: string | null
          pincode?: string | null
          state?: string | null
          status?: Database["public"]["Enums"]["active_status"]
          updated_at?: string | null
        }
        Relationships: []
      }
      loyalty_wallet: {
        Row: {
          created_at: string | null
          customer_id: string
          status: Database["public"]["Enums"]["active_status"]
          updated_at: string | null
          wallet_amount: number | null
          wallet_id: string
        }
        Insert: {
          created_at?: string | null
          customer_id: string
          status?: Database["public"]["Enums"]["active_status"]
          updated_at?: string | null
          wallet_amount?: number | null
          wallet_id?: string
        }
        Update: {
          created_at?: string | null
          customer_id?: string
          status?: Database["public"]["Enums"]["active_status"]
          updated_at?: string | null
          wallet_amount?: number | null
          wallet_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "loyalty_wallet_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: true
            referencedRelation: "customers"
            referencedColumns: ["customer_id"]
          },
        ]
      }
      machines: {
        Row: {
          created_at: string | null
          customer_id: string
          engine_number: string | null
          machine_id: string
          model_number: string | null
          purchase_date: string | null
          remarks: string | null
          serial_number: string
          status: Database["public"]["Enums"]["machine_status"]
          updated_at: string | null
          warranty_end_date: string | null
        }
        Insert: {
          created_at?: string | null
          customer_id: string
          engine_number?: string | null
          machine_id?: string
          model_number?: string | null
          purchase_date?: string | null
          remarks?: string | null
          serial_number: string
          status?: Database["public"]["Enums"]["machine_status"]
          updated_at?: string | null
          warranty_end_date?: string | null
        }
        Update: {
          created_at?: string | null
          customer_id?: string
          engine_number?: string | null
          machine_id?: string
          model_number?: string | null
          purchase_date?: string | null
          remarks?: string | null
          serial_number?: string
          status?: Database["public"]["Enums"]["machine_status"]
          updated_at?: string | null
          warranty_end_date?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "machines_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["customer_id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string | null
          is_read: boolean | null
          link: string | null
          message: string
          notification_id: string
          notification_type: string | null
          sent_email: boolean | null
          sent_sms: boolean | null
          title: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          is_read?: boolean | null
          link?: string | null
          message: string
          notification_id?: string
          notification_type?: string | null
          sent_email?: boolean | null
          sent_sms?: boolean | null
          title: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          is_read?: boolean | null
          link?: string | null
          message?: string
          notification_id?: string
          notification_type?: string | null
          sent_email?: boolean | null
          sent_sms?: boolean | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["user_id"]
          },
        ]
      }
      operator_assignments: {
        Row: {
          assignment_end_date: string | null
          assignment_id: string
          assignment_reason: string | null
          assignment_start_date: string
          created_at: string | null
          machine_id: string
          operator_id: string
          remarks: string | null
          status: Database["public"]["Enums"]["assignment_status"]
          updated_at: string | null
        }
        Insert: {
          assignment_end_date?: string | null
          assignment_id?: string
          assignment_reason?: string | null
          assignment_start_date?: string
          created_at?: string | null
          machine_id: string
          operator_id: string
          remarks?: string | null
          status?: Database["public"]["Enums"]["assignment_status"]
          updated_at?: string | null
        }
        Update: {
          assignment_end_date?: string | null
          assignment_id?: string
          assignment_reason?: string | null
          assignment_start_date?: string
          created_at?: string | null
          machine_id?: string
          operator_id?: string
          remarks?: string | null
          status?: Database["public"]["Enums"]["assignment_status"]
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "operator_assignments_machine_id_fkey"
            columns: ["machine_id"]
            isOneToOne: false
            referencedRelation: "machines"
            referencedColumns: ["machine_id"]
          },
          {
            foreignKeyName: "operator_assignments_operator_id_fkey"
            columns: ["operator_id"]
            isOneToOne: false
            referencedRelation: "operators"
            referencedColumns: ["operator_id"]
          },
        ]
      }
      operators: {
        Row: {
          aadhaar_number: string | null
          address: string | null
          created_at: string | null
          customer_id: string
          dob: string | null
          email: string | null
          emergency_contact: string | null
          first_name: string
          gender: string | null
          joining_date: string | null
          last_name: string | null
          mobile: string | null
          operator_code: string
          operator_id: string
          status: Database["public"]["Enums"]["active_status"]
          updated_at: string | null
        }
        Insert: {
          aadhaar_number?: string | null
          address?: string | null
          created_at?: string | null
          customer_id: string
          dob?: string | null
          email?: string | null
          emergency_contact?: string | null
          first_name: string
          gender?: string | null
          joining_date?: string | null
          last_name?: string | null
          mobile?: string | null
          operator_code: string
          operator_id?: string
          status?: Database["public"]["Enums"]["active_status"]
          updated_at?: string | null
        }
        Update: {
          aadhaar_number?: string | null
          address?: string | null
          created_at?: string | null
          customer_id?: string
          dob?: string | null
          email?: string | null
          emergency_contact?: string | null
          first_name?: string
          gender?: string | null
          joining_date?: string | null
          last_name?: string | null
          mobile?: string | null
          operator_code?: string
          operator_id?: string
          status?: Database["public"]["Enums"]["active_status"]
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "operators_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["customer_id"]
          },
        ]
      }
      service_requests: {
        Row: {
          admin_approved_at: string | null
          admin_approved_by: string | null
          admin_status: Database["public"]["Enums"]["request_status"]
          closed_at: string | null
          created_at: string | null
          customer_comments: string | null
          customer_id: string
          insurance_approved_at: string | null
          insurance_approved_by: string | null
          insurance_status: Database["public"]["Enums"]["request_status"]
          machine_id: string
          new_operator_id: string | null
          old_operator_id: string | null
          overall_status: Database["public"]["Enums"]["request_status"]
          rejection_reason: string | null
          request_id: string
          request_number: string
          request_type: string
          requested_by: string
          updated_at: string | null
        }
        Insert: {
          admin_approved_at?: string | null
          admin_approved_by?: string | null
          admin_status?: Database["public"]["Enums"]["request_status"]
          closed_at?: string | null
          created_at?: string | null
          customer_comments?: string | null
          customer_id: string
          insurance_approved_at?: string | null
          insurance_approved_by?: string | null
          insurance_status?: Database["public"]["Enums"]["request_status"]
          machine_id: string
          new_operator_id?: string | null
          old_operator_id?: string | null
          overall_status?: Database["public"]["Enums"]["request_status"]
          rejection_reason?: string | null
          request_id?: string
          request_number: string
          request_type?: string
          requested_by: string
          updated_at?: string | null
        }
        Update: {
          admin_approved_at?: string | null
          admin_approved_by?: string | null
          admin_status?: Database["public"]["Enums"]["request_status"]
          closed_at?: string | null
          created_at?: string | null
          customer_comments?: string | null
          customer_id?: string
          insurance_approved_at?: string | null
          insurance_approved_by?: string | null
          insurance_status?: Database["public"]["Enums"]["request_status"]
          machine_id?: string
          new_operator_id?: string | null
          old_operator_id?: string | null
          overall_status?: Database["public"]["Enums"]["request_status"]
          rejection_reason?: string | null
          request_id?: string
          request_number?: string
          request_type?: string
          requested_by?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "service_requests_admin_approved_by_fkey"
            columns: ["admin_approved_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "service_requests_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["customer_id"]
          },
          {
            foreignKeyName: "service_requests_insurance_approved_by_fkey"
            columns: ["insurance_approved_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "service_requests_machine_id_fkey"
            columns: ["machine_id"]
            isOneToOne: false
            referencedRelation: "machines"
            referencedColumns: ["machine_id"]
          },
          {
            foreignKeyName: "service_requests_new_operator_id_fkey"
            columns: ["new_operator_id"]
            isOneToOne: false
            referencedRelation: "operators"
            referencedColumns: ["operator_id"]
          },
          {
            foreignKeyName: "service_requests_old_operator_id_fkey"
            columns: ["old_operator_id"]
            isOneToOne: false
            referencedRelation: "operators"
            referencedColumns: ["operator_id"]
          },
          {
            foreignKeyName: "service_requests_requested_by_fkey"
            columns: ["requested_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["user_id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      users: {
        Row: {
          auth_user_id: string | null
          created_at: string | null
          customer_id: string | null
          email: string
          full_name: string
          is_active: boolean | null
          last_login: string | null
          operator_id: string | null
          phone: string | null
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string | null
          user_id: string
        }
        Insert: {
          auth_user_id?: string | null
          created_at?: string | null
          customer_id?: string | null
          email: string
          full_name: string
          is_active?: boolean | null
          last_login?: string | null
          operator_id?: string | null
          phone?: string | null
          role: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
          user_id?: string
        }
        Update: {
          auth_user_id?: string | null
          created_at?: string | null
          customer_id?: string | null
          email?: string
          full_name?: string
          is_active?: boolean | null
          last_login?: string | null
          operator_id?: string | null
          phone?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "users_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["customer_id"]
          },
          {
            foreignKeyName: "users_operator_id_fkey"
            columns: ["operator_id"]
            isOneToOne: false
            referencedRelation: "operators"
            referencedColumns: ["operator_id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      current_app_user_id: { Args: never; Returns: string }
      current_customer_id: { Args: never; Returns: string }
      current_operator_id: { Args: never; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      machine_belongs_to_customer: {
        Args: { _customer_id: string; _machine_id: string }
        Returns: boolean
      }
      operator_assigned_to_machine: {
        Args: { _machine_id: string; _operator_id: string }
        Returns: boolean
      }
      operator_belongs_to_customer: {
        Args: { _customer_id: string; _operator_id: string }
        Returns: boolean
      }
    }
    Enums: {
      active_status: "ACTIVE" | "INACTIVE"
      app_role: "ADMIN" | "CUSTOMER" | "INSURANCE" | "OPERATOR"
      assignment_status: "ACTIVE" | "COMPLETED" | "TERMINATED"
      customer_category: "SMALL" | "MEDIUM" | "LARGE" | "ENTERPRISE"
      machine_status: "UNASSIGNED" | "ASSIGNED" | "MAINTENANCE" | "RETIRED"
      request_status: "PENDING" | "APPROVED" | "REJECTED" | "COMPLETED"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      active_status: ["ACTIVE", "INACTIVE"],
      app_role: ["ADMIN", "CUSTOMER", "INSURANCE", "OPERATOR"],
      assignment_status: ["ACTIVE", "COMPLETED", "TERMINATED"],
      customer_category: ["SMALL", "MEDIUM", "LARGE", "ENTERPRISE"],
      machine_status: ["UNASSIGNED", "ASSIGNED", "MAINTENANCE", "RETIRED"],
      request_status: ["PENDING", "APPROVED", "REJECTED", "COMPLETED"],
    },
  },
} as const
