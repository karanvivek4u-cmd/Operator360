import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { machinesListQuery } from "@/lib/operator360/queries";
import { PageHeader } from "@/components/operator360/PageHeader";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { EmptyState } from "@/components/operator360/EmptyState";
import { TableCard, Td, Th, Tr } from "@/components/operator360/DataShell";
import { Truck, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/admin/machines")({
  head: () => ({ meta: [{ title: "Machines · Operator360" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(machinesListQuery),
  component: MachinesPage,
});

function MachinesPage() {
  const { data } = useSuspenseQuery(machinesListQuery);
  const [q, setQ] = useState("");
  const filtered = data.filter((m) =>
    [m.serial_number, m.model_number, (m as any).customers?.company_name].some((v) =>
      (v ?? "").toLowerCase().includes(q.toLowerCase())
    )
  );
  return (
    <div>
      <PageHeader
        title="Machines"
        description="Every machine registered on the platform, across all customers."
        actions={<Button size="sm"><Plus className="size-4" /> Register</Button>}
      />
      {data.length === 0 ? (
        <EmptyState icon={Truck} title="No machines registered" description="Register a machine to begin." />
      ) : (
        <TableCard search={q} onSearch={setQ} placeholder="Search by serial, model, customer…">
          <table className="w-full">
            <thead><tr><Th>Serial</Th><Th>Model</Th><Th>Customer</Th><Th>Warranty</Th><Th>Status</Th></tr></thead>
            <tbody>
              {filtered.map((m) => (
                <Tr key={m.machine_id}>
                  <Td>
                    <Link to="/admin/machines/$id" params={{ id: m.machine_id }} className="font-medium text-primary hover:underline">
                      {m.serial_number}
                    </Link>
                  </Td>
                  <Td>{m.model_number ?? "—"}</Td>
                  <Td className="text-muted-foreground">{(m as any).customers?.company_name ?? "—"}</Td>
                  <Td>{m.warranty_end_date ?? "—"}</Td>
                  <Td><StatusBadge status={m.status} /></Td>
                </Tr>
              ))}
            </tbody>
          </table>
        </TableCard>
      )}
    </div>
  );
}