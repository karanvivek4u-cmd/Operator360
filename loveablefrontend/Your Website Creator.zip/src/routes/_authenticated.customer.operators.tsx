import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { myOperatorsQuery } from "@/lib/operator360/portal-queries";
import { PageHeader } from "@/components/operator360/PageHeader";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { TableCard, Td, Th, Tr } from "@/components/operator360/DataShell";
import { EmptyState } from "@/components/operator360/EmptyState";
import { HardHat, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/customer/operators")({
  head: () => ({ meta: [{ title: "My Operators · Operator360" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(myOperatorsQuery),
  component: () => {
    const { data } = useSuspenseQuery(myOperatorsQuery);
    return (
      <div>
        <PageHeader title="My operators" actions={<Button size="sm"><Plus className="size-4" /> Add operator</Button>} />
        {data.length === 0 ? <EmptyState icon={HardHat} title="No operators yet" /> : (
          <TableCard>
            <table className="w-full"><thead><tr><Th>Code</Th><Th>Name</Th><Th>Mobile</Th><Th>Status</Th></tr></thead>
              <tbody>{data.map((o) => (
                <Tr key={o.operator_id}>
                  <Td><Link to="/customer/operators/$id" params={{ id: o.operator_id }} className="text-primary hover:underline">{o.operator_code}</Link></Td>
                  <Td>{o.first_name} {o.last_name ?? ""}</Td>
                  <Td>{o.mobile ?? "—"}</Td>
                  <Td><StatusBadge status={o.status} /></Td>
                </Tr>
              ))}</tbody></table>
          </TableCard>
        )}
      </div>
    );
  },
});
