import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/operator360/PageHeader";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { Skeleton } from "@/components/ui/skeleton";
import { Wallet, Sparkles } from "lucide-react";
import { Td, Th, Tr } from "@/components/operator360/DataShell";

export const Route = createFileRoute("/_authenticated/admin/customers/$id")({
  head: () => ({ meta: [{ title: "Customer · Operator360" }] }),
  component: CustomerWorkspace,
});

function customerQuery(id: string) {
  return queryOptions({
    queryKey: ["customer", id],
    queryFn: async () => {
      const [customer, machines, operators, requests, wallet] = await Promise.all([
        supabase.from("customers").select("*").eq("customer_id", id).single(),
        supabase.from("machines").select("*").eq("customer_id", id),
        supabase.from("operators").select("*").eq("customer_id", id),
        supabase.from("service_requests").select("*").eq("customer_id", id).order("created_at", { ascending: false }),
        supabase.from("loyalty_wallet").select("*").eq("customer_id", id).maybeSingle(),
      ]);
      return {
        customer: customer.data,
        machines: machines.data ?? [],
        operators: operators.data ?? [],
        requests: requests.data ?? [],
        wallet: wallet.data,
      };
    },
  });
}

function CustomerWorkspace() {
  const { id } = Route.useParams();
  const { data, isLoading } = useQuery(customerQuery(id));

  if (isLoading || !data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }
  const c = data.customer;
  if (!c) {
    return (
      <div className="rounded-xl border border-dashed p-12 text-center text-sm text-muted-foreground">
        Customer not found. <Link to="/admin/customers" className="text-primary hover:underline">Back to customers</Link>
      </div>
    );
  }

  const healthScore = Math.min(100, 60 + data.operators.length * 3 + data.machines.length * 2 - data.requests.filter((r) => r.overall_status === "PENDING").length * 4);

  return (
    <div>
      <PageHeader
        title={c.company_name}
        description={`${c.customer_code} · ${c.city ?? "—"}, ${c.state ?? ""}`}
        actions={
          <div className="flex items-center gap-3">
            <HealthGauge score={healthScore} />
            <StatusBadge status={c.status} />
          </div>
        }
      />

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="machines">Machines ({data.machines.length})</TabsTrigger>
          <TabsTrigger value="operators">Operators ({data.operators.length})</TabsTrigger>
          <TabsTrigger value="requests">Requests ({data.requests.length})</TabsTrigger>
          <TabsTrigger value="loyalty">Loyalty</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="p-5">
              <h3 className="mb-3">Company details</h3>
              <dl className="grid grid-cols-2 gap-3 text-sm">
                <Field label="Contact" value={c.contact_person} />
                <Field label="Email" value={c.email} />
                <Field label="Phone" value={c.phone} />
                <Field label="GST" value={c.gst_number} />
                <Field label="Address" value={c.address} />
                <Field label="Pincode" value={c.pincode} />
              </dl>
            </Card>
            <Card className="p-5">
              <div className="flex items-center gap-2">
                <Sparkles className="size-4 text-primary" />
                <h3>AI summary</h3>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">
                {c.company_name} operates {data.machines.length} machines with {data.operators.length} operators. Recent activity: {data.requests.length} service requests logged. Health score is {healthScore}/100.
              </p>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="machines" className="mt-4">
          <Card className="overflow-hidden">
            <table className="w-full">
              <thead><tr><Th>Serial</Th><Th>Model</Th><Th>Warranty</Th><Th>Status</Th></tr></thead>
              <tbody>
                {data.machines.map((m) => (
                  <Tr key={m.machine_id}>
                    <Td>{m.serial_number}</Td>
                    <Td>{m.model_number ?? "—"}</Td>
                    <Td className="text-muted-foreground">{m.warranty_end_date ?? "—"}</Td>
                    <Td><StatusBadge status={m.status} /></Td>
                  </Tr>
                ))}
              </tbody>
            </table>
          </Card>
        </TabsContent>

        <TabsContent value="operators" className="mt-4">
          <Card className="overflow-hidden">
            <table className="w-full">
              <thead><tr><Th>Code</Th><Th>Name</Th><Th>Mobile</Th><Th>Status</Th></tr></thead>
              <tbody>
                {data.operators.map((o) => (
                  <Tr key={o.operator_id}>
                    <Td>{o.operator_code}</Td>
                    <Td>{o.first_name} {o.last_name ?? ""}</Td>
                    <Td>{o.mobile ?? "—"}</Td>
                    <Td><StatusBadge status={o.status} /></Td>
                  </Tr>
                ))}
              </tbody>
            </table>
          </Card>
        </TabsContent>

        <TabsContent value="requests" className="mt-4">
          <Card className="overflow-hidden">
            <table className="w-full">
              <thead><tr><Th>#</Th><Th>Type</Th><Th>Insurance</Th><Th>Admin</Th><Th>Overall</Th></tr></thead>
              <tbody>
                {data.requests.map((r) => (
                  <Tr key={r.request_id}>
                    <Td>{r.request_number}</Td>
                    <Td>{r.request_type}</Td>
                    <Td><StatusBadge status={r.insurance_status} /></Td>
                    <Td><StatusBadge status={r.admin_status} /></Td>
                    <Td><StatusBadge status={r.overall_status} /></Td>
                  </Tr>
                ))}
              </tbody>
            </table>
          </Card>
        </TabsContent>

        <TabsContent value="loyalty" className="mt-4">
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <Wallet className="size-6 text-primary" />
              <div>
                <div className="text-xs uppercase tracking-wide text-muted-foreground">Loyalty balance</div>
                <div className="text-3xl font-bold tabular-nums">
                  {Number(data.wallet?.wallet_amount ?? 0).toLocaleString()} pts
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string | null | undefined }) {
  return (
    <div>
      <dt className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="mt-0.5 text-sm">{value ?? "—"}</dd>
    </div>
  );
}

function HealthGauge({ score }: { score: number }) {
  const color = score >= 80 ? "text-success" : score >= 60 ? "text-primary" : "text-warning";
  return (
    <div className={`inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold ${color}`}>
      <Sparkles className="size-3.5" /> Health {score}/100
    </div>
  );
}