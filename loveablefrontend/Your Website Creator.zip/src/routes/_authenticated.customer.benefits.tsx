import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { myBenefitsQuery } from "@/lib/operator360/portal-queries";
import { PageHeader } from "@/components/operator360/PageHeader";
import { EmptyState } from "@/components/operator360/EmptyState";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { Shield } from "lucide-react";

export const Route = createFileRoute("/_authenticated/customer/benefits")({
  head: () => ({ meta: [{ title: "Benefits · Operator360" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(myBenefitsQuery),
  component: () => {
    const b = useSuspenseQuery(myBenefitsQuery).data;
    return (
      <div>
        <PageHeader title="Operator benefits" />
        {b.length === 0 ? <EmptyState icon={Shield} title="No benefits enrolled" /> : (
          <div className="grid gap-3 md:grid-cols-2">
            {b.map((x) => (
              <Card key={x.benefit_id} className="p-5">
                <div className="flex items-start justify-between"><h3>{x.benefit_name}</h3><StatusBadge status={x.status} /></div>
                <p className="mt-2 text-2xl font-bold text-primary">₹{Number(x.coverage_amount ?? 0).toLocaleString()}</p>
                <p className="mt-1 text-xs text-muted-foreground">{x.start_date} → {x.end_date ?? "ongoing"}</p>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  },
});
