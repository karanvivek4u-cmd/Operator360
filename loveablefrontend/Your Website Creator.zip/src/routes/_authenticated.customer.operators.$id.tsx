import { createFileRoute } from "@tanstack/react-router";
import { useQuery, queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/operator360/PageHeader";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/customer/operators/$id")({
  head: () => ({ meta: [{ title: "Operator · Operator360" }] }),
  component: () => {
    const { id } = Route.useParams();
    const q = useQuery(queryOptions({
      queryKey: ["cust", "op", id],
      queryFn: async () => (await supabase.from("operators").select("*").eq("operator_id", id).single()).data,
    }));
    const o = q.data;
    if (!o) return null;
    return (
      <div>
        <PageHeader title={`${o.first_name} ${o.last_name ?? ""}`} description={o.operator_code} actions={<StatusBadge status={o.status} />} />
        <Card className="p-5">
          <dl className="grid grid-cols-2 gap-4 text-sm">
            {[["Mobile", o.mobile], ["Email", o.email], ["DOB", o.dob], ["Emergency", o.emergency_contact], ["Address", o.address]].map(([l, v]) => (
              <div key={l as string}><dt className="text-[11px] uppercase tracking-wide text-muted-foreground">{l}</dt><dd className="mt-0.5">{(v as string) ?? "—"}</dd></div>
            ))}
          </dl>
        </Card>
      </div>
    );
  },
});
