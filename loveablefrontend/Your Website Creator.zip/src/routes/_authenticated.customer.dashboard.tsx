import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { PageHeader } from "@/components/operator360/PageHeader";
import { KpiCard } from "@/components/operator360/KpiCard";
import { AIInsightBullet, AIInsightCard } from "@/components/operator360/AIInsightCard";
import { Card } from "@/components/ui/card";
import { myMachinesQuery, myOperatorsQuery, myRequestsQuery, myLoyaltyQuery } from "@/lib/operator360/portal-queries";
import { Truck, HardHat, FileWarning, Wallet } from "lucide-react";
import { StatusBadge } from "@/components/operator360/StatusBadge";

export const Route = createFileRoute("/_authenticated/customer/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard · Operator360" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(myMachinesQuery);
    context.queryClient.ensureQueryData(myOperatorsQuery);
    context.queryClient.ensureQueryData(myRequestsQuery);
    context.queryClient.ensureQueryData(myLoyaltyQuery);
  },
  component: CustomerDash,
});
function CustomerDash() {
  const machines = useSuspenseQuery(myMachinesQuery).data;
  const operators = useSuspenseQuery(myOperatorsQuery).data;
  const requests = useSuspenseQuery(myRequestsQuery).data;
  const wallet = useSuspenseQuery(myLoyaltyQuery).data;
  const pending = requests.filter((r) => r.overall_status === "PENDING");
  return (
    <div>
      <PageHeader title="My workspace" description="Machines, operators, and active workflows." />
      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <KpiCard label="Owned machines" value={machines.length} icon={Truck} />
        <KpiCard label="Active operators" value={operators.filter((o) => o.status === "ACTIVE").length} icon={HardHat} />
        <KpiCard label="Active requests" value={pending.length} icon={FileWarning} />
        <KpiCard label="Loyalty points" value={Number(wallet?.wallet_amount ?? 0).toLocaleString()} icon={Wallet} />
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <h3 className="mb-3">Recent activity</h3>
          {requests.slice(0, 6).length === 0 ? (
            <p className="text-sm text-muted-foreground">No recent workflow activity.</p>
          ) : (
            <ul className="space-y-3 text-sm">
              {requests.slice(0, 6).map((r) => (
                <li key={r.request_id} className="flex items-center justify-between border-b border-border pb-2">
                  <span>{r.request_number} · Machine {(r as any).machines?.serial_number ?? "—"}</span>
                  <StatusBadge status={r.overall_status} />
                </li>
              ))}
            </ul>
          )}
        </Card>
        <AIInsightCard title="AI Workforce Intelligence">
          <AIInsightBullet delay={0}>Operator retention up 12% this quarter.</AIInsightBullet>
          <AIInsightBullet severity="Risk" delay={80}>Machine EX-220 requires a new operator assignment.</AIInsightBullet>
          <AIInsightBullet severity="Opportunity" delay={160}>Enroll operators in the loyalty benefit tier.</AIInsightBullet>
        </AIInsightCard>
      </div>
    </div>
  );
}
