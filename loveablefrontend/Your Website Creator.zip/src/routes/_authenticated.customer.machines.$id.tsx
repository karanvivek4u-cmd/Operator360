import { createFileRoute } from "@tanstack/react-router";
import { useQuery, queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/operator360/PageHeader";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/_authenticated/customer/machines/$id")({
  head: () => ({ meta: [{ title: "Machine · Operator360" }] }),
  component: MDetail,
});
function MDetail() {
  const { id } = Route.useParams();
  const q = useQuery(queryOptions({
    queryKey: ["cust", "machine", id],
    queryFn: async () => {
      const [m, a] = await Promise.all([
        supabase.from("machines").select("*").eq("machine_id", id).single(),
        supabase.from("operator_assignments").select("*, operators(first_name,last_name,operator_code)").eq("machine_id", id).order("assignment_start_date", { ascending: false }),
      ]);
      return { m: m.data, a: a.data ?? [] };
    },
  }));
  if (q.isLoading || !q.data) return <Skeleton className="h-96 w-full" />;
  const m = q.data.m;
  if (!m) return null;
  return (
    <div>
      <PageHeader title={m.serial_number} description={m.model_number ?? ""} actions={<StatusBadge status={m.status} />} />
      <Card className="p-5">
        <h3 className="mb-3">Operator history</h3>
        <div className="space-y-2">
          {q.data.a.map((x) => (
            <div key={x.assignment_id} className="flex items-center justify-between border-b border-border py-2 text-sm">
              <span>{(x as any).operators?.first_name} {(x as any).operators?.last_name}</span>
              <span className="text-xs text-muted-foreground">{x.assignment_start_date} → {x.assignment_end_date ?? "present"}</span>
              <StatusBadge status={x.status} />
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
