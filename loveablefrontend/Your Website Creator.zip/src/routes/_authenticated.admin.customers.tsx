import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { customersListQuery } from "@/lib/operator360/queries";
import { PageHeader } from "@/components/operator360/PageHeader";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { EmptyState } from "@/components/operator360/EmptyState";
import { TableCard, Td, Th, Tr } from "@/components/operator360/DataShell";
import { Users, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/admin/customers")({
  head: () => ({ meta: [{ title: "Customers · Operator360" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(customersListQuery),
  component: CustomersPage,
});

function CustomersPage() {
  const { data } = useSuspenseQuery(customersListQuery);
  const [q, setQ] = useState("");
  const filtered = data.filter((c) =>
    [c.company_name, c.customer_code, c.email, c.city].some((v) =>
      (v ?? "").toLowerCase().includes(q.toLowerCase())
    )
  );

  return (
    <div>
      <PageHeader
        title="Customers"
        description="All companies operating machines on the Operator360 platform."
        actions={
          <Button size="sm">
            <Plus className="size-4" /> Add customer
          </Button>
        }
      />
      {data.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No customers registered yet"
          description="Add a customer to start managing their machines and workforce."
        />
      ) : (
        <TableCard search={q} onSearch={setQ} placeholder="Search customers…">
          <table className="w-full">
            <thead>
              <tr>
                <Th>Code</Th>
                <Th>Company</Th>
                <Th>Contact</Th>
                <Th>Email</Th>
                <Th>City</Th>
                <Th>Category</Th>
                <Th>Status</Th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => (
                <Tr key={c.customer_id}>
                  <Td>
                    <Link to="/admin/customers/$id" params={{ id: c.customer_id }} className="font-medium text-primary hover:underline">
                      {c.customer_code}
                    </Link>
                  </Td>
                  <Td>{c.company_name}</Td>
                  <Td>{c.contact_person}</Td>
                  <Td className="text-muted-foreground">{c.email}</Td>
                  <Td>{c.city ?? "—"}</Td>
                  <Td>
                    <span className="rounded-md bg-muted px-2 py-0.5 text-xs font-medium">
                      {c.category}
                    </span>
                  </Td>
                  <Td><StatusBadge status={c.status} /></Td>
                </Tr>
              ))}
            </tbody>
          </table>
        </TableCard>
      )}
    </div>
  );
}