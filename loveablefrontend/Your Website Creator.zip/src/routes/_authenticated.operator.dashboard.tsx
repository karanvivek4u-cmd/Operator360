import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { PageHeader } from "@/components/operator360/PageHeader";
import { myAssignmentsQuery, myBenefitsQuery } from "@/lib/operator360/portal-queries";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { Wrench, Shield } from "lucide-react";

export const Route = createFileRoute("/_authenticated/operator/dashboard")({
  head: () => ({ meta: [{ title: "My Machine · Operator360" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(myAssignmentsQuery);
    context.queryClient.ensureQueryData(myBenefitsQuery);
  },
  component: () => {
    const a = useSuspenseQuery(myAssignmentsQuery).data;
    const b = useSuspenseQuery(myBenefitsQuery).data;
    const current = a.find((x) => x.status === "ACTIVE");
    return (
      <div>
        <PageHeader title="My machine" description="Your current assignment and benefits." />
        <div className="grid gap-4 md:grid-cols-2">
          <Card className="p-6">
            <div className="flex items-center gap-3"><div className="grid size-12 place-items-center rounded-lg bg-primary-surface text-primary"><Wrench className="size-6" /></div><div><h3>Current machine</h3><p className="text-xs text-muted-foreground">Assigned equipment</p></div></div>
            {current ? (
              <div className="mt-5">
                <div className="text-2xl font-bold">{(current as any).machines?.serial_number ?? "—"}</div>
                <p className="mt-1 text-sm text-muted-foreground">Since {current.assignment_start_date}</p>
                <div className="mt-3"><StatusBadge status={current.status} /></div>
              </div>
            ) : (
              <p className="mt-6 text-sm text-muted-foreground">You are not currently assigned to a machine.</p>
            )}
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3"><div className="grid size-12 place-items-center rounded-lg bg-primary-surface text-primary"><Shield className="size-6" /></div><div><h3>Active benefits</h3></div></div>
            <div className="mt-4 space-y-2 text-sm">
              {b.filter((x) => x.status === "ACTIVE").slice(0, 4).map((x) => (
                <div key={x.benefit_id} className="flex justify-between border-b border-border py-2 last:border-0"><span>{x.benefit_name}</span><span className="tabular-nums text-primary">₹{Number(x.coverage_amount ?? 0).toLocaleString()}</span></div>
              ))}
              {b.length === 0 && <p className="text-muted-foreground">No active benefits.</p>}
            </div>
          </Card>
        </div>
      </div>
    );
  },
});
