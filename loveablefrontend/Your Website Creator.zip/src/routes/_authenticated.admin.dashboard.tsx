import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import {
  adminMetricsQuery,
  serviceRequestsListQuery,
} from "@/lib/operator360/queries";
import { KpiCard } from "@/components/operator360/KpiCard";
import { PageHeader } from "@/components/operator360/PageHeader";
import {
  AIInsightBullet,
  AIInsightCard,
} from "@/components/operator360/AIInsightCard";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { Users, Truck, HardHat, FileWarning } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Link } from "@tanstack/react-router";
import {
  BarChart,
  Bar,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
} from "recharts";

export const Route = createFileRoute("/_authenticated/admin/dashboard")({
  head: () => ({ meta: [{ title: "Admin Dashboard · Operator360" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(adminMetricsQuery);
    context.queryClient.ensureQueryData(serviceRequestsListQuery);
  },
  component: AdminDashboard,
});

function AdminDashboard() {
  const { data: metrics } = useSuspenseQuery(adminMetricsQuery);
  const { data: requests } = useSuspenseQuery(serviceRequestsListQuery);
  const recent = requests.slice(0, 6);

  const chartData = [
    { label: "Assigned", value: Math.max(1, metrics.machines - metrics.pendingRequests) },
    { label: "Pending", value: metrics.pendingRequests },
    { label: "Idle", value: Math.max(0, metrics.machines - metrics.operators) },
  ];
  const colors = ["oklch(0.66 0.11 195)", "oklch(0.68 0.16 65)", "oklch(0.75 0.02 250)"];

  return (
    <div>
      <PageHeader
        title="Command Center"
        description="Fleet, workforce, and workflow health at a glance."
      />

      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <KpiCard label="Customers" value={metrics.customers} icon={Users} trend={{ value: "+8% this month", direction: "up" }} />
        <KpiCard label="Machines" value={metrics.machines} icon={Truck} />
        <KpiCard label="Operators" value={metrics.operators} icon={HardHat} trend={{ value: "Retention +12%", direction: "up" }} />
        <KpiCard label="Pending Requests" value={metrics.pendingRequests} icon={FileWarning} trend={{ value: "Needs review", direction: "flat" }} />
      </div>

      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card className="p-5 fade-in-up" style={{ animationDelay: "80ms" }}>
            <div className="mb-4 flex items-center justify-between">
              <h3>Fleet status distribution</h3>
              <span className="text-xs text-muted-foreground">Live</span>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.92 0.01 250)" vertical={false} />
                  <XAxis dataKey="label" tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: "oklch(0.55 0.02 260)" }} />
                  <YAxis tickLine={false} axisLine={false} tick={{ fontSize: 12, fill: "oklch(0.55 0.02 260)" }} />
                  <Tooltip
                    contentStyle={{
                      borderRadius: 8,
                      border: "1px solid oklch(0.92 0.01 250)",
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                    {chartData.map((_, i) => (
                      <Cell key={i} fill={colors[i]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

        <div className="fade-in-up" style={{ animationDelay: "160ms" }}>
          <AIInsightCard title="AI Copilot" onRegenerate={() => {}}>
            <AIInsightBullet severity="Opportunity" delay={0}>
              Operator retention up 12% quarter-over-quarter — reward top performers.
            </AIInsightBullet>
            <AIInsightBullet severity="Risk" delay={80}>
              Machine EX-220 idle for 6 days. Consider reassignment or maintenance.
            </AIInsightBullet>
            <AIInsightBullet severity="Alert" delay={160}>
              {metrics.pendingRequests} service requests pending admin approval.
            </AIInsightBullet>
          </AIInsightCard>
        </div>
      </div>

      <Card className="mt-4 fade-in-up" style={{ animationDelay: "240ms" }}>
        <div className="flex items-center justify-between border-b border-border p-5">
          <h3>Recent service requests</h3>
          <Link to="/admin/service-requests" className="text-xs font-medium text-primary hover:underline">
            View all →
          </Link>
        </div>
        <div className="divide-y divide-border">
          {recent.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">
              No requests yet.
            </div>
          ) : (
            recent.map((r) => (
              <Link
                to="/admin/service-requests/$id"
                params={{ id: r.request_id }}
                key={r.request_id}
                className="flex items-center justify-between gap-4 px-5 py-3 hover:bg-muted/40"
              >
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">
                    {r.request_number} ·{" "}
                    <span className="text-muted-foreground">
                      {(r as any).customers?.company_name ?? "—"}
                    </span>
                  </div>
                  <div className="mt-0.5 truncate text-xs text-muted-foreground">
                    {r.customer_comments ?? "Operator replacement request"}
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-3">
                  <StatusBadge status={r.overall_status} />
                  <span className="text-xs text-muted-foreground">
                    {r.created_at ? formatDistanceToNow(new Date(r.created_at), { addSuffix: true }) : ""}
                  </span>
                </div>
              </Link>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}