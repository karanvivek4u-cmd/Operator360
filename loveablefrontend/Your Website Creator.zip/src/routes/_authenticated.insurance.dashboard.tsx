import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { insuranceQueueQuery } from "@/lib/operator360/portal-queries";
import { PageHeader } from "@/components/operator360/PageHeader";
import { KpiCard } from "@/components/operator360/KpiCard";
import { AIInsightBullet, AIInsightCard } from "@/components/operator360/AIInsightCard";
import { Clock, CheckCircle2, XCircle } from "lucide-react";

export const Route = createFileRoute("/_authenticated/insurance/dashboard")({
  head: () => ({ meta: [{ title: "Insurance Dashboard · Operator360" }] }),
  loader: ({ context }) => {
    context.queryClient.ensureQueryData(insuranceQueueQuery("PENDING"));
    context.queryClient.ensureQueryData(insuranceQueueQuery("APPROVED"));
    context.queryClient.ensureQueryData(insuranceQueueQuery("REJECTED"));
  },
  component: () => {
    const pending = useSuspenseQuery(insuranceQueueQuery("PENDING")).data;
    const approved = useSuspenseQuery(insuranceQueueQuery("APPROVED")).data;
    const rejected = useSuspenseQuery(insuranceQueueQuery("REJECTED")).data;
    return (
      <div>
        <PageHeader title="Insurance approvals" description="Review and act on operator replacement requests." />
        <div className="grid gap-4 md:grid-cols-3">
          <Link to="/insurance/pending"><KpiCard label="Pending review" value={pending.length} icon={Clock} /></Link>
          <Link to="/insurance/approved"><KpiCard label="Approved" value={approved.length} icon={CheckCircle2} /></Link>
          <Link to="/insurance/rejected"><KpiCard label="Rejected" value={rejected.length} icon={XCircle} /></Link>
        </div>
        <div className="mt-4">
          <AIInsightCard title="AI Advisor">
            <AIInsightBullet delay={0}>{pending.length} request(s) waiting for insurance decision.</AIInsightBullet>
            <AIInsightBullet severity="Opportunity" delay={80}>Approval velocity improved 8% week-over-week.</AIInsightBullet>
          </AIInsightCard>
        </div>
      </div>
    );
  },
});
