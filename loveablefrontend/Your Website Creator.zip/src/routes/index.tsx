import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Truck,
  HardHat,
  Gauge,
  Play,
  Plus,
} from "lucide-react";
import craneHero from "@/assets/crane-hero.png.asset.json";

export const Route = createFileRoute("/")({
  beforeLoad: async () => {
    if (typeof window === "undefined") return;
    const { data } = await supabase.auth.getSession();
    if (data.session) {
      const { data: u } = await supabase
        .from("users")
        .select("role")
        .eq("auth_user_id", data.session.user.id)
        .maybeSingle();
      const role = u?.role ?? "CUSTOMER";
      const home =
        role === "ADMIN"
          ? "/admin/dashboard"
          : role === "INSURANCE"
            ? "/insurance/dashboard"
            : role === "OPERATOR"
              ? "/operator/dashboard"
              : "/customer/dashboard";
      throw redirect({ to: home });
    }
  },
  component: Landing,
});

function Landing() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-[#f4f5f7] text-[#0a1628]">
      {/* Blueprint grid background */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(10,22,40,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(10,22,40,0.06) 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage:
            "radial-gradient(ellipse at 70% 40%, black 40%, transparent 85%)",
        }}
      />
      {/* Giant faded L5 mark */}
      <div
        aria-hidden
        className="pointer-events-none absolute right-[-2rem] top-24 select-none text-[22rem] font-black leading-none tracking-tighter text-[#0a1628]/[0.04]"
        style={{ fontFamily: '"Archivo Black", "Inter", sans-serif' }}
      >
        L5
      </div>

      <header className="relative z-20 border-b border-[#0a1628]/10 bg-transparent">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <div className="flex items-center gap-2">
            <div className="grid size-8 place-items-center rounded-md bg-[#0a1628] font-bold text-white">
              O
            </div>
            <span className="text-sm font-semibold tracking-tight">Operator360</span>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm">
              <Link to="/auth">Sign in</Link>
            </Button>
            <Button asChild size="sm" className="bg-[#0a1628] text-white hover:bg-[#111f38]">
              <Link to="/auth" search={{ mode: "signup" }}>
                Get started
              </Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Right-edge vertical "LIVE OPERATIONS" tab */}
      <div className="pointer-events-none absolute right-0 top-1/2 z-20 hidden -translate-y-1/2 lg:block">
        <div className="flex items-center gap-2 rounded-l-2xl bg-[#0a1628] px-3 py-6 text-white shadow-lg">
          <span className="size-1.5 rounded-full bg-[#22d3c5]" />
          <span className="[writing-mode:vertical-rl] rotate-180 text-[11px] font-semibold uppercase tracking-[0.28em]">
            Live Operations
          </span>
        </div>
      </div>

      <section className="relative z-10 mx-auto max-w-7xl px-6 pb-10 pt-12 md:pt-16">
        <div className="grid gap-6 lg:grid-cols-[minmax(0,0.95fr)_minmax(0,1.45fr)] lg:items-start">
          {/* LEFT: copy */}
          <div className="fade-in-up relative pt-2 lg:pt-10">
            <div className="mb-6 flex items-center gap-3">
              <span className="h-px w-8 bg-[#22d3c5]" />
              <span className="text-[11px] font-semibold uppercase tracking-[0.28em] text-[#22d3c5]">
                AI-Native Workforce OS
              </span>
            </div>
            <h1
              className="text-5xl font-black uppercase leading-[0.95] tracking-tight text-[#0a1628] md:text-6xl lg:text-[5.25rem]"
              style={{ fontFamily: '"Archivo Black", "Inter", sans-serif' }}
            >
              Command<br />center for<br />heavy{" "}
              <span className="text-[#1e5fd6]">equipment</span>
              <br />operators
            </h1>
            <p className="mt-6 max-w-md text-base leading-relaxed text-[#4a5568]">
              Unify machines, operators, assignments, welfare benefits, and
              replacement workflows in one intelligent platform for
              manufacturers, dealers, and insurers.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-5">
              <Button
                asChild
                size="lg"
                className="h-12 gap-2 rounded-md bg-[#0e2a5e] px-6 text-sm font-semibold text-white hover:bg-[#123472]"
              >
                <Link to="/auth">
                  Explore the platform <ArrowRight className="size-4" />
                </Link>
              </Button>
              <button className="group inline-flex items-center gap-3 text-sm font-semibold text-[#0a1628]">
                <span className="grid size-10 place-items-center rounded-full border border-[#0a1628]/25 transition group-hover:bg-[#0a1628] group-hover:text-white">
                  <Play className="size-4 fill-current" />
                </span>
                Watch overview
              </button>
            </div>
          </div>

          {/* RIGHT: crane hero */}
          <div className="relative min-h-[30rem] md:min-h-[36rem] lg:min-h-[42rem]">
            {/* corner plus marks */}
            <Plus className="absolute right-6 top-4 size-4 text-[#0a1628]/30 md:right-14 md:top-8" />
            <Plus className="absolute right-24 top-14 size-3 text-[#0a1628]/25 md:right-44 md:top-20" />
            {/* technical note */}
            <div className="absolute left-[16%] top-10 z-20 hidden max-w-[11rem] md:left-[24%] md:top-14 md:block">
              <div className="mb-2 flex items-center gap-2">
                <span className="h-px w-6 bg-[#0a1628]/60" />
                <span className="h-1 w-1 rounded-full bg-[#0a1628]/60" />
              </div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#0a1628]/70">
                Built for<br />performance.<br />Designed for<br />reliability.
              </p>
              <div
                className="mt-3 h-2 w-16"
                style={{
                  backgroundImage:
                    "repeating-linear-gradient(135deg, #0a1628 0 2px, transparent 2px 6px)",
                }}
              />
            </div>
            {/* faint compass mark */}
            <div
              aria-hidden
              className="pointer-events-none absolute bottom-36 left-[14%] z-10 size-28 rounded-full border border-[#0a1628]/15 md:bottom-44 md:left-[22%]"
            >
              <div className="absolute inset-2 rounded-full border border-[#0a1628]/10" />
              <div className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2 bg-[#0a1628]/10" />
              <div className="absolute top-1/2 h-px w-full -translate-y-1/2 bg-[#0a1628]/10" />
            </div>
            <img
              src={craneHero.url}
              alt="Heavy-lift crawler crane"
              className="absolute bottom-[-1.5rem] right-[-8%] z-10 h-auto w-[115%] max-w-none object-contain drop-shadow-[0_30px_40px_rgba(10,22,40,0.18)] md:bottom-[-2rem] md:right-[-12%] md:w-[120%] lg:bottom-[-2.5rem] lg:right-[-16%] lg:w-[125%]"
            />
          </div>
        </div>

        {/* Bottom stats bar */}
        <div className="mt-12 grid grid-cols-1 gap-0 overflow-hidden rounded-2xl border border-[#0a1628]/10 bg-white/90 shadow-[0_20px_60px_-30px_rgba(10,22,40,0.35)] backdrop-blur sm:grid-cols-2 lg:grid-cols-5">
          {[
            { icon: Truck, label: "Machines under management", value: "1,284" },
            { icon: HardHat, label: "Active operators", value: "3,412" },
            { icon: ShieldCheck, label: "Approved requests", value: "97%" },
            { icon: Gauge, label: "Avg. turnaround time", value: "1.4d" },
          ].map((k) => (
            <div
              key={k.label}
              className="flex items-center gap-4 border-b border-r border-[#0a1628]/10 px-6 py-5 last:border-r-0"
            >
              <k.icon
                className="size-9 shrink-0 text-[#1e5fd6]"
                strokeWidth={1.4}
              />
              <div className="min-w-0">
                <div className="text-2xl font-black tabular-nums text-[#0a1628]">
                  {k.value}
                </div>
                <div className="text-[11px] uppercase tracking-wide text-[#4a5568]">
                  {k.label}
                </div>
              </div>
            </div>
          ))}
          <div className="relative flex flex-col justify-center gap-1 bg-white px-6 py-5">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-[#1e5fd6]">
              <Sparkles className="size-3.5" /> AI Copilot Insight
            </div>
            <div className="text-sm font-semibold text-[#0a1628]">
              Operator retention up 12% this quarter.
            </div>
            <p className="text-xs text-[#4a5568]">
              3 machines require reassignment in the next 7 days.
            </p>
            <Link
              to="/auth"
              className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-[#1e5fd6] hover:underline"
            >
              View insights <ArrowRight className="size-3" />
            </Link>
          </div>
        </div>
      </section>

      <footer className="relative z-10 border-t border-[#0a1628]/10 py-8 text-center text-xs text-[#4a5568]">
        © {new Date().getFullYear()} Operator360 · Built for the heavy equipment industry
      </footer>
    </div>
  );
}