import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { currentUserQuery } from "@/lib/operator360/queries";
import { AppShell } from "@/components/operator360/AppShell";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ location, context }) => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) {
      throw redirect({ to: "/auth", search: { redirect: location.href } });
    }
    await context.queryClient.ensureQueryData(currentUserQuery);
  },
  component: AuthedLayout,
});

function AuthedLayout() {
  const { data: user } = useSuspenseQuery(currentUserQuery);
  if (!user) {
    return (
      <div className="grid min-h-screen place-items-center px-6 text-center text-sm text-muted-foreground">
        <div>
          Your account is being provisioned. Please refresh in a moment or contact
          your administrator.
        </div>
      </div>
    );
  }
  return (
    <AppShell user={user}>
      <Outlet />
    </AppShell>
  );
}