import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { benefitsListQuery } from "@/lib/operator360/queries";
import { PageHeader } from "@/components/operator360/PageHeader";
import { StatusBadge } from "@/components/operator360/StatusBadge";
import { TableCard, Td, Th, Tr } from "@/components/operator360/DataShell";
import { EmptyState } from "@/components/operator360/EmptyState";
import { Shield, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/admin/benefits")({
  head: () => ({ meta: [{ title: "Benefits · Operator360" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(benefitsListQuery),
  component: BenefitsPage,
});
function BenefitsPage() {
  const { data } = useSuspenseQuery(benefitsListQuery);
  return (
    <div>
      <PageHeader title="Benefits" description="Welfare programs and insurance coverage across operators." actions={<Button size="sm"><Plus className="size-4" /> Add benefit</Button>} />
      {data.length === 0 ? (
        <EmptyState icon={Shield} title="No benefits registered" />
      ) : (
        <TableCard>
          <table className="w-full">
            <thead><tr><Th>Operator</Th><Th>Benefit</Th><Th>Coverage</Th><Th>Period</Th><Th>Status</Th></tr></thead>
            <tbody>
              {data.map((b) => (
                <Tr key={b.benefit_id}>
                  <Td>{(b as any).operators?.first_name} {(b as any).operators?.last_name} <span className="text-xs text-muted-foreground">({(b as any).operators?.operator_code})</span></Td>
                  <Td>{b.benefit_name}</Td>
                  <Td className="font-medium tabular-nums">₹{Number(b.coverage_amount ?? 0).toLocaleString()}</Td>
                  <Td className="text-muted-foreground">{b.start_date} → {b.end_date ?? "—"}</Td>
                  <Td><StatusBadge status={b.status} /></Td>
                </Tr>
              ))}
            </tbody>
          </table>
        </TableCard>
      )}
    </div>
  );
}