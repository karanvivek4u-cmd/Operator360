import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { AppUser } from "./types";

export const currentUserQuery = queryOptions({
  queryKey: ["me"],
  queryFn: async (): Promise<AppUser | null> => {
    const { data: sess } = await supabase.auth.getUser();
    const authUser = sess.user;
    if (!authUser) return null;
    const { data, error } = await supabase
      .from("users")
      .select("user_id,auth_user_id,full_name,email,role,customer_id,operator_id")
      .eq("auth_user_id", authUser.id)
      .maybeSingle();
    if (error) throw error;
    return data as AppUser | null;
  },
});

export const notificationsQuery = (userId: string | null) =>
  queryOptions({
    queryKey: ["notifications", userId],
    enabled: !!userId,
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("notifications")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data ?? [];
    },
  });

// Admin
export const adminMetricsQuery = queryOptions({
  queryKey: ["admin", "metrics"],
  queryFn: async () => {
    const [customers, machines, operators, pending] = await Promise.all([
      supabase.from("customers").select("customer_id", { count: "exact", head: true }),
      supabase.from("machines").select("machine_id", { count: "exact", head: true }),
      supabase.from("operators").select("operator_id", { count: "exact", head: true }),
      supabase
        .from("service_requests")
        .select("request_id", { count: "exact", head: true })
        .eq("overall_status", "PENDING"),
    ]);
    return {
      customers: customers.count ?? 0,
      machines: machines.count ?? 0,
      operators: operators.count ?? 0,
      pendingRequests: pending.count ?? 0,
    };
  },
});

export const customersListQuery = queryOptions({
  queryKey: ["customers"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("customers")
      .select("*")
      .order("company_name");
    if (error) throw error;
    return data ?? [];
  },
});

export const machinesListQuery = queryOptions({
  queryKey: ["machines"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("machines")
      .select("*, customers(company_name)")
      .order("serial_number");
    if (error) throw error;
    return data ?? [];
  },
});

export const operatorsListQuery = queryOptions({
  queryKey: ["operators"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("operators")
      .select("*, customers(company_name)")
      .order("first_name");
    if (error) throw error;
    return data ?? [];
  },
});

export const assignmentsListQuery = queryOptions({
  queryKey: ["assignments"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("operator_assignments")
      .select(
        "*, machines(serial_number, model_number, customer_id, customers(company_name)), operators(first_name,last_name,operator_code)"
      )
      .order("assignment_start_date", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
});

export const serviceRequestsListQuery = queryOptions({
  queryKey: ["service_requests"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("service_requests")
      .select(
        "*, customers(company_name), machines(serial_number), old_op:old_operator_id(first_name,last_name), new_op:new_operator_id(first_name,last_name)"
      )
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
});

export const benefitsListQuery = queryOptions({
  queryKey: ["benefits"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("benefits")
      .select("*, operators(first_name,last_name,operator_code)")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
});

export const loyaltyListQuery = queryOptions({
  queryKey: ["loyalty"],
  queryFn: async () => {
    const { data, error } = await supabase
      .from("loyalty_wallet")
      .select("*, customers(company_name)")
      .order("wallet_amount", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
});