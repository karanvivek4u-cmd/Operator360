import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { AppUser } from "./types";

type QueryRow = Record<string, any>;

async function getCurrentAppUser(): Promise<AppUser | null> {
  const { data: sess } = await supabase.auth.getUser();
  const authUser = sess.user;
  if (!authUser) return null;

  const { data, error } = await supabase
    .from("users")
    .select("user_id,auth_user_id,full_name,email,role,customer_id,operator_id")
    .eq("auth_user_id", authUser.id)
    .maybeSingle();

  if (error) throw error;
  return data as AppUser | null;
}

export const myMachinesQuery = queryOptions({
  queryKey: ["me", "machines"],
  queryFn: async () => {
    const user = await getCurrentAppUser();
    let query = supabase.from("machines").select("*").order("serial_number");
    if (user?.role === "CUSTOMER") query = query.eq("customer_id", user.customer_id ?? "");
    const { data, error } = await query;
    if (error) throw error;
    return (data ?? []) as QueryRow[];
  },
});

export const myOperatorsQuery = queryOptions({
  queryKey: ["me", "operators"],
  queryFn: async () => {
    const user = await getCurrentAppUser();
    let query = supabase.from("operators").select("*").order("first_name");
    if (user?.role === "CUSTOMER") query = query.eq("customer_id", user.customer_id ?? "");
    if (user?.role === "OPERATOR") query = query.eq("operator_id", user.operator_id ?? "");
    const { data, error } = await query;
    if (error) throw error;
    return (data ?? []) as QueryRow[];
  },
});

export const myAssignmentsQuery = queryOptions({
  queryKey: ["me", "assignments"],
  queryFn: async () => {
    const user = await getCurrentAppUser();
    let query = supabase
      .from("operator_assignments")
      .select("*, machines(serial_number), operators(first_name,last_name)")
      .order("assignment_start_date", { ascending: false });
    if (user?.role === "OPERATOR") query = query.eq("operator_id", user.operator_id ?? "");
    const { data, error } = await query;
    if (error) throw error;
    return (data ?? []) as QueryRow[];
  },
});

export const myRequestsQuery = queryOptions({
  queryKey: ["me", "requests"],
  queryFn: async () => {
    const user = await getCurrentAppUser();
    let query = supabase
      .from("service_requests")
      .select("*, machines(serial_number)")
      .order("created_at", { ascending: false });
    if (user?.role === "CUSTOMER") query = query.eq("customer_id", user.customer_id ?? "");
    const { data, error } = await query;
    if (error) throw error;
    return (data ?? []) as QueryRow[];
  },
});

export const myBenefitsQuery = queryOptions({
  queryKey: ["me", "benefits"],
  queryFn: async () => {
    const user = await getCurrentAppUser();
    let query = supabase.from("benefits").select("*").order("created_at", { ascending: false });
    if (user?.role === "OPERATOR") query = query.eq("operator_id", user.operator_id ?? "");
    const { data, error } = await query;
    if (error) throw error;
    return (data ?? []) as QueryRow[];
  },
});

export const myLoyaltyQuery = queryOptions({
  queryKey: ["me", "loyalty"],
  queryFn: async () => {
    const user = await getCurrentAppUser();
    let query = supabase.from("loyalty_wallet").select("*");
    if (user?.role === "CUSTOMER") query = query.eq("customer_id", user.customer_id ?? "");
    const { data, error } = await query.limit(1).maybeSingle();
    if (error) throw error;
    return data as QueryRow | null;
  },
});

// Insurance queues
export const insuranceQueueQuery = (status: "PENDING" | "APPROVED" | "REJECTED") =>
  queryOptions({
    queryKey: ["insurance", status],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("service_requests")
        .select("*, customers(company_name), machines(serial_number), old_op:old_operator_id(first_name,last_name), new_op:new_operator_id(first_name,last_name)")
        .eq("insurance_status", status)
        .order("created_at", { ascending: false });
      if (error) throw error;
        return (data ?? []) as QueryRow[];
    },
  });