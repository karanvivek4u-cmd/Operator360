export type UserRole = "Admin" | "Customer" | "Insurance Coordinator" | "Operator";

export interface Customer {
  id: string;
  name: string;
  companyCode: string;
  category: string;
  email: string;
  phone: string;
  address: string;
  walletBalance: number;
  status: string;
  createdAt?: string;
  machineCount?: number;
  operatorCount?: number;
}

export interface Machine {
  id: string;
  serialNumber: string;
  modelNumber: string;
  category: string;
  customerId: string;
  customerName?: string;
  customerCode?: string;
  status: "Active" | "Maintenance" | "Idle" | "Decommissioned" | string;
  warrantyExpiry: string;
  manufactureYear: number;
  specifications: string;
  activeOperatorCount?: number;
  activeOperators?: Operator[];
  createdAt?: string;
}

export interface Operator {
  id: string;
  name: string;
  mobile: string;
  email: string;
  photoUrl: string;
  customerId: string;
  customerName?: string;
  joiningDate: string;
  status: "Active" | "Suspended" | "On Leave" | string;
  policyNumber: string;
  coverageAmount: number;
  assignedMachine?: {
    id: string;
    modelNumber: string;
    serialNumber: string;
    assignedAt?: string;
  } | null;
  createdAt?: string;
}

export interface Assignment {
  id: string;
  machineId: string;
  operatorId: string;
  assignedAt: string;
  endedAt?: string | null;
  status: "Active" | "Replaced" | "Ended" | string;
  notes?: string;
  machineModel?: string;
  machineSerial?: string;
  operatorName?: string;
  operatorMobile?: string;
}

export interface ServiceRequest {
  id: string;
  customerId: string;
  customerName?: string;
  machineId: string;
  machineModel?: string;
  machineSerial?: string;
  oldOperatorId: string;
  oldOperator?: Operator | null;
  newOperatorId?: string | null;
  newOperator?: Operator | null;
  reason: string;
  remarks?: string;
  status: "Pending Insurance Approval" | "Pending Admin Approval" | "Approved" | "Rejected";
  insuranceReviewedAt?: string;
  insuranceNotes?: string;
  adminReviewedAt?: string;
  adminNotes?: string;
  createdAt: string;
}

export interface NotificationItem {
  id: string;
  targetRole: UserRole | string;
  targetEntityId?: string;
  title: string;
  message: string;
  type: "info" | "warning" | "success" | "alert";
  isRead: boolean;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  actorRole: string;
  actorName: string;
  action: string;
  details: string;
  createdAt: string;
}

export interface AIInsight {
  id: string;
  title: string;
  category: string;
  description: string;
  recommendation: string;
  impact: "High" | "Medium" | "Low";
  createdAt: string;
}
