import { NextResponse } from "next/server";
import { db } from "@/db";
import { operators, customers, assignments, machines, activityLogs } from "@/db/schema";
import { eq, and, like, or } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export async function GET(req: Request) {
  try {
    await seedDatabase();
    const { searchParams } = new URL(req.url);
    const customerId = searchParams.get("customerId");
    const search = searchParams.get("search");

    let query = db
      .select({
        operator: operators,
        customerName: customers.name,
      })
      .from(operators)
      .innerJoin(customers, eq(operators.customerId, customers.id));

    if (customerId) {
      query = query.where(eq(operators.customerId, customerId)) as typeof query;
    }

    const rows = await query;

    // Fetch active assigned machine for each operator
    const enriched = await Promise.all(
      rows.map(async (row) => {
        const activeAsgn = await db
          .select({
            assignment: assignments,
            machine: machines,
          })
          .from(assignments)
          .innerJoin(machines, eq(assignments.machineId, machines.id))
          .where(
            and(
              eq(assignments.operatorId, row.operator.id),
              eq(assignments.status, "Active")
            )
          )
          .limit(1);

        return {
          ...row.operator,
          customerName: row.customerName,
          assignedMachine: activeAsgn[0]
            ? {
                id: activeAsgn[0].machine.id,
                modelNumber: activeAsgn[0].machine.modelNumber,
                serialNumber: activeAsgn[0].machine.serialNumber,
                assignedAt: activeAsgn[0].assignment.assignedAt,
              }
            : null,
        };
      })
    );

    // Filter by search text if provided (search by name, mobile, or machine model/serial)
    if (search && search.trim() !== "") {
      const lower = search.toLowerCase().trim();
      const filtered = enriched.filter((op) => {
        const nameMatch = op.name.toLowerCase().includes(lower);
        const mobileMatch = op.mobile.toLowerCase().includes(lower);
        const customerMatch = op.customerName.toLowerCase().includes(lower);
        const machineMatch =
          op.assignedMachine &&
          (op.assignedMachine.modelNumber.toLowerCase().includes(lower) ||
            op.assignedMachine.serialNumber.toLowerCase().includes(lower));
        return nameMatch || mobileMatch || customerMatch || machineMatch;
      });
      return NextResponse.json(filtered);
    }

    return NextResponse.json(enriched);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, mobile, email, photoUrl, customerId, joiningDate, requesterRole } = body;

    // Enforce Business Rule: Admin CANNOT create operators. Only Customers can create operators.
    if (requesterRole === "Admin") {
      return NextResponse.json(
        { error: "Business Rule Violation: Admin cannot directly create operators. Operators can only be created by Customers." },
        { status: 403 }
      );
    }

    if (!name || !mobile || !customerId) {
      return NextResponse.json({ error: "Name, Mobile Number, and Customer are required" }, { status: 400 });
    }

    const newId = `op_${Date.now()}`;
    const policyNum = `INS-2026-X${Math.floor(1000 + Math.random() * 9000)}`;

    const newOperator = {
      id: newId,
      name,
      mobile,
      email: email || `${name.toLowerCase().replace(/\s+/g, ".")}@client.com`,
      photoUrl: photoUrl || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300`,
      customerId,
      joiningDate: joiningDate || new Date().toISOString().split("T")[0],
      status: "Active",
      policyNumber: policyNum,
      coverageAmount: 500000,
    };

    await db.insert(operators).values(newOperator);

    await db.insert(activityLogs).values({
      id: `act_${Date.now()}`,
      actorRole: "Customer",
      actorName: "Customer Admin",
      action: "Created Operator",
      details: `Registered new operator ${name} with policy ${policyNum}`,
    });

    return NextResponse.json({ success: true, operator: newOperator });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
