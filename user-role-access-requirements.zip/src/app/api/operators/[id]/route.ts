import { NextResponse } from "next/server";
import { db } from "@/db";
import { operators, customers, assignments, machines, activityLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const op = await db
      .select({
        operator: operators,
        customer: customers,
      })
      .from(operators)
      .innerJoin(customers, eq(operators.customerId, customers.id))
      .where(eq(operators.id, id))
      .limit(1);

    if (!op.length) {
      return NextResponse.json({ error: "Operator not found" }, { status: 404 });
    }

    // Get all assignments for this operator
    const allAssignments = await db
      .select({
        assignment: assignments,
        machine: machines,
      })
      .from(assignments)
      .innerJoin(machines, eq(assignments.machineId, machines.id))
      .where(eq(assignments.operatorId, id))
      .orderBy(desc(assignments.assignedAt));

    const activeAsgn = allAssignments.find((a) => a.assignment.status === "Active");

    return NextResponse.json({
      operator: op[0].operator,
      customer: op[0].customer,
      assignedMachine: activeAsgn ? activeAsgn.machine : null,
      activeAssignment: activeAsgn ? activeAsgn.assignment : null,
      history: allAssignments.map((a) => ({
        ...a.assignment,
        machineModel: a.machine.modelNumber,
        machineSerial: a.machine.serialNumber,
      })),
      benefits: {
        policyNumber: op[0].operator.policyNumber,
        coverageAmount: op[0].operator.coverageAmount,
        status: "Active Policy",
        coverageItems: [
          { name: "Group Occupational Accident & Disability", limit: "$500,000" },
          { name: "Emergency Medical & Trauma Response", limit: "$100,000" },
          { name: "OEM Equipment Operator Liability Shield", limit: "Included" },
          { name: "Annual Health Screening & Driver Fitness", limit: "100% Covered" },
        ],
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.select().from(operators).where(eq(operators.id, id)).limit(1);
    if (!existing.length) {
      return NextResponse.json({ error: "Operator not found" }, { status: 404 });
    }

    await db
      .update(operators)
      .set({
        name: body.name ?? existing[0].name,
        mobile: body.mobile ?? existing[0].mobile,
        email: body.email ?? existing[0].email,
        photoUrl: body.photoUrl ?? existing[0].photoUrl,
        status: body.status ?? existing[0].status,
      })
      .where(eq(operators.id, id));

    await db.insert(activityLogs).values({
      id: `act_${Date.now()}`,
      actorRole: "Customer",
      actorName: "Customer Admin",
      action: "Updated Operator",
      details: `Updated info for operator ${existing[0].name}`,
    });

    return NextResponse.json({ success: true, message: "Operator details updated successfully" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
