import { NextResponse } from "next/server";
import { db } from "@/db";
import { machines, customers, assignments, operators, activityLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const mach = await db
      .select({
        machine: machines,
        customer: customers,
      })
      .from(machines)
      .innerJoin(customers, eq(machines.customerId, customers.id))
      .where(eq(machines.id, id))
      .limit(1);

    if (!mach.length) {
      return NextResponse.json({ error: "Machine not found" }, { status: 404 });
    }

    // Get all assignments (Active & Historical)
    const allAssignments = await db
      .select({
        assignment: assignments,
        operator: operators,
      })
      .from(assignments)
      .innerJoin(operators, eq(assignments.operatorId, operators.id))
      .where(eq(assignments.machineId, id))
      .orderBy(desc(assignments.assignedAt));

    const activeAssignments = allAssignments.filter((a) => a.assignment.status === "Active");
    const historicalAssignments = allAssignments.filter((a) => a.assignment.status !== "Active");

    return NextResponse.json({
      machine: mach[0].machine,
      customer: mach[0].customer,
      activeOperators: activeAssignments.map((a) => ({
        ...a.operator,
        assignmentId: a.assignment.id,
        assignedAt: a.assignment.assignedAt,
        notes: a.assignment.notes,
      })),
      activeCount: activeAssignments.length,
      history: historicalAssignments.map((h) => ({
        ...h.assignment,
        operatorName: h.operator.name,
        operatorMobile: h.operator.mobile,
      })),
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.select().from(machines).where(eq(machines.id, id)).limit(1);
    if (!existing.length) {
      return NextResponse.json({ error: "Machine not found" }, { status: 404 });
    }

    await db
      .update(machines)
      .set({
        modelNumber: body.modelNumber ?? existing[0].modelNumber,
        serialNumber: body.serialNumber ?? existing[0].serialNumber,
        category: body.category ?? existing[0].category,
        status: body.status ?? existing[0].status,
        warrantyExpiry: body.warrantyExpiry ?? existing[0].warrantyExpiry,
        manufactureYear: body.manufactureYear !== undefined ? Number(body.manufactureYear) : existing[0].manufactureYear,
        specifications: body.specifications ?? existing[0].specifications,
      })
      .where(eq(machines.id, id));

    await db.insert(activityLogs).values({
      id: `act_${Date.now()}`,
      actorRole: "Admin",
      actorName: "System Admin",
      action: "Updated Machine",
      details: `Edited specs or status for ${existing[0].modelNumber}`,
    });

    return NextResponse.json({ success: true, message: "Machine updated successfully" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
