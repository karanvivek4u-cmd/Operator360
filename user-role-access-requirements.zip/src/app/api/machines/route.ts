import { NextResponse } from "next/server";
import { db } from "@/db";
import { machines, customers, assignments, operators, activityLogs } from "@/db/schema";
import { eq, and, isNull } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export async function GET(req: Request) {
  try {
    await seedDatabase();
    const { searchParams } = new URL(req.url);
    const customerId = searchParams.get("customerId");

    let query = db.select({
      machine: machines,
      customerName: customers.name,
      customerCode: customers.companyCode,
    })
    .from(machines)
    .innerJoin(customers, eq(machines.customerId, customers.id));

    if (customerId) {
      query = query.where(eq(machines.customerId, customerId)) as typeof query;
    }

    const result = await query;

    // Enrich each machine with list of active assigned operators and active operator count
    const enriched = await Promise.all(
      result.map(async (row) => {
        const activeAssignments = await db
          .select({
            assignment: assignments,
            operator: operators,
          })
          .from(assignments)
          .innerJoin(operators, eq(assignments.operatorId, operators.id))
          .where(and(eq(assignments.machineId, row.machine.id), eq(assignments.status, "Active")));

        return {
          ...row.machine,
          customerName: row.customerName,
          customerCode: row.customerCode,
          activeOperatorCount: activeAssignments.length,
          activeOperators: activeAssignments.map((a) => a.operator),
        };
      })
    );

    return NextResponse.json(enriched);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { serialNumber, modelNumber, category, customerId, warrantyExpiry, manufactureYear, specifications } = body;

    if (!serialNumber || !modelNumber || !customerId) {
      return NextResponse.json({ error: "Serial Number, Model Number, and Customer are required" }, { status: 400 });
    }

    const newId = `mach_${Date.now()}`;
    const newMachine = {
      id: newId,
      serialNumber,
      modelNumber,
      category: category || "Heavy Equipment",
      customerId,
      status: "Active",
      warrantyExpiry: warrantyExpiry || "2027-12-31",
      manufactureYear: Number(manufactureYear) || new Date().getFullYear(),
      specifications: typeof specifications === "string" ? specifications : JSON.stringify(specifications || {}),
    };

    await db.insert(machines).values(newMachine);

    await db.insert(activityLogs).values({
      id: `act_${Date.now()}`,
      actorRole: "Admin",
      actorName: "System Admin",
      action: "Added Machine",
      details: `Added new machine ${modelNumber} (${serialNumber})`,
    });

    return NextResponse.json({ success: true, machine: newMachine });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
