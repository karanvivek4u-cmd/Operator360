import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers, machines, operators, serviceRequests, assignments } from "@/db/schema";
import { eq, count } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export async function GET() {
  try {
    await seedDatabase();

    const [custs, machs, ops, reqs, asgns] = await Promise.all([
      db.select().from(customers),
      db.select().from(machines),
      db.select().from(operators),
      db.select().from(serviceRequests),
      db.select().from(assignments),
    ]);

    const totalCustomers = custs.length;
    const totalMachines = machs.length;
    const totalOperators = ops.length;
    const openRequests = reqs.filter(
      (r) => r.status === "Pending Insurance Approval" || r.status === "Pending Admin Approval"
    ).length;
    const activeBenefits = ops.filter((o) => o.status === "Active").length;
    const totalWallet = custs.reduce((acc, c) => acc + (c.walletBalance || 0), 0);

    // Machine Status Chart
    const machineStatusCount: Record<string, number> = {
      Active: 0,
      Maintenance: 0,
      Idle: 0,
      Decommissioned: 0,
    };
    machs.forEach((m) => {
      machineStatusCount[m.status] = (machineStatusCount[m.status] || 0) + 1;
    });

    const machineStatusChart = Object.keys(machineStatusCount).map((status) => ({
      name: status,
      value: machineStatusCount[status],
    }));

    // Operator Growth Chart Data (Mock timeline based on joining dates)
    const operatorGrowthChart = [
      { month: "Oct 2025", operators: totalOperators - 5, activeAssignments: totalOperators - 6 },
      { month: "Nov 2025", operators: totalOperators - 4, activeAssignments: totalOperators - 4 },
      { month: "Dec 2025", operators: totalOperators - 3, activeAssignments: totalOperators - 3 },
      { month: "Jan 2026", operators: totalOperators - 2, activeAssignments: totalOperators - 2 },
      { month: "Feb 2026", operators: totalOperators - 1, activeAssignments: totalOperators - 1 },
      { month: "Mar 2026", operators: totalOperators, activeAssignments: asgns.filter((a) => a.status === "Active").length },
    ];

    // Request breakdown
    const requestBreakdown = {
      pendingInsurance: reqs.filter((r) => r.status === "Pending Insurance Approval").length,
      pendingAdmin: reqs.filter((r) => r.status === "Pending Admin Approval").length,
      approved: reqs.filter((r) => r.status === "Approved").length,
      rejected: reqs.filter((r) => r.status === "Rejected").length,
    };

    return NextResponse.json({
      metrics: {
        totalCustomers,
        totalMachines,
        totalOperators,
        activeBenefits,
        openRequests,
        totalWallet,
      },
      machineStatusChart,
      operatorGrowthChart,
      requestBreakdown,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
