import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  serviceRequests,
  customers,
  machines,
  operators,
  notifications,
  activityLogs,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const customerId = searchParams.get("customerId");
    const status = searchParams.get("status");

    let query = db
      .select({
        request: serviceRequests,
        customerName: customers.name,
        machineModel: machines.modelNumber,
        machineSerial: machines.serialNumber,
      })
      .from(serviceRequests)
      .innerJoin(customers, eq(serviceRequests.customerId, customers.id))
      .innerJoin(machines, eq(serviceRequests.machineId, machines.id))
      .orderBy(desc(serviceRequests.createdAt));

    const rows = await query;

    // Fetch old operator and new operator details for each request
    const enriched = await Promise.all(
      rows.map(async (row) => {
        const oldOp = await db
          .select()
          .from(operators)
          .where(eq(operators.id, row.request.oldOperatorId))
          .limit(1);

        let newOp = null;
        if (row.request.newOperatorId) {
          const fetchedNew = await db
            .select()
            .from(operators)
            .where(eq(operators.id, row.request.newOperatorId))
            .limit(1);
          newOp = fetchedNew[0] || null;
        }

        return {
          ...row.request,
          customerName: row.customerName,
          machineModel: row.machineModel,
          machineSerial: row.machineSerial,
          oldOperator: oldOp[0] || null,
          newOperator: newOp,
        };
      })
    );

    let result = enriched;
    if (customerId) {
      result = result.filter((r) => r.customerId === customerId);
    }
    if (status) {
      result = result.filter((r) => r.status === status);
    }

    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { customerId, machineId, oldOperatorId, newOperatorId, reason, remarks } = body;

    if (!customerId || !machineId || !oldOperatorId || !reason) {
      return NextResponse.json(
        { error: "Customer, Machine, Old Operator, and Reason are required" },
        { status: 400 }
      );
    }

    const reqId = `req_${Math.floor(100 + Math.random() * 900)}`;

    const newReq = {
      id: reqId,
      customerId,
      machineId,
      oldOperatorId,
      newOperatorId: newOperatorId || null,
      reason,
      remarks: remarks || "",
      status: "Pending Insurance Approval", // Initial state per business workflow
    };

    await db.insert(serviceRequests).values(newReq);

    // Get details for notification
    const cust = await db.select().from(customers).where(eq(customers.id, customerId)).limit(1);
    const mach = await db.select().from(machines).where(eq(machines.id, machineId)).limit(1);

    // Send Notification to Insurance Coordinator
    await db.insert(notifications).values({
      id: `notif_${Date.now()}`,
      targetRole: "Insurance",
      title: "New Operator Replacement Request",
      message: `${cust[0]?.name || "Customer"} submitted replacement request (${reqId}) for machine ${mach[0]?.modelNumber}.`,
      type: "alert",
    });

    // Log activity
    await db.insert(activityLogs).values({
      id: `act_${Date.now()}`,
      actorRole: "Customer",
      actorName: cust[0]?.name || "Customer Admin",
      action: "Raised Replacement Request",
      details: `Created replacement request ${reqId} for ${mach[0]?.modelNumber}`,
    });

    return NextResponse.json({ success: true, requestId: reqId });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
