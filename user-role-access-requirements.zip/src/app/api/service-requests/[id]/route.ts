import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  serviceRequests,
  assignments,
  notifications,
  activityLogs,
  machines,
  operators,
  customers,
} from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const reqRow = await db
      .select()
      .from(serviceRequests)
      .where(eq(serviceRequests.id, id))
      .limit(1);

    if (!reqRow.length) {
      return NextResponse.json({ error: "Service request not found" }, { status: 404 });
    }

    const cust = await db.select().from(customers).where(eq(customers.id, reqRow[0].customerId)).limit(1);
    const mach = await db.select().from(machines).where(eq(machines.id, reqRow[0].machineId)).limit(1);
    const oldOp = await db.select().from(operators).where(eq(operators.id, reqRow[0].oldOperatorId)).limit(1);
    const newOp = reqRow[0].newOperatorId
      ? await db.select().from(operators).where(eq(operators.id, reqRow[0].newOperatorId)).limit(1)
      : [];

    return NextResponse.json({
      request: reqRow[0],
      customer: cust[0] || null,
      machine: mach[0] || null,
      oldOperator: oldOp[0] || null,
      newOperator: newOp[0] || null,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { action, notes } = body;

    const existingReq = await db
      .select()
      .from(serviceRequests)
      .where(eq(serviceRequests.id, id))
      .limit(1);

    if (!existingReq.length) {
      return NextResponse.json({ error: "Service request not found" }, { status: 404 });
    }

    const current = existingReq[0];

    if (action === "insurance_approve") {
      await db
        .update(serviceRequests)
        .set({
          status: "Pending Admin Approval",
          insuranceReviewedAt: new Date(),
          insuranceNotes: notes || "Approved by Insurance Coordinator",
        })
        .where(eq(serviceRequests.id, id));

      // Notify Admin
      await db.insert(notifications).values({
        id: `notif_${Date.now()}`,
        targetRole: "Admin",
        title: "Replacement Request Approved by Insurance",
        message: `Request ${id} cleared by Insurance Coordinator. Final Admin approval required.`,
        type: "warning",
      });

      await db.insert(activityLogs).values({
        id: `act_${Date.now()}`,
        actorRole: "Insurance Coordinator",
        actorName: "Insurance Desk",
        action: "Insurance Approved Replacement Request",
        details: `Request ${id} approved by Insurance. Moved to Admin Queue.`,
      });

      return NextResponse.json({
        success: true,
        message: "Request approved by Insurance Coordinator and sent to Admin for final approval.",
      });
    }

    if (action === "insurance_reject") {
      await db
        .update(serviceRequests)
        .set({
          status: "Rejected",
          insuranceReviewedAt: new Date(),
          insuranceNotes: notes || "Rejected by Insurance Coordinator",
        })
        .where(eq(serviceRequests.id, id));

      await db.insert(activityLogs).values({
        id: `act_${Date.now()}`,
        actorRole: "Insurance Coordinator",
        actorName: "Insurance Desk",
        action: "Insurance Rejected Replacement Request",
        details: `Request ${id} was rejected during insurance review.`,
      });

      return NextResponse.json({
        success: true,
        message: "Request rejected by Insurance Coordinator.",
      });
    }

    if (action === "admin_approve") {
      // Must be in "Pending Admin Approval" or "Pending Insurance Approval" if forced
      await db
        .update(serviceRequests)
        .set({
          status: "Approved",
          adminReviewedAt: new Date(),
          adminNotes: notes || "Final OEM Admin Approval granted.",
        })
        .where(eq(serviceRequests.id, id));

      // Execute assignment changes!
      // 1) Terminate old operator's assignment on this machine
      await db
        .update(assignments)
        .set({
          status: "Replaced",
          endedAt: new Date(),
          notes: `Replaced via service request ${id}`,
        })
        .where(
          and(
            eq(assignments.machineId, current.machineId),
            eq(assignments.operatorId, current.oldOperatorId),
            eq(assignments.status, "Active")
          )
        );

      // 2) If new operator specified, assign new operator to machine
      if (current.newOperatorId) {
        await db.insert(assignments).values({
          id: `asgn_${Date.now()}`,
          machineId: current.machineId,
          operatorId: current.newOperatorId,
          assignedAt: new Date(),
          status: "Active",
          notes: `Assigned via approved replacement request ${id}`,
        });
      }

      // Notify Customer
      await db.insert(notifications).values({
        id: `notif_${Date.now()}`,
        targetRole: "Customer",
        targetEntityId: current.customerId,
        title: "Replacement Request Fully Approved",
        message: `Replacement request ${id} has been fully approved by OEM Admin and Insurance. Operator assignment updated.`,
        type: "success",
      });

      await db.insert(activityLogs).values({
        id: `act_${Date.now()}`,
        actorRole: "Admin",
        actorName: "OEM Admin",
        action: "Admin Approved Replacement Request",
        details: `Request ${id} fully approved. Old operator replaced, new assignment active.`,
      });

      return NextResponse.json({
        success: true,
        message: "Request approved by Admin. Old assignment terminated and new operator assigned successfully.",
      });
    }

    if (action === "admin_reject") {
      await db
        .update(serviceRequests)
        .set({
          status: "Rejected",
          adminReviewedAt: new Date(),
          adminNotes: notes || "Rejected by OEM Admin",
        })
        .where(eq(serviceRequests.id, id));

      await db.insert(activityLogs).values({
        id: `act_${Date.now()}`,
        actorRole: "Admin",
        actorName: "OEM Admin",
        action: "Admin Rejected Replacement Request",
        details: `Request ${id} rejected by OEM Admin.`,
      });

      return NextResponse.json({
        success: true,
        message: "Request rejected by Admin.",
      });
    }

    return NextResponse.json({ error: "Invalid action specified" }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
