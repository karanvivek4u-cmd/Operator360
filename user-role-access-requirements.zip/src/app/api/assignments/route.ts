import { NextResponse } from "next/server";
import { db } from "@/db";
import { assignments, machines, operators, activityLogs } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const machineId = searchParams.get("machineId");
    const operatorId = searchParams.get("operatorId");

    let query = db
      .select({
        assignment: assignments,
        machine: machines,
        operator: operators,
      })
      .from(assignments)
      .innerJoin(machines, eq(assignments.machineId, machines.id))
      .innerJoin(operators, eq(assignments.operatorId, operators.id));

    if (machineId) {
      query = query.where(eq(assignments.machineId, machineId)) as typeof query;
    } else if (operatorId) {
      query = query.where(eq(assignments.operatorId, operatorId)) as typeof query;
    }

    const rows = await query;
    return NextResponse.json(
      rows.map((r) => ({
        ...r.assignment,
        machineModel: r.machine.modelNumber,
        machineSerial: r.machine.serialNumber,
        operatorName: r.operator.name,
        operatorMobile: r.operator.mobile,
      }))
    );
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { machineId, operatorId, notes } = body;

    if (!machineId || !operatorId) {
      return NextResponse.json({ error: "Machine and Operator are required" }, { status: 400 });
    }

    // Rule 1: Check active operator count on machine (Max 3)
    const activeOnMachine = await db
      .select()
      .from(assignments)
      .where(and(eq(assignments.machineId, machineId), eq(assignments.status, "Active")));

    if (activeOnMachine.length >= 3) {
      return NextResponse.json(
        { error: "Business Rule Limit: This machine already has the maximum allowable active operators (3/3)." },
        { status: 400 }
      );
    }

    // Rule 2: Check if operator is already assigned to another machine
    const activeForOperator = await db
      .select()
      .from(assignments)
      .where(and(eq(assignments.operatorId, operatorId), eq(assignments.status, "Active")));

    if (activeForOperator.length > 0) {
      return NextResponse.json(
        { error: "Business Rule Limit: This operator is currently actively assigned to another machine. Raise a replacement request or unassign first." },
        { status: 400 }
      );
    }

    // Create Assignment
    const newAsgnId = `asgn_${Date.now()}`;
    await db.insert(assignments).values({
      id: newAsgnId,
      machineId,
      operatorId,
      assignedAt: new Date(),
      status: "Active",
      notes: notes || "Directly assigned by Customer",
    });

    // Get names for logging
    const targetMach = await db.select().from(machines).where(eq(machines.id, machineId)).limit(1);
    const targetOp = await db.select().from(operators).where(eq(operators.id, operatorId)).limit(1);

    await db.insert(activityLogs).values({
      id: `act_${Date.now()}`,
      actorRole: "Customer",
      actorName: "Customer Admin",
      action: "Assigned Operator",
      details: `Assigned operator ${targetOp[0]?.name} to machine ${targetMach[0]?.modelNumber}`,
    });

    return NextResponse.json({ success: true, assignmentId: newAsgnId });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
