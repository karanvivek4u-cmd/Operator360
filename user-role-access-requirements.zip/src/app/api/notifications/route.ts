import { NextResponse } from "next/server";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { eq, or, desc } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export async function GET(req: Request) {
  try {
    await seedDatabase();
    const { searchParams } = new URL(req.url);
    const targetRole = searchParams.get("targetRole");
    const targetEntityId = searchParams.get("targetEntityId");

    let query = db.select().from(notifications).orderBy(desc(notifications.createdAt));

    const rows = await query;
    let filtered = rows;

    if (targetRole) {
      filtered = filtered.filter((n) => {
        const roleMatch = n.targetRole === targetRole;
        const entityMatch = !targetEntityId || !n.targetEntityId || n.targetEntityId === targetEntityId;
        return roleMatch && entityMatch;
      });
    }

    return NextResponse.json(filtered);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const { id, isRead } = body;

    if (id) {
      await db
        .update(notifications)
        .set({ isRead: isRead ?? true })
        .where(eq(notifications.id, id));
    } else {
      // Mark all read for targetRole
      const { targetRole } = body;
      if (targetRole) {
        await db
          .update(notifications)
          .set({ isRead: true })
          .where(eq(notifications.targetRole, targetRole));
      }
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
