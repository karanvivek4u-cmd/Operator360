import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers, machines, operators, serviceRequests, activityLogs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const customer = await db.select().from(customers).where(eq(customers.id, id)).limit(1);

    if (!customer.length) {
      return NextResponse.json({ error: "Customer not found" }, { status: 404 });
    }

    const custMachines = await db.select().from(machines).where(eq(machines.customerId, id));
    const custOperators = await db.select().from(operators).where(eq(operators.customerId, id));
    const custRequests = await db.select().from(serviceRequests).where(eq(serviceRequests.customerId, id));

    return NextResponse.json({
      customer: customer[0],
      machines: custMachines,
      operators: custOperators,
      requests: custRequests,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const existing = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
    if (!existing.length) {
      return NextResponse.json({ error: "Customer not found" }, { status: 404 });
    }

    await db
      .update(customers)
      .set({
        name: body.name ?? existing[0].name,
        category: body.category ?? existing[0].category,
        email: body.email ?? existing[0].email,
        phone: body.phone ?? existing[0].phone,
        address: body.address ?? existing[0].address,
        walletBalance: body.walletBalance !== undefined ? Number(body.walletBalance) : existing[0].walletBalance,
        status: body.status ?? existing[0].status,
      })
      .where(eq(customers.id, id));

    await db.insert(activityLogs).values({
      id: `act_${Date.now()}`,
      actorRole: "Admin",
      actorName: "System Admin",
      action: "Updated Customer",
      details: `Updated details or status for customer: ${existing[0].name}`,
    });

    return NextResponse.json({ success: true, message: "Customer updated successfully" });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
