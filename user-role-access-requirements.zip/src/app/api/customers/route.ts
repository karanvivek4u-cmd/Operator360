import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers, machines, operators, activityLogs } from "@/db/schema";
import { eq, count } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export async function GET() {
  try {
    await seedDatabase();
    const allCustomers = await db.select().from(customers).orderBy(customers.createdAt);
    
    // Enrich with count of machines and operators
    const enriched = await Promise.all(
      allCustomers.map(async (cust) => {
        const mCount = await db
          .select({ val: count() })
          .from(machines)
          .where(eq(machines.customerId, cust.id));
        
        const oCount = await db
          .select({ val: count() })
          .from(operators)
          .where(eq(operators.customerId, cust.id));

        return {
          ...cust,
          machineCount: mCount[0]?.val || 0,
          operatorCount: oCount[0]?.val || 0,
        };
      })
    );

    return NextResponse.json(enriched);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, companyCode, category, email, phone, address, walletBalance } = body;

    if (!name || !companyCode || !email) {
      return NextResponse.json({ error: "Name, Company Code and Email are required" }, { status: 400 });
    }

    const newId = `cust_${Date.now()}`;
    const newCustomer = {
      id: newId,
      name,
      companyCode,
      category: category || "Gold OEM Client",
      email,
      phone: phone || "+1 (555) 000-0000",
      address: address || "Registered Address",
      walletBalance: Number(walletBalance) || 25000,
      status: "Active",
    };

    await db.insert(customers).values(newCustomer);

    // Log Activity
    await db.insert(activityLogs).values({
      id: `act_${Date.now()}`,
      actorRole: "Admin",
      actorName: "System Admin",
      action: "Created Customer",
      details: `Added new customer: ${name} (${companyCode})`,
    });

    return NextResponse.json({ success: true, customer: newCustomer });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
