"use client";

import { useState, useEffect } from "react";
import { UserRole, Customer, Operator, NotificationItem } from "@/types";
import { Navbar } from "@/components/layout/Navbar";
import { Sidebar } from "@/components/layout/Sidebar";

// View modules
import { AdminViews } from "@/components/views/AdminViews";
import { CustomerViews } from "@/components/views/CustomerViews";
import { InsuranceViews } from "@/components/views/InsuranceViews";
import { OperatorViews } from "@/components/views/OperatorViews";

// Modals
import { AssignOperatorModal } from "@/components/modals/AssignOperatorModal";
import { ReplaceOperatorModal } from "@/components/modals/ReplaceOperatorModal";
import { AddCustomerModal } from "@/components/modals/AddCustomerModal";
import { AddMachineModal } from "@/components/modals/AddMachineModal";
import { CustomerDetailModal } from "@/components/modals/CustomerDetailModal";
import { MachineDetailModal } from "@/components/modals/MachineDetailModal";

import { X, Bell, Shield, Loader2, RefreshCw } from "lucide-react";

export default function Home() {
  const [currentRole, setCurrentRole] = useState<UserRole>("Admin");
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // Global entity states
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [activeCustomer, setActiveCustomer] = useState<Customer | null>(null);

  const [operators, setOperators] = useState<Operator[]>([]);
  const [activeOperator, setActiveOperator] = useState<Operator | null>(null);

  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);

  const [initializing, setInitializing] = useState<boolean>(true);

  // Modals state
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [isAddMachineOpen, setIsAddMachineOpen] = useState(false);
  const [addMachineCustomerId, setAddMachineCustomerId] = useState<string | undefined>(undefined);

  const [isAssignOperatorOpen, setIsAssignOperatorOpen] = useState(false);
  const [assignMachineId, setAssignMachineId] = useState<string | undefined>(undefined);

  const [isReplaceOperatorOpen, setIsReplaceOperatorOpen] = useState(false);
  const [replaceMachineId, setReplaceMachineId] = useState<string | undefined>(undefined);

  const [detailCustomerId, setDetailCustomerId] = useState<string | null>(null);
  const [detailMachineId, setDetailMachineId] = useState<string | null>(null);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  useEffect(() => {
    bootstrapApp();
  }, []);

  useEffect(() => {
    // Reset active tab to dashboard on role switch
    setActiveTab("dashboard");
    fetchNotifications();
  }, [currentRole, activeCustomer, activeOperator]);

  const bootstrapApp = async () => {
    setInitializing(true);
    try {
      // Seed & load customers and operators
      const [cRes, oRes] = await Promise.all([
        fetch("/api/customers"),
        fetch("/api/operators"),
      ]);

      const cData = await cRes.json();
      const oData = await oRes.json();

      if (Array.isArray(cData) && cData.length > 0) {
        setCustomers(cData);
        setActiveCustomer(cData[0]);
      }

      if (Array.isArray(oData) && oData.length > 0) {
        setOperators(oData);
        setActiveOperator(oData[0]);
      }

      await fetchNotifications();
    } catch (err) {
      console.error("Initialization error:", err);
    } finally {
      setInitializing(false);
    }
  };

  const fetchNotifications = async () => {
    try {
      let url = `/api/notifications?targetRole=${currentRole}`;
      if (currentRole === "Customer" && activeCustomer) {
        url += `&targetEntityId=${activeCustomer.id}`;
      } else if (currentRole === "Operator" && activeOperator) {
        url += `&targetEntityId=${activeOperator.id}`;
      }

      const res = await fetch(url);
      const data = await res.json();
      if (Array.isArray(data)) {
        setNotifications(data);
        const unread = data.filter((n: NotificationItem) => !n.isRead).length;
        setUnreadCount(unread);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleMarkNotificationsRead = async () => {
    try {
      await fetch("/api/notifications", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetRole: currentRole }),
      });
      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  const reloadGlobalEntities = async () => {
    try {
      const [cRes, oRes] = await Promise.all([
        fetch("/api/customers"),
        fetch("/api/operators"),
      ]);
      const cData = await cRes.json();
      const oData = await oRes.json();

      if (Array.isArray(cData)) {
        setCustomers(cData);
        if (activeCustomer) {
          const updated = cData.find((c: Customer) => c.id === activeCustomer.id);
          if (updated) setActiveCustomer(updated);
        }
      }

      if (Array.isArray(oData)) {
        setOperators(oData);
        if (activeOperator) {
          const updatedOp = oData.find((op: Operator) => op.id === activeOperator.id);
          if (updatedOp) setActiveOperator(updatedOp);
        }
      }

      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  if (initializing) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 gap-4">
        <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
          <Loader2 className="w-7 h-7 animate-spin" />
        </div>
        <div className="text-center space-y-1">
          <h2 className="text-xl font-bold">Bootstrapping Titan OEM Fleet Management</h2>
          <p className="text-xs text-slate-400">
            Connecting Drizzle ORM, initializing PostgreSQL schema, and seeding demo assets...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col antialiased">
      {/* Role Selector Header Navigation */}
      <Navbar
        currentRole={currentRole}
        onRoleChange={(r) => setCurrentRole(r)}
        customers={customers}
        activeCustomer={activeCustomer}
        onCustomerChange={(c) => setActiveCustomer(c)}
        operators={operators}
        activeOperator={activeOperator}
        onOperatorChange={(op) => setActiveOperator(op)}
        unreadCount={unreadCount}
        onToggleNotifications={() => setIsNotificationsOpen(!isNotificationsOpen)}
      />

      {/* Main Layout Area */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Dynamic Navigation Sidebar */}
        <Sidebar
          currentRole={currentRole}
          activeTab={activeTab}
          onTabChange={(tab) => setActiveTab(tab)}
          unreadCount={unreadCount}
        />

        {/* Dynamic Page Content View depending on Selected Role */}
        <main className="flex-1 p-4 lg:p-8 overflow-y-auto max-w-7xl">
          {currentRole === "Admin" && (
            <AdminViews
              activeTab={activeTab}
              onOpenAddCustomer={() => setIsAddCustomerOpen(true)}
              onOpenAddMachine={() => {
                setAddMachineCustomerId(undefined);
                setIsAddMachineOpen(true);
              }}
              onSelectCustomer={(id) => setDetailCustomerId(id)}
              onSelectMachine={(id) => setDetailMachineId(id)}
              onSelectOperator={(op) => {
                // Navigate or view operator
                setActiveTab("operators");
              }}
            />
          )}

          {currentRole === "Customer" && (
            <CustomerViews
              activeTab={activeTab}
              activeCustomer={activeCustomer}
              onOpenAssignModal={(machId) => {
                setAssignMachineId(machId);
                setIsAssignOperatorOpen(true);
              }}
              onOpenReplaceModal={(machId) => {
                setReplaceMachineId(machId);
                setIsReplaceOperatorOpen(true);
              }}
              onSelectMachine={(id) => setDetailMachineId(id)}
              onSelectOperator={(op) => {
                setActiveTab("operators");
              }}
            />
          )}

          {currentRole === "Insurance Coordinator" && (
            <InsuranceViews
              activeTab={activeTab}
              onSelectOperator={(op) => {
                setActiveTab("requests");
              }}
            />
          )}

          {currentRole === "Operator" && (
            <OperatorViews
              activeTab={activeTab}
              activeOperator={activeOperator}
            />
          )}
        </main>
      </div>

      {/* Notifications Drawer Slide-over */}
      {isNotificationsOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/50 backdrop-blur-xs">
          <div className="bg-slate-900 border-l border-slate-800 w-full max-w-md h-full p-6 flex flex-col shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-amber-400" />
                <h3 className="text-lg font-bold text-slate-100">Notifications ({currentRole})</h3>
              </div>
              <button
                onClick={() => setIsNotificationsOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center justify-between mb-4">
              <span className="text-xs text-slate-400">{notifications.length} Alerts Target Log</span>
              <button
                onClick={handleMarkNotificationsRead}
                className="text-xs font-semibold text-amber-400 hover:underline"
              >
                Mark All Read
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {notifications.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs italic">
                  No notifications found for role {currentRole}.
                </div>
              ) : (
                notifications.map((n) => (
                  <div
                    key={n.id}
                    className={`p-3.5 rounded-xl border text-xs space-y-1 transition ${
                      n.isRead
                        ? "bg-slate-800/30 border-slate-800/60 text-slate-400"
                        : "bg-slate-800/80 border-amber-500/30 text-slate-200"
                    }`}
                  >
                    <div className="font-bold text-slate-100 flex items-center justify-between">
                      <span>{n.title}</span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(n.createdAt).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">{n.message}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal Dialogs */}
      <AddCustomerModal
        isOpen={isAddCustomerOpen}
        onClose={() => setIsAddCustomerOpen(false)}
        onSuccess={() => {
          reloadGlobalEntities();
        }}
      />

      <AddMachineModal
        isOpen={isAddMachineOpen}
        onClose={() => setIsAddMachineOpen(false)}
        onSuccess={() => {
          reloadGlobalEntities();
        }}
        preselectedCustomerId={addMachineCustomerId}
      />

      <AssignOperatorModal
        isOpen={isAssignOperatorOpen}
        onClose={() => setIsAssignOperatorOpen(false)}
        onSuccess={() => {
          reloadGlobalEntities();
        }}
        selectedMachineId={assignMachineId}
        customersList={customers}
        activeCustomer={activeCustomer}
      />

      <ReplaceOperatorModal
        isOpen={isReplaceOperatorOpen}
        onClose={() => setIsReplaceOperatorOpen(false)}
        onSuccess={() => {
          reloadGlobalEntities();
        }}
        selectedMachineId={replaceMachineId}
        activeCustomer={activeCustomer}
      />

      <CustomerDetailModal
        isOpen={Boolean(detailCustomerId)}
        onClose={() => setDetailCustomerId(null)}
        customerId={detailCustomerId}
        onOpenAddMachine={(custCatId) => {
          setDetailCustomerId(null);
          setAddMachineCustomerId(custCatId);
          setIsAddMachineOpen(true);
        }}
        onNavigateToTab={(tab, filterCustId) => {
          if (filterCustId && customers.length > 0) {
            const match = customers.find((c) => c.id === filterCustId);
            if (match) setActiveCustomer(match);
          }
          setActiveTab(tab);
        }}
      />

      <MachineDetailModal
        isOpen={Boolean(detailMachineId)}
        onClose={() => setDetailMachineId(null)}
        machineId={detailMachineId}
        userRole={currentRole}
        onOpenAssignModal={(mId) => {
          setAssignMachineId(mId);
          setIsAssignOperatorOpen(true);
        }}
        onOpenReplaceModal={(mId) => {
          setReplaceMachineId(mId);
          setIsReplaceOperatorOpen(true);
        }}
      />
    </div>
  );
}
