"use client";

import { UserRole, Customer, Operator } from "@/types";
import {
  ShieldAlert,
  Building,
  UserCheck,
  HardHat,
  Bell,
  ChevronDown,
  RefreshCw,
  Zap,
} from "lucide-react";

interface NavbarProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  customers: Customer[];
  activeCustomer: Customer | null;
  onCustomerChange: (customer: Customer) => void;
  operators: Operator[];
  activeOperator: Operator | null;
  onOperatorChange: (operator: Operator) => void;
  unreadCount: number;
  onToggleNotifications: () => void;
}

export function Navbar({
  currentRole,
  onRoleChange,
  customers,
  activeCustomer,
  onCustomerChange,
  operators,
  activeOperator,
  onOperatorChange,
  unreadCount,
  onToggleNotifications,
}: NavbarProps) {
  const roleIcons = {
    Admin: <ShieldAlert className="w-4 h-4 text-amber-400" />,
    Customer: <Building className="w-4 h-4 text-blue-400" />,
    "Insurance Coordinator": <UserCheck className="w-4 h-4 text-emerald-400" />,
    Operator: <HardHat className="w-4 h-4 text-indigo-400" />,
  };

  const roleColors = {
    Admin: "bg-amber-500/10 text-amber-300 border-amber-500/30",
    Customer: "bg-blue-500/10 text-blue-300 border-blue-500/30",
    "Insurance Coordinator": "bg-emerald-500/10 text-emerald-300 border-emerald-500/30",
    Operator: "bg-indigo-500/10 text-indigo-300 border-indigo-500/30",
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 lg:px-8 py-3">
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Brand Logo & Tag */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 via-amber-600 to-yellow-600 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
            <Zap className="w-6 h-6 fill-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-black tracking-wider text-slate-100 uppercase">
                TITAN <span className="text-amber-400">OEM</span>
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-widest bg-slate-800 text-slate-300 border border-slate-700">
                Fleet OS v3.2
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              Equipment Manufacturer & Fleet Ecosystem Portal
            </p>
          </div>
        </div>

        {/* Dynamic Role Switcher & Context Persona Selector */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Main Role Dropdown Switcher */}
          <div className="flex items-center gap-2 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700/80 shadow-inner">
            <span className="text-xs font-semibold text-slate-400 pl-2 hidden sm:inline">
              Active Role:
            </span>
            <div className="relative">
              <select
                value={currentRole}
                onChange={(e) => onRoleChange(e.target.value as UserRole)}
                className={`appearance-none bg-slate-900 font-bold text-xs rounded-lg px-3 py-2 pr-8 border focus:outline-none cursor-pointer transition ${roleColors[currentRole]}`}
              >
                <option value="Admin" className="bg-slate-900 text-slate-200 font-medium">
                  🛡️ Admin (Equipment Manufacturer)
                </option>
                <option value="Customer" className="bg-slate-900 text-slate-200 font-medium">
                  🏢 Customer (Machine Buying Company)
                </option>
                <option value="Insurance Coordinator" className="bg-slate-900 text-slate-200 font-medium">
                  📋 Insurance Coordinator
                </option>
                <option value="Operator" className="bg-slate-900 text-slate-200 font-medium">
                  🚜 Operator (Machine Driver)
                </option>
              </select>
              <ChevronDown className="w-3.5 h-3.5 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400" />
            </div>
          </div>

          {/* Sub Context Selector for Customer Persona */}
          {currentRole === "Customer" && customers.length > 0 && (
            <div className="flex items-center gap-1.5 bg-blue-950/40 p-1.5 rounded-xl border border-blue-800/60 text-xs">
              <span className="text-slate-400 pl-2 font-medium">Company:</span>
              <select
                value={activeCustomer?.id || ""}
                onChange={(e) => {
                  const found = customers.find((c) => c.id === e.target.value);
                  if (found) onCustomerChange(found);
                }}
                className="bg-slate-900 text-blue-300 font-semibold rounded-lg px-2.5 py-1.5 border border-blue-700/60 focus:outline-none cursor-pointer"
              >
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.companyCode})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Sub Context Selector for Operator Persona */}
          {currentRole === "Operator" && operators.length > 0 && (
            <div className="flex items-center gap-1.5 bg-indigo-950/40 p-1.5 rounded-xl border border-indigo-800/60 text-xs">
              <span className="text-slate-400 pl-2 font-medium">Driver:</span>
              <select
                value={activeOperator?.id || ""}
                onChange={(e) => {
                  const found = operators.find((op) => op.id === e.target.value);
                  if (found) onOperatorChange(found);
                }}
                className="bg-slate-900 text-indigo-300 font-semibold rounded-lg px-2.5 py-1.5 border border-indigo-700/60 focus:outline-none cursor-pointer"
              >
                {operators.map((op) => (
                  <option key={op.id} value={op.id}>
                    {op.name} ({op.policyNumber})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Notification Alert Bell */}
          <button
            onClick={onToggleNotifications}
            className="relative p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-slate-100 rounded-xl border border-slate-700 transition"
            title="View Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black flex items-center justify-center animate-pulse">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
