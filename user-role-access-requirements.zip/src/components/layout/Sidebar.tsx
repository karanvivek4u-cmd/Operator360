"use client";

import { UserRole } from "@/types";
import {
  LayoutDashboard,
  Building2,
  Truck,
  Users,
  Link2,
  Shield,
  Clock,
  BarChart3,
  BrainCircuit,
  Bell,
  Settings,
  User,
  Bot,
  HelpCircle,
} from "lucide-react";

interface SidebarProps {
  currentRole: UserRole;
  activeTab: string;
  onTabChange: (tab: string) => void;
  unreadCount: number;
}

export function Sidebar({ currentRole, activeTab, onTabChange, unreadCount }: SidebarProps) {
  // Navigation item definitions per role
  const adminNav = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "customers", label: "Customers", icon: Building2 },
    { id: "machines", label: "Machines", icon: Truck },
    { id: "operators", label: "Operators", icon: Users },
    { id: "assignments", label: "Assignments", icon: Link2 },
    { id: "benefits", label: "Benefits", icon: Shield },
    { id: "requests", label: "Service Requests", icon: Clock },
    { id: "reports", label: "Reports", icon: BarChart3 },
    { id: "ai-insights", label: "AI Insights", icon: BrainCircuit },
    { id: "notifications", label: "Notifications", icon: Bell, badge: unreadCount },
    { id: "settings", label: "Settings", icon: Settings },
    { id: "profile", label: "Profile", icon: User },
  ];

  const customerNav = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "machines", label: "Machines", icon: Truck },
    { id: "operators", label: "Operators", icon: Users },
    { id: "benefits", label: "Benefits", icon: Shield },
    { id: "requests", label: "Requests", icon: Clock },
    { id: "notifications", label: "Notifications", icon: Bell, badge: unreadCount },
    { id: "profile", label: "Profile", icon: User },
  ];

  const insuranceNav = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "requests", label: "Service Requests", icon: Clock },
    { id: "notifications", label: "Notifications", icon: Bell, badge: unreadCount },
    { id: "profile", label: "Profile", icon: User },
  ];

  const operatorNav = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "benefits", label: "Benefits", icon: Shield },
    { id: "notifications", label: "Notifications", icon: Bell, badge: unreadCount },
    { id: "ai-assistant", label: "AI Assistant", icon: Bot },
    { id: "profile", label: "Profile", icon: User },
  ];

  const navItemsMap = {
    Admin: adminNav,
    Customer: customerNav,
    "Insurance Coordinator": insuranceNav,
    Operator: operatorNav,
  };

  const currentNav = navItemsMap[currentRole] || adminNav;

  return (
    <aside className="w-full md:w-64 bg-slate-900/60 border-b md:border-b-0 md:border-r border-slate-800 shrink-0 p-4">
      <div className="mb-4 hidden md:block">
        <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest px-3">
          {currentRole} Navigation
        </span>
      </div>

      <nav className="flex flex-row md:flex-col overflow-x-auto md:overflow-visible gap-1 pb-2 md:pb-0 scrollbar-none">
        {currentNav.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                isActive
                  ? "bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-800/60"
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${isActive ? "text-slate-950" : "text-slate-400"}`} />
              <span>{item.label}</span>
              {item.badge !== undefined && item.badge > 0 && (
                <span
                  className={`ml-auto px-1.5 py-0.5 rounded-full text-[10px] font-black ${
                    isActive ? "bg-slate-950 text-amber-400" : "bg-amber-500/20 text-amber-300"
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="mt-8 pt-4 border-t border-slate-800/80 hidden md:block">
        <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-800/60 text-slate-400 text-xs space-y-1">
          <div className="font-semibold text-slate-300 flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-amber-400" /> System Guide
          </div>
          <p className="text-[11px] leading-relaxed text-slate-400">
            Switch roles seamlessly at top bar to test multi-tenant workflows.
          </p>
        </div>
      </div>
    </aside>
  );
}
