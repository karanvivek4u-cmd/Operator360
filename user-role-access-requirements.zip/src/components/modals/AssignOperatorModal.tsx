"use client";

import { useState, useEffect } from "react";
import { Machine, Operator, Customer } from "@/types";
import { X, AlertTriangle, UserPlus, Link2, CheckCircle2, Loader2 } from "lucide-react";

interface AssignOperatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  selectedMachineId?: string;
  customersList: Customer[];
  activeCustomer: Customer | null;
}

export function AssignOperatorModal({
  isOpen,
  onClose,
  onSuccess,
  selectedMachineId,
  customersList,
  activeCustomer,
}: AssignOperatorModalProps) {
  const [machines, setMachines] = useState<Machine[]>([]);
  const [operators, setOperators] = useState<Operator[]>([]);
  const [targetMachineId, setTargetMachineId] = useState<string>(selectedMachineId || "");
  const [mode, setMode] = useState<"existing" | "new">("existing");
  const [selectedOperatorId, setSelectedOperatorId] = useState<string>("");

  // New operator form state
  const [newOpName, setNewOpName] = useState("");
  const [newOpMobile, setNewOpMobile] = useState("");
  const [newOpEmail, setNewOpEmail] = useState("");

  const [loading, setLoading] = useState(false);
  const [fetchingData, setFetchingData] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  useEffect(() => {
    if (isOpen) {
      setErrorMsg("");
      setSuccessMsg("");
      fetchData();
    }
  }, [isOpen, activeCustomer]);

  useEffect(() => {
    if (selectedMachineId) {
      setTargetMachineId(selectedMachineId);
    }
  }, [selectedMachineId]);

  const fetchData = async () => {
    setFetchingData(true);
    try {
      const custId = activeCustomer?.id || "";
      const machUrl = custId ? `/api/machines?customerId=${custId}` : "/api/machines";
      const opUrl = custId ? `/api/operators?customerId=${custId}` : "/api/operators";

      const [mRes, oRes] = await Promise.all([fetch(machUrl), fetch(opUrl)]);
      const mData = await mRes.json();
      const oData = await oRes.json();

      if (Array.isArray(mData)) setMachines(mData);
      if (Array.isArray(oData)) setOperators(oData);

      if (selectedMachineId) {
        setTargetMachineId(selectedMachineId);
      } else if (Array.isArray(mData) && mData.length > 0) {
        setTargetMachineId(mData[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setFetchingData(false);
    }
  };

  if (!isOpen) return null;

  const currentMachine = machines.find((m) => m.id === targetMachineId);
  const isMaxLimit = currentMachine ? (currentMachine.activeOperatorCount || 0) >= 3 : false;

  // Operators eligible for assignment (not currently active on any machine)
  const availableOperators = operators.filter((op) => !op.assignedMachine);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (!targetMachineId) {
      setErrorMsg("Please select a machine");
      return;
    }

    if (isMaxLimit) {
      setErrorMsg("This machine has reached the maximum of 3 active operators.");
      return;
    }

    setLoading(true);

    try {
      let finalOperatorId = selectedOperatorId;

      // If customer is creating a new operator first
      if (mode === "new") {
        if (!newOpName || !newOpMobile) {
          setErrorMsg("Operator Name and Mobile Number are required");
          setLoading(false);
          return;
        }

        const createOpRes = await fetch("/api/operators", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: newOpName,
            mobile: newOpMobile,
            email: newOpEmail,
            customerId: activeCustomer?.id || currentMachine?.customerId,
            requesterRole: "Customer", // Enforce Customer creator rule
          }),
        });

        const opData = await createOpRes.json();
        if (!createOpRes.ok) {
          throw new Error(opData.error || "Failed to create operator");
        }

        finalOperatorId = opData.operator.id;
      } else {
        if (!finalOperatorId) {
          setErrorMsg("Please select an operator to assign");
          setLoading(false);
          return;
        }
      }

      // Perform assignment
      const assignRes = await fetch("/api/assignments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          machineId: targetMachineId,
          operatorId: finalOperatorId,
          notes: "Assigned by Customer",
        }),
      });

      const assignData = await assignRes.json();
      if (!assignRes.ok) {
        throw new Error(assignData.error || "Failed to assign operator");
      }

      setSuccessMsg("Operator successfully assigned to machine!");
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1200);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to assign operator");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-400">
            <Link2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">Assign Operator to Machine</h2>
            <p className="text-xs text-slate-400">
              {activeCustomer ? activeCustomer.name : "Select machine & operator for shift assignment"}
            </p>
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-xl text-sm flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded-xl text-sm flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {fetchingData ? (
          <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
            <p className="text-sm">Loading machine fleet and workforce data...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Machine Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                1. Select Target Machine
              </label>
              <select
                value={targetMachineId}
                onChange={(e) => setTargetMachineId(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 text-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500"
              >
                <option value="">-- Choose Machine --</option>
                {machines.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.modelNumber} ({m.serialNumber}) — Active Ops: {m.activeOperatorCount || 0}/3
                  </option>
                ))}
              </select>
            </div>

            {/* Warning if 3/3 capacity reached */}
            {currentMachine && (
              <div
                className={`p-4 rounded-xl border flex items-start gap-3 ${
                  isMaxLimit
                    ? "bg-rose-950/40 border-rose-800/60 text-rose-200"
                    : "bg-slate-800/50 border-slate-700/60 text-slate-300"
                }`}
              >
                <AlertTriangle
                  className={`w-5 h-5 shrink-0 mt-0.5 ${
                    isMaxLimit ? "text-rose-400 animate-pulse" : "text-amber-400"
                  }`}
                />
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider">
                    Operator Capacity Status
                  </div>
                  <div className="text-sm font-medium mt-0.5">
                    Currently Assigned:{" "}
                    <span className="font-bold text-amber-400">
                      {currentMachine.activeOperatorCount || 0} / 3
                    </span>{" "}
                    active drivers
                  </div>
                  {isMaxLimit && (
                    <p className="text-xs text-rose-300 mt-1">
                      <strong>Business Rule Enforcement:</strong> Machine cannot have more than three
                      active operators. To add another operator, please raise a Replacement Request
                      to swap out an existing operator.
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Operator Option Tabs */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                2. Select Operator Source
              </label>
              <div className="grid grid-cols-2 gap-2 bg-slate-800/60 p-1 rounded-xl border border-slate-700/60 mb-3">
                <button
                  type="button"
                  onClick={() => setMode("existing")}
                  className={`py-2 text-xs font-medium rounded-lg transition ${
                    mode === "existing"
                      ? "bg-amber-500 text-slate-950 shadow font-semibold"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  Select Existing Operator
                </button>
                <button
                  type="button"
                  onClick={() => setMode("new")}
                  className={`py-2 text-xs font-medium rounded-lg transition ${
                    mode === "new"
                      ? "bg-amber-500 text-slate-950 shadow font-semibold"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  + Create New Operator
                </button>
              </div>

              {mode === "existing" ? (
                <div>
                  <select
                    value={selectedOperatorId}
                    onChange={(e) => setSelectedOperatorId(e.target.value)}
                    disabled={isMaxLimit}
                    className="w-full bg-slate-800/80 border border-slate-700 text-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <option value="">-- Select Available Operator --</option>
                    {availableOperators.map((op) => (
                      <option key={op.id} value={op.id}>
                        {op.name} ({op.mobile}) - Policy: {op.policyNumber}
                      </option>
                    ))}
                  </select>
                  {availableOperators.length === 0 && (
                    <p className="text-xs text-amber-400 mt-2">
                      No unassigned operators available. Switch to "Create New Operator" to add a driver.
                    </p>
                  )}
                </div>
              ) : (
                <div className="space-y-3 p-4 bg-slate-800/40 border border-slate-700/60 rounded-xl">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Full Name *</label>
                    <input
                      type="text"
                      placeholder="e.g. Liam Henderson"
                      value={newOpName}
                      onChange={(e) => setNewOpName(e.target.value)}
                      disabled={isMaxLimit}
                      className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 disabled:opacity-50"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Mobile Phone *</label>
                      <input
                        type="text"
                        placeholder="+1 (555) 000-0000"
                        value={newOpMobile}
                        onChange={(e) => setNewOpMobile(e.target.value)}
                        disabled={isMaxLimit}
                        className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 disabled:opacity-50"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Email Address</label>
                      <input
                        type="email"
                        placeholder="driver@company.com"
                        value={newOpEmail}
                        onChange={(e) => setNewOpEmail(e.target.value)}
                        disabled={isMaxLimit}
                        className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500 disabled:opacity-50"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-xs font-semibold text-slate-300 hover:text-slate-100 hover:bg-slate-800 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading || isMaxLimit}
                className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl shadow-lg transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Assigning...</span>
                  </>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Assign Operator Now</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
