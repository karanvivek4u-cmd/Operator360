"use client";

import { useState, useEffect } from "react";
import { Machine, Operator, Customer } from "@/types";
import { X, RefreshCw, AlertCircle, CheckCircle2, ShieldCheck, Loader2 } from "lucide-react";

interface ReplaceOperatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  selectedMachineId?: string;
  activeCustomer: Customer | null;
}

export function ReplaceOperatorModal({
  isOpen,
  onClose,
  onSuccess,
  selectedMachineId,
  activeCustomer,
}: ReplaceOperatorModalProps) {
  const [machines, setMachines] = useState<Machine[]>([]);
  const [operators, setOperators] = useState<Operator[]>([]);
  
  const [machineId, setMachineId] = useState<string>(selectedMachineId || "");
  const [oldOperatorId, setOldOperatorId] = useState<string>("");
  const [newOperatorId, setNewOperatorId] = useState<string>("");
  const [reason, setReason] = useState<string>("");
  const [remarks, setRemarks] = useState<string>("");

  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  useEffect(() => {
    if (isOpen) {
      setErrorMsg("");
      setSuccessMsg("");
      setReason("Shift Rotation & Driver Medical Relief");
      fetchData();
    }
  }, [isOpen, activeCustomer]);

  useEffect(() => {
    if (selectedMachineId) {
      setMachineId(selectedMachineId);
    }
  }, [selectedMachineId]);

  const fetchData = async () => {
    setFetching(true);
    try {
      const custId = activeCustomer?.id || "";
      const machUrl = custId ? `/api/machines?customerId=${custId}` : "/api/machines";
      const opUrl = custId ? `/api/operators?customerId=${custId}` : "/api/operators";

      const [mRes, oRes] = await Promise.all([fetch(machUrl), fetch(opUrl)]);
      const mData = await mRes.json();
      const oData = await oRes.json();

      if (Array.isArray(mData)) setMachines(mData);
      if (Array.isArray(oData)) setOperators(oData);

      if (selectedMachineId) {
        setMachineId(selectedMachineId);
      } else if (Array.isArray(mData) && mData.length > 0) {
        setMachineId(mData[0].id);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setFetching(false);
    }
  };

  if (!isOpen) return null;

  const currentMachine = machines.find((m) => m.id === machineId);
  const activeOperatorsOnMachine = currentMachine?.activeOperators || [];

  // Candidate replacement operators (operators belonging to customer not currently on this machine)
  const availableNewOperators = operators.filter(
    (op) => op.id !== oldOperatorId && (!op.assignedMachine || op.assignedMachine.id !== machineId)
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (!machineId || !oldOperatorId || !reason) {
      setErrorMsg("Please select Machine, Old Operator to replace, and enter Reason.");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/service-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerId: activeCustomer?.id || currentMachine?.customerId,
          machineId,
          oldOperatorId,
          newOperatorId: newOperatorId || null,
          reason,
          remarks,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to submit replacement request");
      }

      setSuccessMsg(
        "Replacement Request submitted! Status is now 'Pending Insurance Approval'. Customer cannot assign new operator until Insurance & Admin fully approve."
      );

      setTimeout(() => {
        onSuccess();
        onClose();
      }, 2000);
    } catch (err: any) {
      setErrorMsg(err.message || "Failed to submit replacement request");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-xl text-blue-400">
            <RefreshCw className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-100">Raise Operator Replacement Request</h2>
            <p className="text-xs text-slate-400">
              Requires Insurance Coordinator approval followed by OEM Admin approval
            </p>
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 rounded-xl text-sm flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded-xl text-sm flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
            <span className="text-xs leading-relaxed">{successMsg}</span>
          </div>
        )}

        {fetching ? (
          <div className="py-12 flex flex-col items-center justify-center gap-3 text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
            <p className="text-sm">Fetching equipment and active operator status...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Machine Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Select Machine *
              </label>
              <select
                value={machineId}
                onChange={(e) => {
                  setMachineId(e.target.value);
                  setOldOperatorId("");
                }}
                className="w-full bg-slate-800/80 border border-slate-700 text-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="">-- Choose Machine --</option>
                {machines.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.modelNumber} ({m.serialNumber}) — {m.activeOperatorCount || 0} active drivers
                  </option>
                ))}
              </select>
            </div>

            {/* Old Operator Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Old Operator (To be Replaced) *
              </label>
              <select
                value={oldOperatorId}
                onChange={(e) => setOldOperatorId(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 text-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="">-- Select Active Operator on this Machine --</option>
                {activeOperatorsOnMachine.map((op) => (
                  <option key={op.id} value={op.id}>
                    {op.name} ({op.mobile}) — Policy: {op.policyNumber}
                  </option>
                ))}
              </select>
              {activeOperatorsOnMachine.length === 0 && (
                <p className="text-xs text-amber-400 mt-1">
                  No active operators currently assigned to this machine.
                </p>
              )}
            </div>

            {/* New Operator Selection (Optional) */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                New Proposed Operator (Optional)
              </label>
              <select
                value={newOperatorId}
                onChange={(e) => setNewOperatorId(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 text-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-blue-500"
              >
                <option value="">-- Select Replacement Candidate (Or leave blank) --</option>
                {availableNewOperators.map((op) => (
                  <option key={op.id} value={op.id}>
                    {op.name} ({op.mobile}) - Policy: {op.policyNumber}
                  </option>
                ))}
              </select>
            </div>

            {/* Reason */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Replacement Reason *
              </label>
              <input
                type="text"
                placeholder="e.g. Medical leave, Shift rotation, Relocation to another site"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 text-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Remarks */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1">
                Remarks / Fleet Manager Notes
              </label>
              <textarea
                rows={2}
                placeholder="Additional details for Insurance risk clearance and OEM Admin..."
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                className="w-full bg-slate-800/80 border border-slate-700 text-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Workflow Notice */}
            <div className="p-3 bg-blue-950/40 border border-blue-800/60 rounded-xl text-blue-200 text-xs flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <strong>Workflow Enforcement:</strong> Upon submission, the request status will set to{" "}
                <span className="text-amber-300 font-semibold font-mono">Pending Insurance Approval</span>.
                Insurance Coordinator must approve first before OEM Admin can issue final approval.
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-slate-100 hover:bg-slate-800 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading || !oldOperatorId}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-slate-100 text-xs font-bold rounded-xl shadow-lg transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Submitting Request...</span>
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4" />
                    <span>Submit Replacement Request</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
