"use client";

import { useState, useEffect } from "react";
import { Machine, Customer, Operator, Assignment } from "@/types";
import { X, Truck, Building2, Users, FileText, ShieldCheck, Clock, Loader2 } from "lucide-react";

interface MachineDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  machineId: string | null;
  onOpenAssignModal?: (machineId: string) => void;
  onOpenReplaceModal?: (machineId: string) => void;
  userRole?: string;
}

export function MachineDetailModal({
  isOpen,
  onClose,
  machineId,
  onOpenAssignModal,
  onOpenReplaceModal,
  userRole,
}: MachineDetailModalProps) {
  const [data, setData] = useState<{
    machine: Machine;
    customer: Customer;
    activeOperators: (Operator & { assignmentId: string; assignedAt: string })[];
    activeCount: number;
    history: (Assignment & { operatorName: string; operatorMobile: string })[];
  } | null>(null);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isOpen && machineId) {
      fetchMachineDetails(machineId);
    }
  }, [isOpen, machineId]);

  const fetchMachineDetails = async (id: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/machines/${id}`);
      const result = await res.json();
      if (res.ok) {
        setData(result);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !machineId) return null;

  const isMaxLimit = (data?.activeCount || 0) >= 3;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl max-w-3xl w-full p-6 shadow-2xl relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {loading || !data ? (
          <div className="py-20 flex flex-col items-center justify-center gap-3 text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
            <p className="text-sm">Retrieving telematics, warranty & active operator telemetry...</p>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 pb-4 mb-4 pr-8">
              <div className="flex items-center gap-4">
                <div className="p-3.5 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-amber-400">
                  <Truck className="w-7 h-7" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-100">{data.machine.modelNumber}</h2>
                  <p className="text-xs text-slate-400 mt-0.5 font-mono">
                    SN: <span className="text-amber-300 font-semibold">{data.machine.serialNumber}</span> |{" "}
                    Category: {data.machine.category} | Year: {data.machine.manufactureYear}
                  </p>
                </div>
              </div>

              {/* Action buttons if Customer or Admin */}
              {(userRole === "Customer" || userRole === "Admin") && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onClose();
                      if (onOpenAssignModal) onOpenAssignModal(data.machine.id);
                    }}
                    disabled={isMaxLimit}
                    className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition shadow disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Assign Operator
                  </button>
                  <button
                    onClick={() => {
                      onClose();
                      if (onOpenReplaceModal) onOpenReplaceModal(data.machine.id);
                    }}
                    className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl transition shadow"
                  >
                    Raise Replacement
                  </button>
                </div>
              )}
            </div>

            {/* Content Scrollable */}
            <div className="flex-1 overflow-y-auto pr-2 space-y-5">
              {/* Customer Ownership & Specs */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-800/40 border border-slate-700/50 rounded-xl space-y-2">
                  <h3 className="text-xs font-semibold uppercase text-slate-400 flex items-center gap-1.5">
                    <Building2 className="w-4 h-4 text-amber-400" /> Company Owner
                  </h3>
                  <div className="text-sm font-bold text-slate-200">{data.customer.name}</div>
                  <div className="text-xs text-slate-400 font-mono">
                    Code: {data.customer.companyCode} | Contact: {data.customer.email}
                  </div>
                </div>

                <div className="p-4 bg-slate-800/40 border border-slate-700/50 rounded-xl space-y-2">
                  <h3 className="text-xs font-semibold uppercase text-slate-400 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" /> Warranty & Status
                  </h3>
                  <div className="flex items-center gap-3">
                    <span className="px-2.5 py-1 rounded text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {data.machine.status}
                    </span>
                    <span className="text-xs text-slate-300">
                      Expires: <strong className="text-slate-100">{data.machine.warrantyExpiry}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Hardware Specifications */}
              <div className="p-4 bg-slate-800/30 border border-slate-700/40 rounded-xl">
                <h3 className="text-xs font-semibold uppercase text-slate-400 mb-2 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-indigo-400" /> Equipment Specifications
                </h3>
                <div className="text-xs text-slate-300 font-mono bg-slate-900/60 p-3 rounded-lg border border-slate-800">
                  {typeof data.machine.specifications === "string"
                    ? data.machine.specifications
                    : JSON.stringify(data.machine.specifications, null, 2)}
                </div>
              </div>

              {/* Assigned Active Operators (Max 3 Rule Enforcement View) */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-semibold uppercase text-slate-400 flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-amber-400" /> Currently Assigned Operators
                  </h3>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                      isMaxLimit
                        ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                        : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                    }`}
                  >
                    Active Drivers: {data.activeCount} / 3 Max Limit
                  </span>
                </div>

                {data.activeOperators.length === 0 ? (
                  <div className="p-4 bg-slate-800/30 border border-slate-700/40 rounded-xl text-center text-slate-400 text-xs">
                    No active operators currently assigned to this unit.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {data.activeOperators.map((op) => (
                      <div
                        key={op.id}
                        className="p-3 bg-slate-800/80 border border-slate-700/80 rounded-xl text-slate-200"
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <img
                            src={op.photoUrl}
                            alt={op.name}
                            className="w-8 h-8 rounded-full object-cover border border-slate-600"
                          />
                          <div>
                            <div className="text-xs font-bold text-slate-100">{op.name}</div>
                            <div className="text-[10px] text-slate-400">{op.mobile}</div>
                          </div>
                        </div>
                        <div className="text-[10px] text-indigo-300 font-mono">
                          Policy: {op.policyNumber}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Assignment History */}
              <div>
                <h3 className="text-xs font-semibold uppercase text-slate-400 mb-3 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-cyan-400" /> Operator Assignment History
                </h3>
                {data.history.length === 0 ? (
                  <div className="text-xs text-slate-500 italic">No historical re-assignment logs available.</div>
                ) : (
                  <div className="space-y-2">
                    {data.history.map((h) => (
                      <div
                        key={h.id}
                        className="p-3 bg-slate-800/40 border border-slate-700/40 rounded-xl flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-semibold text-slate-200">{h.operatorName}</span>
                          <span className="text-slate-400 text-[11px] ml-2 font-mono">
                            ({h.operatorMobile})
                          </span>
                          <div className="text-[10px] text-slate-400 mt-0.5">{h.notes}</div>
                        </div>
                        <div className="text-right">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              h.status === "Replaced"
                                ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                                : "bg-slate-700 text-slate-300"
                            }`}
                          >
                            {h.status}
                          </span>
                          <div className="text-[10px] text-slate-500 mt-0.5 font-mono">
                            {new Date(h.assignedAt).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
