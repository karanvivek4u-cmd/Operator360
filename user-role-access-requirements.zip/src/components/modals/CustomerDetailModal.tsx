"use client";

import { useState, useEffect } from "react";
import { Customer, Machine, Operator, ServiceRequest } from "@/types";
import {
  X,
  Building2,
  Wallet,
  Truck,
  Users,
  Shield,
  Plus,
  Clock,
  ExternalLink,
  ChevronRight,
  Loader2,
} from "lucide-react";

interface CustomerDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerId: string | null;
  onOpenAddMachine?: (customerId: string) => void;
  onNavigateToTab?: (tab: string, filterCustomerId?: string) => void;
}

export function CustomerDetailModal({
  isOpen,
  onClose,
  customerId,
  onOpenAddMachine,
  onNavigateToTab,
}: CustomerDetailModalProps) {
  const [data, setData] = useState<{
    customer: Customer;
    machines: Machine[];
    operators: Operator[];
    requests: ServiceRequest[];
  } | null>(null);

  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"overview" | "machines" | "operators" | "timeline">("overview");

  useEffect(() => {
    if (isOpen && customerId) {
      fetchCustomerDetails(customerId);
    }
  }, [isOpen, customerId]);

  const fetchCustomerDetails = async (id: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/customers/${id}`);
      const result = await res.json();
      if (res.ok) {
        setData(result);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !customerId) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl max-w-4xl w-full p-6 shadow-2xl relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-100 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {loading || !data ? (
          <div className="py-20 flex flex-col items-center justify-center gap-3 text-slate-400">
            <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
            <p className="text-sm">Fetching detailed customer profile & asset registry...</p>
          </div>
        ) : (
          <>
            {/* Header info */}
            <div className="flex flex-wrap items-start justify-between gap-4 border-b border-slate-800 pb-5 mb-5 pr-8">
              <div className="flex items-center gap-4">
                <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl text-amber-400">
                  <Building2 className="w-8 h-8" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-2xl font-bold text-slate-100">{data.customer.name}</h2>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {data.customer.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Code: <span className="font-mono text-slate-200">{data.customer.companyCode}</span> | Email:{" "}
                    <span className="text-slate-200">{data.customer.email}</span>
                  </p>
                </div>
              </div>

              {/* Action Buttons required by spec */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    if (onOpenAddMachine) onOpenAddMachine(data.customer.id);
                  }}
                  className="px-3 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Machine</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    if (onNavigateToTab) onNavigateToTab("operators", data.customer.id);
                  }}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition flex items-center gap-1.5"
                >
                  <Users className="w-4 h-4 text-indigo-400" />
                  <span>View Operators</span>
                </button>
                <button
                  onClick={() => {
                    onClose();
                    if (onNavigateToTab) onNavigateToTab("requests", data.customer.id);
                  }}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition flex items-center gap-1.5"
                >
                  <Clock className="w-4 h-4 text-cyan-400" />
                  <span>View Requests</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
              <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl">
                <div className="text-xs text-slate-400 flex items-center gap-1">
                  <Wallet className="w-3.5 h-3.5 text-emerald-400" /> Loyalty Wallet
                </div>
                <div className="text-lg font-bold text-emerald-400 mt-1">
                  ${data.customer.walletBalance.toLocaleString()}
                </div>
              </div>
              <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl">
                <div className="text-xs text-slate-400 flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-amber-400" /> Machines Owned
                </div>
                <div className="text-lg font-bold text-amber-400 mt-1">{data.machines.length} Units</div>
              </div>
              <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl">
                <div className="text-xs text-slate-400 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-indigo-400" /> Active Operators
                </div>
                <div className="text-lg font-bold text-indigo-400 mt-1">{data.operators.length} Drivers</div>
              </div>
              <div className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl">
                <div className="text-xs text-slate-400 flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5 text-blue-400" /> Active Service Claims
                </div>
                <div className="text-lg font-bold text-blue-400 mt-1">{data.requests.length} Requests</div>
              </div>
            </div>

            {/* Tabs */}
            <div className="flex items-center gap-2 border-b border-slate-800 mb-4 text-xs font-semibold">
              <button
                onClick={() => setActiveTab("overview")}
                className={`pb-2.5 px-3 border-b-2 transition ${
                  activeTab === "overview"
                    ? "border-amber-500 text-amber-400"
                    : "border-transparent text-slate-400 hover:text-slate-200"
                }`}
              >
                Overview & Benefits
              </button>
              <button
                onClick={() => setActiveTab("machines")}
                className={`pb-2.5 px-3 border-b-2 transition ${
                  activeTab === "machines"
                    ? "border-amber-500 text-amber-400"
                    : "border-transparent text-slate-400 hover:text-slate-200"
                }`}
              >
                Purchased Machines ({data.machines.length})
              </button>
              <button
                onClick={() => setActiveTab("operators")}
                className={`pb-2.5 px-3 border-b-2 transition ${
                  activeTab === "operators"
                    ? "border-amber-500 text-amber-400"
                    : "border-transparent text-slate-400 hover:text-slate-200"
                }`}
              >
                Registered Operators ({data.operators.length})
              </button>
            </div>

            {/* Tab Body */}
            <div className="flex-1 overflow-y-auto pr-2 space-y-4">
              {activeTab === "overview" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-800/40 border border-slate-700/50 rounded-xl space-y-3">
                    <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-amber-400" /> Corporate Details
                    </h3>
                    <div className="text-xs space-y-2 text-slate-300">
                      <div>
                        <span className="text-slate-400">Address:</span> {data.customer.address}
                      </div>
                      <div>
                        <span className="text-slate-400">Phone:</span> {data.customer.phone}
                      </div>
                      <div>
                        <span className="text-slate-400">Tier Status:</span> {data.customer.category}
                      </div>
                      <div>
                        <span className="text-slate-400">Account Status:</span>{" "}
                        <span className="text-emerald-400 font-semibold">{data.customer.status}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-slate-800/40 border border-slate-700/50 rounded-xl space-y-3">
                    <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                      <Shield className="w-4 h-4 text-blue-400" /> Active Corporate Benefits
                    </h3>
                    <ul className="text-xs text-slate-300 space-y-2">
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        <span>$500,000 Group Safety Insurance per operator</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        <span>24/7 Priority Emergency Maintenance Dispatch</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        <span>Max 3-Operator Allocation per Heavy Equipment unit</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        <span>Loyalty Credit cashback on warranty service renewals</span>
                      </li>
                    </ul>
                  </div>
                </div>
              )}

              {activeTab === "machines" && (
                <div className="space-y-3">
                  {data.machines.length === 0 ? (
                    <div className="text-center py-8 text-slate-400 text-xs">
                      No machines registered for this company yet.
                    </div>
                  ) : (
                    data.machines.map((m) => (
                      <div
                        key={m.id}
                        className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl flex items-center justify-between gap-3 hover:border-slate-600 transition"
                      >
                        <div>
                          <div className="text-sm font-bold text-slate-200">{m.modelNumber}</div>
                          <div className="text-xs text-slate-400 font-mono">
                            SN: {m.serialNumber} | Category: {m.category}
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            {m.status}
                          </span>
                          <div className="text-[11px] text-slate-400 mt-1">
                            Warranty till: {m.warrantyExpiry}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {activeTab === "operators" && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {data.operators.length === 0 ? (
                    <div className="col-span-2 text-center py-8 text-slate-400 text-xs">
                      No operators created under this customer yet.
                    </div>
                  ) : (
                    data.operators.map((op) => (
                      <div
                        key={op.id}
                        className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-xl flex items-center gap-3"
                      >
                        <img
                          src={op.photoUrl}
                          alt={op.name}
                          className="w-10 h-10 rounded-full object-cover border border-slate-600"
                        />
                        <div>
                          <div className="text-sm font-bold text-slate-200">{op.name}</div>
                          <div className="text-xs text-slate-400">{op.mobile}</div>
                          <div className="text-[10px] font-mono text-indigo-400 mt-0.5">
                            Policy: {op.policyNumber}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
