"use client";

import { useState, useEffect } from "react";
import { ServiceRequest, NotificationItem, Operator } from "@/types";
import {
  UserCheck,
  Clock,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Bell,
  User,
  Eye,
  FileText,
  AlertCircle,
  Loader2,
} from "lucide-react";

interface InsuranceViewsProps {
  activeTab: string;
  onSelectOperator?: (op: Operator) => void;
}

export function InsuranceViews({ activeTab, onSelectOperator }: InsuranceViewsProps) {
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Selected request details modal
  const [selectedReq, setSelectedReq] = useState<ServiceRequest | null>(null);
  const [insuranceNotes, setInsuranceNotes] = useState("");

  useEffect(() => {
    loadInsuranceData();
  }, [activeTab]);

  const loadInsuranceData = async () => {
    setLoading(true);
    try {
      const [rRes, nRes] = await Promise.all([
        fetch("/api/service-requests"),
        fetch("/api/notifications?targetRole=Insurance"),
      ]);

      const rData = await rRes.json();
      const nData = await nRes.json();

      if (Array.isArray(rData)) setRequests(rData);
      if (Array.isArray(nData)) setNotifications(nData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleInsuranceApprove = async (id: string) => {
    try {
      const res = await fetch(`/api/service-requests/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "insurance_approve",
          notes: insuranceNotes || "Compliance verified & approved by Insurance Coordinator",
        }),
      });

      if (res.ok) {
        setSelectedReq(null);
        setInsuranceNotes("");
        loadInsuranceData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleInsuranceReject = async (id: string) => {
    try {
      const res = await fetch(`/api/service-requests/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "insurance_reject",
          notes: insuranceNotes || "Rejected due to policy non-compliance during risk review",
        }),
      });

      if (res.ok) {
        setSelectedReq(null);
        setInsuranceNotes("");
        loadInsuranceData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (loading) {
    return (
      <div className="p-12 flex flex-col items-center justify-center gap-3 text-slate-400">
        <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
        <p className="text-sm font-medium">Connecting to Apex Shield Assurance Underwriting Portal...</p>
      </div>
    );
  }

  const pendingInsuranceRequests = requests.filter((r) => r.status === "Pending Insurance Approval");
  const approvedTodayCount = requests.filter(
    (r) => r.status === "Pending Admin Approval" || r.status === "Approved"
  ).length;
  const rejectedTodayCount = requests.filter((r) => r.status === "Rejected").length;

  // 1. DASHBOARD VIEW
  if (activeTab === "dashboard") {
    return (
      <div className="space-y-6">
        {/* Banner */}
        <div className="p-6 bg-gradient-to-r from-emerald-950/50 via-slate-900 to-slate-900 border border-emerald-500/30 rounded-2xl flex items-center justify-between shadow-xl">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4" /> Apex Shield Underwriting Portal
            </div>
            <h1 className="text-2xl font-black text-slate-100 mt-1">Insurance Coordinator Control</h1>
            <p className="text-xs text-slate-400 mt-1">
              Review driver safety clearance, verify $500,000 policy eligibility, and issue underwriting approvals.
            </p>
          </div>
        </div>

        {/* Insurance Metrics Row per Spec: Pending Requests, Approved Today, Rejected Today, Recent Requests */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Pending Claims Review <Clock className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-3xl font-black text-amber-400 mt-2">
              {pendingInsuranceRequests.length}
            </div>
            <div className="text-[11px] text-amber-300 mt-1">Requires Insurance Approval</div>
          </div>

          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Approved Requests <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-3xl font-black text-emerald-400 mt-2">{approvedTodayCount}</div>
            <div className="text-[11px] text-slate-400 mt-1">Passed Underwriting Clearance</div>
          </div>

          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Rejected Requests <XCircle className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-3xl font-black text-rose-400 mt-2">{rejectedTodayCount}</div>
            <div className="text-[11px] text-slate-400 mt-1">Declined Policy Submissions</div>
          </div>
        </div>

        {/* Recent Requests List */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" /> Action Queue & Recent Claims
          </h3>

          <div className="space-y-3">
            {requests.length === 0 ? (
              <div className="text-xs text-slate-500 italic p-4 text-center">No service requests found.</div>
            ) : (
              requests.map((req) => (
                <div
                  key={req.id}
                  className="p-4 bg-slate-800/40 border border-slate-700/50 rounded-xl flex flex-wrap items-center justify-between gap-4 hover:border-slate-600 transition"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-emerald-400">REQ-{req.id}</span>
                      <span
                        className={`px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                          req.status === "Pending Insurance Approval"
                            ? "bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse"
                            : req.status === "Pending Admin Approval"
                            ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30"
                            : req.status === "Approved"
                            ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                            : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>
                    <div className="text-sm font-bold text-slate-100 mt-1">
                      {req.machineModel} ({req.machineSerial})
                    </div>
                    <div className="text-xs text-slate-400">Company: {req.customerName}</div>
                  </div>

                  <div className="flex items-center gap-2">
                    {req.status === "Pending Insurance Approval" ? (
                      <>
                        <button
                          onClick={() => handleInsuranceApprove(req.id)}
                          className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" /> Approve Insurance
                        </button>
                        <button
                          onClick={() => handleInsuranceReject(req.id)}
                          className="px-3 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1"
                        >
                          <XCircle className="w-3.5 h-3.5" /> Reject Insurance
                        </button>
                      </>
                    ) : (
                      <span className="text-xs text-slate-400 italic">Insurance Action Completed</span>
                    )}
                    <button
                      onClick={() => setSelectedReq(req)}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition"
                    >
                      Inspect
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  }

  // 2. SERVICE REQUESTS TAB VIEW
  if (activeTab === "requests") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Service Requests Clearance Desk</h1>
          <p className="text-xs text-slate-400">
            Verify driver replacement eligibility and trigger OEM Admin final workflow
          </p>
        </div>

        <div className="space-y-4">
          {requests.map((req) => (
            <div key={req.id} className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <span className="font-mono text-xs font-bold text-emerald-400">REQ-{req.id}</span>
                  <h3 className="text-base font-bold text-slate-100 mt-1">{req.machineModel}</h3>
                  <p className="text-xs text-slate-400">Customer: {req.customerName}</p>
                </div>
                <span
                  className={`px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                    req.status === "Pending Insurance Approval"
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                  }`}
                >
                  {req.status}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3 bg-slate-800/40 rounded-xl border border-slate-800 text-xs">
                <div>
                  Old Operator: <strong className="text-rose-300">{req.oldOperator?.name || "Driver"}</strong>
                </div>
                <div>
                  New Proposed Operator:{" "}
                  <strong className="text-emerald-300">{req.newOperator?.name || "Pending Onboarding"}</strong>
                </div>
                <div className="col-span-2">Reason: {req.reason}</div>
              </div>

              {req.status === "Pending Insurance Approval" && (
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                  <button
                    onClick={() => handleInsuranceApprove(req.id)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Approve Insurance
                  </button>
                  <button
                    onClick={() => handleInsuranceReject(req.id)}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5"
                  >
                    <XCircle className="w-4 h-4" /> Reject Insurance
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Selected Req Detail Modal */}
        {selectedReq && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-4">
              <h3 className="text-lg font-bold">Insurance Risk Assessment REQ-{selectedReq.id}</h3>
              <div className="text-xs space-y-2 bg-slate-800/50 p-3 rounded-xl border border-slate-700">
                <div>Machine: {selectedReq.machineModel} ({selectedReq.machineSerial})</div>
                <div>Old Operator: {selectedReq.oldOperator?.name}</div>
                <div>New Operator: {selectedReq.newOperator?.name || "None Specified"}</div>
                <div>Reason: {selectedReq.reason}</div>
                <div>Remarks: {selectedReq.remarks || "No additional remarks."}</div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  Underwriting Clearance Notes
                </label>
                <textarea
                  rows={2}
                  value={insuranceNotes}
                  onChange={(e) => setInsuranceNotes(e.target.value)}
                  placeholder="Enter policy verification notes for OEM Admin..."
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  onClick={() => setSelectedReq(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-slate-100"
                >
                  Close
                </button>
                {selectedReq.status === "Pending Insurance Approval" && (
                  <>
                    <button
                      onClick={() => handleInsuranceReject(selectedReq.id)}
                      className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl"
                    >
                      Reject
                    </button>
                    <button
                      onClick={() => handleInsuranceApprove(selectedReq.id)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl"
                    >
                      Approve Insurance
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // 3. NOTIFICATIONS & PROFILE
  return (
    <div className="space-y-6">
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
        <h1 className="text-xl font-bold text-slate-100">Apex Shield Assurance Underwriting Desk</h1>
        <p className="text-xs text-slate-400">Official OEM Equipment Driver Insurance Coordinator</p>
      </div>
    </div>
  );
}
