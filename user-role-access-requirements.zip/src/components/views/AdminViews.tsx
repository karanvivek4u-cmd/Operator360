"use client";

import { useState, useEffect } from "react";
import {
  Customer,
  Machine,
  Operator,
  Assignment,
  ServiceRequest,
  NotificationItem,
  ActivityLog,
  AIInsight,
} from "@/types";
import {
  Building2,
  Truck,
  Users,
  Shield,
  Clock,
  Wallet,
  Plus,
  Search,
  Eye,
  Edit3,
  UserCheck,
  UserX,
  TrendingUp,
  BrainCircuit,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  FileText,
  Settings,
  User,
  Filter,
  RefreshCw,
  Zap,
  BarChart3,
  Loader2,
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
} from "recharts";

interface AdminViewsProps {
  activeTab: string;
  onOpenAddCustomer: () => void;
  onOpenAddMachine: () => void;
  onSelectCustomer: (id: string) => void;
  onSelectMachine: (id: string) => void;
  onSelectOperator: (op: Operator) => void;
}

export function AdminViews({
  activeTab,
  onOpenAddCustomer,
  onOpenAddMachine,
  onSelectCustomer,
  onSelectMachine,
  onSelectOperator,
}: AdminViewsProps) {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [operators, setOperators] = useState<Operator[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [reportsData, setReportsData] = useState<any>(null);
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  const [loading, setLoading] = useState(true);

  // Search and filter states
  const [custSearch, setCustSearch] = useState("");
  const [machFilterCust, setMachFilterCust] = useState("");
  const [opSearch, setOpSearch] = useState("");
  const [opCustomerFilter, setOpCustomerFilter] = useState("");
  const [requestStatusFilter, setRequestStatusFilter] = useState("All");

  useEffect(() => {
    loadAllAdminData();
  }, [activeTab]);

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      const [cRes, mRes, oRes, aRes, rRes, repRes, iRes, actRes, nRes] = await Promise.all([
        fetch("/api/customers"),
        fetch("/api/machines"),
        fetch("/api/operators"),
        fetch("/api/assignments"),
        fetch("/api/service-requests"),
        fetch("/api/reports"),
        fetch("/api/ai-insights"),
        fetch("/api/activity-logs"),
        fetch("/api/notifications?targetRole=Admin"),
      ]);

      const cData = await cRes.json();
      const mData = await mRes.json();
      const oData = await oRes.json();
      const aData = await aRes.json();
      const rData = await rRes.json();
      const repData = await repRes.json();
      const iData = await iRes.json();
      const actData = await actRes.json();
      const nData = await nRes.json();

      if (Array.isArray(cData)) setCustomers(cData);
      if (Array.isArray(mData)) setMachines(mData);
      if (Array.isArray(oData)) setOperators(oData);
      if (Array.isArray(aData)) setAssignments(aData);
      if (Array.isArray(rData)) setRequests(rData);
      if (repData) setReportsData(repData);
      if (Array.isArray(iData)) setInsights(iData);
      if (Array.isArray(actData)) setActivityLogs(actData);
      if (Array.isArray(nData)) setNotifications(nData);
    } catch (err) {
      console.error("Error loading admin data:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleAdminApproveRequest = async (id: string) => {
    try {
      const res = await fetch(`/api/service-requests/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "admin_approve" }),
      });
      if (res.ok) {
        loadAllAdminData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAdminRejectRequest = async (id: string) => {
    try {
      const res = await fetch(`/api/service-requests/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "admin_reject" }),
      });
      if (res.ok) {
        loadAllAdminData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleCustomerStatus = async (cust: Customer) => {
    try {
      const newStatus = cust.status === "Active" ? "Inactive" : "Active";
      await fetch(`/api/customers/${cust.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      loadAllAdminData();
    } catch (err) {
      console.error(err);
    }
  };

  if (loading && !reportsData) {
    return (
      <div className="p-12 flex flex-col items-center justify-center gap-3 text-slate-400">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
        <p className="text-sm font-medium">Loading OEM Manufacturer Control Center...</p>
      </div>
    );
  }

  const COLORS = ["#10B981", "#F59E0B", "#6366F1", "#EF4444"];

  // 1. DASHBOARD VIEW
  if (activeTab === "dashboard") {
    const metrics = reportsData?.metrics || {
      totalCustomers: customers.length,
      totalMachines: machines.length,
      totalOperators: operators.length,
      activeBenefits: operators.filter((o) => o.status === "Active").length,
      openRequests: requests.filter(
        (r) => r.status === "Pending Insurance Approval" || r.status === "Pending Admin Approval"
      ).length,
      totalWallet: customers.reduce((acc, c) => acc + (c.walletBalance || 0), 0),
    };

    const growthChart = reportsData?.operatorGrowthChart || [];
    const statusChart = reportsData?.machineStatusChart || [];

    return (
      <div className="space-y-6">
        {/* Banner */}
        <div className="p-6 bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-500/20 rounded-2xl flex flex-wrap items-center justify-between gap-4 shadow-xl">
          <div>
            <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider">
              <Zap className="w-4 h-4 fill-amber-400" /> Manufacturer Command Console
            </div>
            <h1 className="text-2xl font-black text-slate-100 mt-1">Global OEM Fleet Dashboard</h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Full enterprise visibility across registered client companies, heavy machine allocations, operator credentials, insurance policies, and AI fleet telemetry.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenAddCustomer}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4" /> Add Customer
            </button>
            <button
              onClick={onOpenAddMachine}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs rounded-xl border border-slate-700 transition flex items-center gap-2"
            >
              <Plus className="w-4 h-4 text-amber-400" /> Add Machine
            </button>
          </div>
        </div>

        {/* Spec Metrics Row */}
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Total Customers <Building2 className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-slate-100 mt-2">{metrics.totalCustomers}</div>
            <div className="text-[11px] text-emerald-400 mt-1 font-medium">100% Active Partnerships</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Total Machines <Truck className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-black text-slate-100 mt-2">{metrics.totalMachines}</div>
            <div className="text-[11px] text-slate-400 mt-1">Across 3 categories</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Total Operators <Users className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-black text-slate-100 mt-2">{metrics.totalOperators}</div>
            <div className="text-[11px] text-indigo-400 mt-1 font-medium">Driver Pool Active</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Active Benefits <Shield className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-emerald-400 mt-2">{metrics.activeBenefits}</div>
            <div className="text-[11px] text-slate-400 mt-1">$500k Policy Coverage</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Open Requests <Clock className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-amber-400 mt-2">{metrics.openRequests}</div>
            <div className="text-[11px] text-amber-300 mt-1 font-medium">Needs Insurance / Admin</div>
          </div>

          <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Total Wallet Pool <Wallet className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-xl font-black text-emerald-400 mt-2">
              ${metrics.totalWallet.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Client Loyalty Credits</div>
          </div>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Growth Chart */}
          <div className="lg:col-span-2 p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-100">Workforce & Operator Growth</h3>
                <p className="text-xs text-slate-400">Monthly trend of registered drivers vs active assignments</p>
              </div>
              <TrendingUp className="w-5 h-5 text-amber-400" />
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={growthChart}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} />
                  <YAxis stroke="#94a3b8" fontSize={11} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", color: "#f8fafc" }}
                  />
                  <Bar dataKey="operators" fill="#f59e0b" name="Total Operators" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="activeAssignments" fill="#6366f1" name="Active Machine Allocations" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Machine Status Distribution Chart */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-100">Machine Status Breakdown</h3>
              <p className="text-xs text-slate-400">Current machine status across entire fleet</p>
            </div>
            <div className="h-48 my-2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusChart}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={70}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {statusChart.map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", color: "#f8fafc" }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {statusChart.map((s: any, idx: number) => (
                <div key={s.name} className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                  />
                  <span className="text-slate-300 font-medium">
                    {s.name}: <strong className="text-slate-100">{s.value}</strong>
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recently Added Customers & Assigned Operators */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recently Added Customers */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-amber-400" /> Recently Added Customers
              </h3>
              <span className="text-xs text-slate-400">{customers.length} Total</span>
            </div>
            <div className="space-y-3">
              {customers.slice(-3).reverse().map((c) => (
                <div
                  key={c.id}
                  onClick={() => onSelectCustomer(c.id)}
                  className="p-3 bg-slate-800/50 border border-slate-700/50 rounded-xl flex items-center justify-between hover:bg-slate-800 transition cursor-pointer"
                >
                  <div>
                    <div className="text-sm font-bold text-slate-200">{c.name}</div>
                    <div className="text-xs text-slate-400 font-mono">
                      Code: {c.companyCode} | Category: {c.category}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold text-emerald-400">
                      ${c.walletBalance.toLocaleString()}
                    </div>
                    <span className="text-[10px] text-slate-400">{c.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recently Assigned Operators */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-indigo-400" /> Recently Assigned Operators
              </h3>
              <span className="text-xs text-slate-400">{assignments.length} Total Logs</span>
            </div>
            <div className="space-y-3">
              {assignments.slice(0, 3).map((asgn) => (
                <div
                  key={asgn.id}
                  className="p-3 bg-slate-800/50 border border-slate-700/50 rounded-xl flex items-center justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-500/10 border border-indigo-500/30 rounded-lg text-indigo-400 font-bold text-xs">
                      OPS
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-200">{asgn.operatorName}</div>
                      <div className="text-xs text-slate-400 font-mono">
                        Machine: {asgn.machineModel} ({asgn.machineSerial})
                      </div>
                    </div>
                  </div>
                  <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    {asgn.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Insights & Timeline */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* AI Insights */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <BrainCircuit className="w-5 h-5 text-amber-400" /> AI Insights & Telemetry Alerts
              </h3>
            </div>
            <div className="space-y-3">
              {insights.slice(0, 3).map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 bg-slate-800/40 border border-slate-700/50 rounded-xl space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-300">{item.title}</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                        item.impact === "High"
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                          : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      }`}
                    >
                      {item.impact} Impact
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">{item.description}</p>
                  <div className="text-[11px] text-slate-400 font-medium">
                    💡 <strong className="text-slate-200">Recommendation:</strong> {item.recommendation}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Activity Logs Timeline */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <Clock className="w-5 h-5 text-cyan-400" /> Activity Timeline
              </h3>
            </div>
            <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
              {activityLogs.slice(0, 5).map((log) => (
                <div key={log.id} className="p-3 bg-slate-800/40 border border-slate-700/40 rounded-xl text-xs space-y-1">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="font-semibold text-amber-400">{log.actorRole} ({log.actorName})</span>
                    <span className="font-mono text-[10px]">{new Date(log.createdAt).toLocaleTimeString()}</span>
                  </div>
                  <div className="font-bold text-slate-200">{log.action}</div>
                  <p className="text-slate-300">{log.details}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. CUSTOMERS MANAGEMENT VIEW
  if (activeTab === "customers") {
    const filteredCusts = customers.filter(
      (c) =>
        c.name.toLowerCase().includes(custSearch.toLowerCase()) ||
        c.companyCode.toLowerCase().includes(custSearch.toLowerCase()) ||
        c.email.toLowerCase().includes(custSearch.toLowerCase())
    );

    return (
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Customer Management</h1>
            <p className="text-xs text-slate-400">Add, view, edit, and deactivate customer companies</p>
          </div>
          <button
            onClick={onOpenAddCustomer}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> Add Customer Company
          </button>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search customer by company name, code, or email..."
            value={custSearch}
            onChange={(e) => setCustSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 text-slate-200 rounded-xl text-xs focus:outline-none focus:border-amber-500"
          />
        </div>

        {/* Customer Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCusts.map((cust) => (
            <div
              key={cust.id}
              className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 hover:border-slate-700 transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <h3 className="text-base font-bold text-slate-100">{cust.name}</h3>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                      cust.status === "Active"
                        ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                        : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                    }`}
                  >
                    {cust.status}
                  </span>
                </div>
                <p className="text-xs text-slate-400 font-mono mt-1">Code: {cust.companyCode}</p>
                <div className="mt-3 space-y-1 text-xs text-slate-300">
                  <div>
                    <span className="text-slate-400">Category:</span> {cust.category}
                  </div>
                  <div>
                    <span className="text-slate-400">Email:</span> {cust.email}
                  </div>
                  <div>
                    <span className="text-slate-400">Phone:</span> {cust.phone}
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 space-y-3">
                <div className="grid grid-cols-3 gap-2 text-center text-xs bg-slate-800/40 p-2 rounded-xl">
                  <div>
                    <div className="text-slate-400 text-[10px]">Machines</div>
                    <div className="font-bold text-amber-400">{cust.machineCount || 0}</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-[10px]">Operators</div>
                    <div className="font-bold text-indigo-400">{cust.operatorCount || 0}</div>
                  </div>
                  <div>
                    <div className="text-slate-400 text-[10px]">Wallet</div>
                    <div className="font-bold text-emerald-400">
                      ${cust.walletBalance?.toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectCustomer(cust.id)}
                    className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center justify-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5 text-amber-400" /> View Details
                  </button>
                  <button
                    onClick={() => handleToggleCustomerStatus(cust)}
                    className={`px-3 py-2 text-xs font-bold rounded-xl border transition flex items-center gap-1 ${
                      cust.status === "Active"
                        ? "bg-rose-950/40 text-rose-300 border-rose-800/60 hover:bg-rose-900/60"
                        : "bg-emerald-950/40 text-emerald-300 border-emerald-800/60 hover:bg-emerald-900/60"
                    }`}
                  >
                    {cust.status === "Active" ? <UserX className="w-3.5 h-3.5" /> : <UserCheck className="w-3.5 h-3.5" />}
                    <span>{cust.status === "Active" ? "Deactivate" : "Activate"}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 3. MACHINE MANAGEMENT VIEW
  if (activeTab === "machines") {
    const filteredMachines = machines.filter((m) => {
      const custMatch = !machFilterCust || m.customerId === machFilterCust;
      return custMatch;
    });

    return (
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Machine Management</h1>
            <p className="text-xs text-slate-400">Add, edit, inspect, and track warranty & operator capacity</p>
          </div>
          <button
            onClick={onOpenAddMachine}
            className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition flex items-center gap-2"
          >
            <Plus className="w-4 h-4" /> Add New Machine
          </button>
        </div>

        {/* Filter by Customer */}
        <div className="flex items-center gap-3">
          <Filter className="w-4 h-4 text-slate-400" />
          <select
            value={machFilterCust}
            onChange={(e) => setMachFilterCust(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-xl px-3 py-2 focus:outline-none"
          >
            <option value="">-- All Customer Companies --</option>
            {customers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.companyCode})
              </option>
            ))}
          </select>
        </div>

        {/* Machines Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredMachines.map((m) => (
            <div
              key={m.id}
              className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 hover:border-slate-700 transition"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h3 className="text-base font-bold text-slate-100">{m.modelNumber}</h3>
                  <p className="text-xs text-amber-400 font-mono mt-0.5">SN: {m.serialNumber}</p>
                </div>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {m.status}
                </span>
              </div>

              <div className="text-xs space-y-1.5 text-slate-300 bg-slate-800/40 p-3 rounded-xl border border-slate-800/60">
                <div>
                  <span className="text-slate-400">Owner Customer:</span>{" "}
                  <strong className="text-slate-200">{m.customerName}</strong>
                </div>
                <div>
                  <span className="text-slate-400">Category:</span> {m.category}
                </div>
                <div>
                  <span className="text-slate-400">Warranty Until:</span> {m.warrantyExpiry}
                </div>
              </div>

              {/* Active Operator Allocation Badge */}
              <div className="flex items-center justify-between p-2.5 bg-slate-800/80 rounded-xl text-xs">
                <span className="text-slate-300 font-medium">Active Drivers:</span>
                <span
                  className={`font-bold font-mono px-2 py-0.5 rounded ${
                    (m.activeOperatorCount || 0) >= 3
                      ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                      : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                  }`}
                >
                  {m.activeOperatorCount || 0} / 3 Max
                </span>
              </div>

              <button
                onClick={() => onSelectMachine(m.id)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center justify-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5 text-amber-400" /> Inspect Machine Details
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 4. OPERATOR MANAGEMENT VIEW (Admin Search & View)
  if (activeTab === "operators") {
    let filteredOps = operators;

    if (opCustomerFilter) {
      filteredOps = filteredOps.filter((o) => o.customerId === opCustomerFilter);
    }

    if (opSearch.trim()) {
      const lower = opSearch.toLowerCase().trim();
      filteredOps = filteredOps.filter((o) => {
        const nameMatch = o.name.toLowerCase().includes(lower);
        const mobileMatch = o.mobile.toLowerCase().includes(lower);
        const customerMatch = (o.customerName || "").toLowerCase().includes(lower);
        const machineMatch =
          o.assignedMachine &&
          (o.assignedMachine.modelNumber.toLowerCase().includes(lower) ||
            o.assignedMachine.serialNumber.toLowerCase().includes(lower));
        return nameMatch || mobileMatch || customerMatch || machineMatch;
      });
    }

    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Operator Directory & Inspection</h1>
          <p className="text-xs text-slate-400">
            Search drivers globally by name, mobile, machine, or customer filter.
          </p>
        </div>

        {/* Spec Enforcement Note */}
        <div className="p-4 bg-amber-950/30 border border-amber-800/50 rounded-2xl text-amber-200 text-xs flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
          <div>
            <strong>Business Rule Notice:</strong> Admin cannot directly create operators. Operators are created only by Customer companies.
          </div>
        </div>

        {/* Search Controls */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Search globally by Name, Mobile, Machine */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search globally by Operator Name, Mobile, or Machine..."
              value={opSearch}
              onChange={(e) => setOpSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 text-slate-200 rounded-xl text-xs focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Filter by Customer */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 shrink-0">Filter by Customer:</span>
            <select
              value={opCustomerFilter}
              onChange={(e) => setOpCustomerFilter(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded-xl px-3 py-2.5 focus:outline-none"
            >
              <option value="">-- All Customers --</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Operators List Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredOps.map((op) => (
            <div
              key={op.id}
              className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 hover:border-slate-700 transition"
            >
              <div className="flex items-center gap-3">
                <img
                  src={op.photoUrl}
                  alt={op.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/30"
                />
                <div>
                  <h3 className="text-base font-bold text-slate-100">{op.name}</h3>
                  <p className="text-xs text-slate-400">{op.mobile}</p>
                  <p className="text-[10px] text-amber-400 font-semibold mt-0.5">
                    {op.customerName}
                  </p>
                </div>
              </div>

              <div className="p-3 bg-slate-800/40 border border-slate-700/50 rounded-xl text-xs space-y-1.5 font-mono">
                <div>
                  <span className="text-slate-400 font-sans">Policy Number:</span>{" "}
                  <strong className="text-indigo-300">{op.policyNumber}</strong>
                </div>
                <div>
                  <span className="text-slate-400 font-sans">Coverage:</span>{" "}
                  <span className="text-emerald-400 font-bold">${op.coverageAmount.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-slate-400 font-sans">Assigned Machine:</span>{" "}
                  {op.assignedMachine ? (
                    <span className="text-amber-300 font-bold">{op.assignedMachine.modelNumber}</span>
                  ) : (
                    <span className="text-slate-500 italic">Unassigned</span>
                  )}
                </div>
              </div>

              <button
                onClick={() => onSelectOperator(op)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center justify-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5 text-amber-400" /> View Operator Credentials
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 5. ASSIGNMENTS HISTORY VIEW
  if (activeTab === "assignments") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Operator Assignment Records</h1>
          <p className="text-xs text-slate-400">Complete historical timeline of active and ended driver allocations</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-800/80 text-slate-400 font-semibold uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Operator Name</th>
                  <th className="py-3.5 px-4">Machine Assigned</th>
                  <th className="py-3.5 px-4">Assigned On</th>
                  <th className="py-3.5 px-4">Ended On</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {assignments.map((asgn) => (
                  <tr key={asgn.id} className="hover:bg-slate-800/30 transition">
                    <td className="py-3 px-4 font-bold text-slate-100">{asgn.operatorName}</td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-amber-400">{asgn.machineModel}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{asgn.machineSerial}</div>
                    </td>
                    <td className="py-3 px-4 font-mono">{new Date(asgn.assignedAt).toLocaleDateString()}</td>
                    <td className="py-3 px-4 font-mono">
                      {asgn.endedAt ? new Date(asgn.endedAt).toLocaleDateString() : "Present"}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          asgn.status === "Active"
                            ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                            : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                        }`}
                      >
                        {asgn.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400 text-[11px] max-w-xs truncate">
                      {asgn.notes}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // 6. SERVICE REQUESTS VIEW (Admin Approval)
  if (activeTab === "requests") {
    let filteredReqs = requests;
    if (requestStatusFilter !== "All") {
      filteredReqs = requests.filter((r) => r.status === requestStatusFilter);
    }

    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Service & Replacement Requests</h1>
          <p className="text-xs text-slate-400">
            Approve or reject operator replacement requests after Insurance Coordinator clearance.
          </p>
        </div>

        {/* Status Filter Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          {["All", "Pending Insurance Approval", "Pending Admin Approval", "Approved", "Rejected"].map((st) => (
            <button
              key={st}
              onClick={() => setRequestStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                requestStatusFilter === st
                  ? "bg-amber-500 text-slate-950 font-bold"
                  : "bg-slate-800/60 text-slate-400 hover:text-slate-200"
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        {/* Request List */}
        <div className="space-y-4">
          {filteredReqs.length === 0 ? (
            <div className="p-8 bg-slate-900 border border-slate-800 rounded-2xl text-center text-slate-400 text-xs">
              No requests found for filter "{requestStatusFilter}".
            </div>
          ) : (
            filteredReqs.map((req) => (
              <div
                key={req.id}
                className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 shadow-sm"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-mono font-bold text-amber-400">REQ-{req.id}</span>
                      <span
                        className={`px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                          req.status === "Approved"
                            ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                            : req.status === "Pending Admin Approval"
                            ? "bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse"
                            : req.status === "Pending Insurance Approval"
                            ? "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                            : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                        }`}
                      >
                        {req.status}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-slate-100 mt-1">{req.machineModel}</h3>
                    <p className="text-xs text-slate-400">Company: {req.customerName}</p>
                  </div>

                  {/* Actions if status is Pending Admin Approval */}
                  {req.status === "Pending Admin Approval" && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleAdminApproveRequest(req.id)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4" /> Final Approve
                      </button>
                      <button
                        onClick={() => handleAdminRejectRequest(req.id)}
                        className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5"
                      >
                        <XCircle className="w-4 h-4" /> Reject Request
                      </button>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3 bg-slate-800/40 rounded-xl border border-slate-800 text-xs">
                  <div>
                    <span className="text-slate-400">Old Operator (To Replace):</span>{" "}
                    <strong className="text-rose-300">{req.oldOperator?.name || "Driver"}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">New Proposed Operator:</span>{" "}
                    <strong className="text-emerald-300">
                      {req.newOperator?.name || "TBD / Pending Assignment"}
                    </strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-400">Reason:</span> {req.reason}
                  </div>
                  {req.insuranceNotes && (
                    <div className="col-span-2 text-indigo-300">
                      <strong>Insurance Review Note:</strong> {req.insuranceNotes}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    );
  }

  // 7. BENEFITS OVERVIEW
  if (activeTab === "benefits") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">Master Insurance & Benefits Program</h1>
          <p className="text-xs text-slate-400">OEM Operator Group Health & Equipment Protection policies</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
            <Shield className="w-6 h-6 text-emerald-400" />
            <h3 className="text-sm font-bold text-slate-100">Group Occupational Accident</h3>
            <p className="text-xs text-slate-400">$500,000 maximum payout per driver per incident.</p>
          </div>
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
            <Zap className="w-6 h-6 text-amber-400" />
            <h3 className="text-sm font-bold text-slate-100">OEM Telematics Shield</h3>
            <p className="text-xs text-slate-400">Automated machine liability coverage for operational incidents.</p>
          </div>
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
            <Wallet className="w-6 h-6 text-indigo-400" />
            <h3 className="text-sm font-bold text-slate-100">Customer Loyalty Wallet Bonus</h3>
            <p className="text-xs text-slate-400">5% cashback credits accrued on incident-free machine operations.</p>
          </div>
        </div>
      </div>
    );
  }

  // 8. REPORTS VIEW
  if (activeTab === "reports") {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Fleet Analytics & Reports</h1>
            <p className="text-xs text-slate-400">Comprehensive manufacturer metrics and compliance audit logs</p>
          </div>
          <button
            onClick={() => alert("Report exported to CSV successfully!")}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition"
          >
            Export CSV Audit Report
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-amber-400" /> Executive Summary
            </h3>
            <ul className="text-xs text-slate-300 space-y-2">
              <li>• Total active fleet units: <strong>{machines.length} units</strong></li>
              <li>• Total certified operator drivers: <strong>{operators.length} operators</strong></li>
              <li>• Service turn-around rate: <strong>99.4% on-time approvals</strong></li>
            </ul>
          </div>
        </div>
      </div>
    );
  }

  // 9. AI INSIGHTS VIEW
  if (activeTab === "ai-insights") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
            <BrainCircuit className="w-7 h-7 text-amber-400" /> AI Fleet Telematics & Insights
          </h1>
          <p className="text-xs text-slate-400">
            Real-time machine health predictions, operator capacity advisories, and risk scores
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {insights.map((item) => (
            <div
              key={item.id}
              className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-amber-300">{item.title}</span>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {item.category}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{item.description}</p>
              <div className="p-3 bg-slate-800/60 rounded-xl border border-slate-700/60 text-xs text-slate-200">
                💡 <strong>Actionable Step:</strong> {item.recommendation}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 10. NOTIFICATIONS VIEW
  if (activeTab === "notifications") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">System Notifications</h1>
          <p className="text-xs text-slate-400">Real-time alerts for service requests and operator updates</p>
        </div>

        <div className="space-y-3">
          {notifications.map((n) => (
            <div
              key={n.id}
              className="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between text-xs"
            >
              <div>
                <div className="font-bold text-slate-100">{n.title}</div>
                <div className="text-slate-400 mt-0.5">{n.message}</div>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">
                {new Date(n.createdAt).toLocaleTimeString()}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 11. SETTINGS & PROFILE VIEW
  return (
    <div className="space-y-6">
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
        <h1 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <Settings className="w-5 h-5 text-amber-400" /> OEM System Configuration & HQ Profile
        </h1>
        <p className="text-xs text-slate-400">Global settings and OEM manufacturer parameter control</p>
        <div className="grid grid-cols-2 gap-4 text-xs text-slate-300 pt-3 border-t border-slate-800">
          <div>
            <span className="text-slate-400">Manufacturer Organization:</span> Titan Heavy OEM Global
          </div>
          <div>
            <span className="text-slate-400">Max Active Operators per Unit:</span> 3 Operators Limit
          </div>
          <div>
            <span className="text-slate-400">Standard Coverage Cap:</span> $500,000 Group Accident
          </div>
          <div>
            <span className="text-slate-400">Service Approval Gate:</span> Insurance clearance required before Admin final signoff
          </div>
        </div>
      </div>
    </div>
  );
}
