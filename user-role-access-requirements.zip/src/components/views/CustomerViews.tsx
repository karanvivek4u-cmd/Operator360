"use client";

import { useState, useEffect } from "react";
import { Customer, Machine, Operator, ServiceRequest, NotificationItem } from "@/types";
import {
  Building2,
  Wallet,
  Truck,
  Users,
  Clock,
  Shield,
  Plus,
  RefreshCw,
  Search,
  Eye,
  Edit3,
  UserPlus,
  AlertTriangle,
  CheckCircle2,
  Bell,
  User,
  Zap,
  Loader2,
} from "lucide-react";

interface CustomerViewsProps {
  activeTab: string;
  activeCustomer: Customer | null;
  onOpenAssignModal: (machineId?: string) => void;
  onOpenReplaceModal: (machineId?: string) => void;
  onSelectMachine: (id: string) => void;
  onSelectOperator: (op: Operator) => void;
}

export function CustomerViews({
  activeTab,
  activeCustomer,
  onOpenAssignModal,
  onOpenReplaceModal,
  onSelectMachine,
  onSelectOperator,
}: CustomerViewsProps) {
  const [machines, setMachines] = useState<Machine[]>([]);
  const [operators, setOperators] = useState<Operator[]>([]);
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  const [loading, setLoading] = useState(true);
  const [opSearch, setOpSearch] = useState("");
  const [editingOperator, setEditingOperator] = useState<Operator | null>(null);
  const [editName, setEditName] = useState("");
  const [editMobile, setEditMobile] = useState("");

  useEffect(() => {
    if (activeCustomer) {
      loadCustomerData();
    }
  }, [activeCustomer, activeTab]);

  const loadCustomerData = async () => {
    if (!activeCustomer) return;
    setLoading(true);

    try {
      const [mRes, oRes, rRes, nRes] = await Promise.all([
        fetch(`/api/machines?customerId=${activeCustomer.id}`),
        fetch(`/api/operators?customerId=${activeCustomer.id}`),
        fetch(`/api/service-requests?customerId=${activeCustomer.id}`),
        fetch(`/api/notifications?targetRole=Customer&targetEntityId=${activeCustomer.id}`),
      ]);

      const mData = await mRes.json();
      const oData = await oRes.json();
      const rData = await rRes.json();
      const nData = await nRes.json();

      if (Array.isArray(mData)) setMachines(mData);
      if (Array.isArray(oData)) setOperators(oData);
      if (Array.isArray(rData)) setRequests(rData);
      if (Array.isArray(nData)) setNotifications(nData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveOperatorEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOperator) return;

    try {
      const res = await fetch(`/api/operators/${editingOperator.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: editName, mobile: editMobile }),
      });

      if (res.ok) {
        setEditingOperator(null);
        loadCustomerData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!activeCustomer) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select a Customer Company from the top header switcher.
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-12 flex flex-col items-center justify-center gap-3 text-slate-400">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
        <p className="text-sm font-medium">Loading {activeCustomer.name} portal data...</p>
      </div>
    );
  }

  const pendingRequestsCount = requests.filter(
    (r) => r.status === "Pending Insurance Approval" || r.status === "Pending Admin Approval"
  ).length;

  // 1. DASHBOARD VIEW
  if (activeTab === "dashboard") {
    return (
      <div className="space-y-6">
        {/* Welcome Banner */}
        <div className="p-6 bg-gradient-to-r from-blue-950/50 via-slate-900 to-slate-900 border border-blue-500/30 rounded-2xl flex flex-wrap items-center justify-between gap-4 shadow-xl">
          <div>
            <div className="flex items-center gap-2 text-blue-400 text-xs font-bold uppercase tracking-wider">
              <Building2 className="w-4 h-4" /> Client OEM Fleet Hub
            </div>
            <h1 className="text-2xl font-black text-slate-100 mt-1">{activeCustomer.name}</h1>
            <p className="text-xs text-slate-400 mt-1">
              Category: <span className="text-amber-400 font-semibold">{activeCustomer.category}</span> | Company Code:{" "}
              <span className="font-mono text-slate-200">{activeCustomer.companyCode}</span>
            </p>
          </div>

          {/* Quick Actions per Spec */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onOpenAssignModal()}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl shadow-lg transition flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" /> Assign Operator
            </button>
            <button
              onClick={() => onOpenReplaceModal()}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-lg transition flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" /> Raise Replacement Request
            </button>
          </div>
        </div>

        {/* Dashboard Cards Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Loyalty Wallet Balance <Wallet className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-emerald-400 mt-2">
              ${activeCustomer.walletBalance.toLocaleString()}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">Redeemable against service parts</div>
          </div>

          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Purchased Machines <Truck className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-black text-slate-100 mt-2">{machines.length} Units</div>
            <div className="text-[11px] text-amber-300 mt-1">Active Heavy Equipment</div>
          </div>

          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Registered Operators <Users className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-2xl font-black text-slate-100 mt-2">{operators.length} Drivers</div>
            <div className="text-[11px] text-indigo-400 mt-1">Certified Work Force</div>
          </div>

          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl shadow-sm">
            <div className="text-xs font-medium text-slate-400 flex items-center justify-between">
              Pending Requests <Clock className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-black text-blue-400 mt-2">{pendingRequestsCount} Pending</div>
            <div className="text-[11px] text-slate-400 mt-1">In Insurance / Admin Approval</div>
          </div>
        </div>

        {/* Benefits Summary & Notifications */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Benefits Summary */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-400" /> Corporate Insurance & OEM Benefits
            </h3>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/50 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-200">Driver Group Safety Plan</div>
                  <div className="text-slate-400">$500,000 policy coverage active per operator</div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300">
                  100% Covered
                </span>
              </div>
              <div className="p-3 bg-slate-800/50 rounded-xl border border-slate-700/50 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-200">Equipment Driver Allocation Limit</div>
                  <div className="text-slate-400">Up to 3 active drivers allowed per machine unit</div>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                  Capacity Enforced
                </span>
              </div>
            </div>
          </div>

          {/* Quick Notifications */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Bell className="w-5 h-5 text-amber-400" /> Recent Company Alerts
            </h3>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="text-xs text-slate-500 italic">No unread notifications.</div>
              ) : (
                notifications.slice(0, 3).map((n) => (
                  <div key={n.id} className="p-3 bg-slate-800/40 rounded-xl border border-slate-700/40 text-xs">
                    <div className="font-bold text-slate-200">{n.title}</div>
                    <p className="text-slate-400 mt-0.5">{n.message}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. MACHINES TAB VIEW
  if (activeTab === "machines") {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Purchased Machine Fleet</h1>
            <p className="text-xs text-slate-400">
              Only machines owned by {activeCustomer.name} are visible here
            </p>
          </div>
        </div>

        {/* Machine Cards List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {machines.map((m) => {
            const activeCount = m.activeOperatorCount || 0;
            const isMaxLimit = activeCount >= 3;

            return (
              <div
                key={m.id}
                className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 hover:border-slate-700 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-base font-bold text-slate-100">{m.modelNumber}</h3>
                    <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {m.status}
                    </span>
                  </div>
                  <p className="text-xs text-amber-400 font-mono mt-1">Serial #: {m.serialNumber}</p>
                  <div className="text-xs text-slate-400 mt-2">Category: {m.category}</div>

                  {/* Active Operators Count Badge & Warning per Spec */}
                  <div className="mt-4 p-3 bg-slate-800/60 rounded-xl border border-slate-700/60 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300 font-semibold">Active Operators:</span>
                      <span
                        className={`font-mono font-bold px-2 py-0.5 rounded text-xs ${
                          isMaxLimit
                            ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                            : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                        }`}
                      >
                        {activeCount} / 3 Max
                      </span>
                    </div>

                    {isMaxLimit && (
                      <div className="p-2 bg-rose-950/50 border border-rose-800/60 rounded-lg text-[11px] text-rose-300 flex items-center gap-1.5 font-medium">
                        <AlertTriangle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                        <span>Maximum limit reached: 3 active operators per machine.</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Machine Action Buttons per Spec: View, Assign Operator, Raise Replacement Request */}
                <div className="space-y-2 pt-3 border-t border-slate-800">
                  <button
                    onClick={() => onSelectMachine(m.id)}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center justify-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5 text-amber-400" /> View Machine Info
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => onOpenAssignModal(m.id)}
                      disabled={isMaxLimit}
                      className="py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl shadow transition flex items-center justify-center gap-1 disabled:opacity-50 disabled:cursor-not-allowed"
                      title={isMaxLimit ? "Maximum 3 operators limit reached" : "Assign Operator"}
                    >
                      <UserPlus className="w-3.5 h-3.5" /> Assign
                    </button>

                    <button
                      onClick={() => onOpenReplaceModal(m.id)}
                      className="py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center justify-center gap-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5" /> Replace
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  // 3. OPERATORS TAB VIEW
  if (activeTab === "operators") {
    const filteredOps = operators.filter(
      (op) =>
        op.name.toLowerCase().includes(opSearch.toLowerCase()) ||
        op.mobile.toLowerCase().includes(opSearch.toLowerCase())
    );

    return (
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Registered Workforce Operators</h1>
            <p className="text-xs text-slate-400">
              Manage operators registered under {activeCustomer.name}
            </p>
          </div>
          <button
            onClick={() => onOpenAssignModal()}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Add & Assign Operator
          </button>
        </div>

        {/* Spec Rule Notice */}
        <div className="p-3 bg-indigo-950/40 border border-indigo-800/50 rounded-xl text-indigo-200 text-xs flex items-center gap-2">
          <Shield className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>Note: Operators cannot be deleted. You can edit details or assign/replace them.</span>
        </div>

        {/* Search */}
        <div className="relative max-w-md">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search operators by name or mobile..."
            value={opSearch}
            onChange={(e) => setOpSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 text-slate-200 rounded-xl text-xs focus:outline-none focus:border-amber-500"
          />
        </div>

        {/* Operators List */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredOps.map((op) => (
            <div
              key={op.id}
              className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 hover:border-slate-700 transition"
            >
              <div className="flex items-center gap-3">
                <img
                  src={op.photoUrl}
                  alt={op.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500/30"
                />
                <div>
                  <h3 className="text-base font-bold text-slate-100">{op.name}</h3>
                  <p className="text-xs text-slate-400">{op.mobile}</p>
                  <p className="text-[10px] text-indigo-300 font-mono mt-0.5">
                    Policy: {op.policyNumber}
                  </p>
                </div>
              </div>

              <div className="p-3 bg-slate-800/40 rounded-xl text-xs space-y-1">
                <div className="text-slate-400">
                  Assigned Machine:{" "}
                  {op.assignedMachine ? (
                    <strong className="text-amber-300 font-mono">{op.assignedMachine.modelNumber}</strong>
                  ) : (
                    <span className="text-slate-500 italic">Unassigned</span>
                  )}
                </div>
                <div className="text-slate-400">
                  Coverage: <strong className="text-emerald-400">${op.coverageAmount.toLocaleString()}</strong>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
                <button
                  onClick={() => onSelectOperator(op)}
                  className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center justify-center gap-1"
                >
                  <Eye className="w-3.5 h-3.5 text-amber-400" /> View Benefits
                </button>
                <button
                  onClick={() => {
                    setEditingOperator(op);
                    setEditName(op.name);
                    setEditMobile(op.mobile);
                  }}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition flex items-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5 text-indigo-400" /> Edit
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Operator Edit Modal */}
        {editingOperator && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
              <h3 className="text-lg font-bold">Edit Operator Details</h3>
              <form onSubmit={handleSaveOperatorEdit} className="space-y-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Full Name</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Mobile Phone Number</label>
                  <input
                    type="text"
                    value={editMobile}
                    onChange={(e) => setEditMobile(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-3">
                  <button
                    type="button"
                    onClick={() => setEditingOperator(null)}
                    className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-slate-100"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl"
                  >
                    Save Details
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  // 4. REQUESTS TAB VIEW
  if (activeTab === "requests") {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-100">Replacement Service Requests</h1>
            <p className="text-xs text-slate-400">Track pending Insurance and OEM Admin approvals</p>
          </div>
          <button
            onClick={() => onOpenReplaceModal()}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow transition flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Raise Replacement Request
          </button>
        </div>

        <div className="space-y-3">
          {requests.map((r) => (
            <div key={r.id} className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-amber-400">REQ-{r.id}</span>
                <span
                  className={`px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                    r.status === "Approved"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : r.status === "Pending Insurance Approval"
                      ? "bg-blue-500/20 text-blue-300 border border-blue-500/30"
                      : r.status === "Pending Admin Approval"
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  }`}
                >
                  {r.status}
                </span>
              </div>
              <div className="text-sm font-bold text-slate-100">{r.machineModel}</div>
              <div className="text-xs text-slate-300 bg-slate-800/40 p-3 rounded-xl border border-slate-800 space-y-1">
                <div>
                  Old Operator: <strong className="text-rose-300">{r.oldOperator?.name || "Driver"}</strong>
                </div>
                <div>
                  New Proposed: <strong className="text-emerald-300">{r.newOperator?.name || "Pending Selection"}</strong>
                </div>
                <div>Reason: {r.reason}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 5. BENEFITS, NOTIFICATIONS, PROFILE
  return (
    <div className="space-y-6">
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
        <h1 className="text-xl font-bold text-slate-100">{activeCustomer.name} Profile & Benefits</h1>
        <p className="text-xs text-slate-400">Category: {activeCustomer.category}</p>
        <div className="text-xs text-slate-300 pt-3 border-t border-slate-800 space-y-2">
          <div>Wallet Credits: ${activeCustomer.walletBalance.toLocaleString()}</div>
          <div>Contact Phone: {activeCustomer.phone}</div>
          <div>Address: {activeCustomer.address}</div>
        </div>
      </div>
    </div>
  );
}
