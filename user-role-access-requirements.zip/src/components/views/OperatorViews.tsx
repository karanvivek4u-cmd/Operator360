"use client";

import { useState, useEffect } from "react";
import { Operator, Machine, NotificationItem } from "@/types";
import {
  HardHat,
  Truck,
  Shield,
  FileText,
  Bot,
  Bell,
  User,
  CheckCircle2,
  Send,
  Loader2,
  AlertTriangle,
  Download,
} from "lucide-react";

interface OperatorViewsProps {
  activeTab: string;
  activeOperator: Operator | null;
}

export function OperatorViews({ activeTab, activeOperator }: OperatorViewsProps) {
  const [data, setData] = useState<{
    operator: Operator;
    assignedMachine: Machine | null;
    benefits: any;
  } | null>(null);

  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);

  // AI Assistant chat state
  const [messages, setMessages] = useState<
    { sender: "user" | "ai"; text: string; timestamp: string }[]
  >([
    {
      sender: "ai",
      text: "Hello Driver! I am your AI Equipment Co-Pilot. How can I assist you with your machine specs, field safety protocols, or insurance benefits today?",
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);
  const [inputQuery, setInputQuery] = useState("");

  useEffect(() => {
    if (activeOperator) {
      loadOperatorData();
    }
  }, [activeOperator, activeTab]);

  const loadOperatorData = async () => {
    if (!activeOperator) return;
    setLoading(true);

    try {
      const [oRes, nRes] = await Promise.all([
        fetch(`/api/operators/${activeOperator.id}`),
        fetch(`/api/notifications?targetRole=Operator&targetEntityId=${activeOperator.id}`),
      ]);

      const oData = await oRes.json();
      const nData = await nRes.json();

      if (oRes.ok) setData(oData);
      if (Array.isArray(nData)) setNotifications(nData);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputQuery.trim()) return;

    const userText = inputQuery.trim();
    const now = new Date().toLocaleTimeString();

    const userMsg = { sender: "user" as const, text: userText, timestamp: now };
    setMessages((prev) => [...prev, userMsg]);
    setInputQuery("");

    // Generate response based on query keywords
    setTimeout(() => {
      let aiText = `I analyzed telemetry for ${
        data?.assignedMachine?.modelNumber || "your equipment"
      }. Hydraulics, oil pressure, and safety sensors are operating at nominal 98% efficiency.`;

      const lower = userText.toLowerCase();
      if (lower.includes("benefit") || lower.includes("insurance") || lower.includes("policy")) {
        aiText = `Your policy ${
          data?.operator.policyNumber || "INS-2026"
        } includes $500,000 Group Safety Coverage, 100% medical expense response, and emergency trauma coverage active for 2026.`;
      } else if (lower.includes("manual") || lower.includes("spec") || lower.includes("engine")) {
        aiText = `Machine Specs for ${data?.assignedMachine?.modelNumber || "Unit"}: Bucket Capacity ${
          data?.assignedMachine?.specifications || "Heavy Duty Specs"
        }. Standard daily pre-trip checklist completed.`;
      } else if (lower.includes("safety") || lower.includes("emergency") || lower.includes("incident")) {
        aiText = `Emergency Protocol Triggered: In case of machine fault or field emergency, sound cabin horn 3 times and contact OEM Emergency Line: +1 (800) 555-TITAN immediately.`;
      }

      setMessages((prev) => [...prev, { sender: "ai", text: aiText, timestamp: new Date().toLocaleTimeString() }]);
    }, 600);
  };

  if (!activeOperator) {
    return (
      <div className="p-12 text-center text-slate-400">
        Please select an Operator Driver from the top header switcher.
      </div>
    );
  }

  if (loading || !data) {
    return (
      <div className="p-12 flex flex-col items-center justify-center gap-3 text-slate-400">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
        <p className="text-sm font-medium">Loading driver dashboard and telematics sync...</p>
      </div>
    );
  }

  const op = data.operator;
  const mach = data.assignedMachine;

  // 1. DASHBOARD VIEW
  if (activeTab === "dashboard") {
    return (
      <div className="space-y-6">
        {/* Profile Header Card */}
        <div className="p-6 bg-gradient-to-r from-indigo-950/50 via-slate-900 to-slate-900 border border-indigo-500/30 rounded-2xl shadow-xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={op.photoUrl}
              alt={op.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-500/50 shadow-lg"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-black text-slate-100">{op.name}</h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Certified OEM Driver
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Mobile: <span className="text-slate-200 font-mono">{op.mobile}</span> | Joined:{" "}
                <span className="text-slate-200">{op.joiningDate}</span>
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/80 text-xs space-y-1">
            <div className="text-slate-400">Group Safety Policy:</div>
            <div className="font-mono font-bold text-indigo-300 text-sm">{op.policyNumber}</div>
            <div className="text-emerald-400 font-bold">${op.coverageAmount.toLocaleString()} Active Payout</div>
          </div>
        </div>

        {/* Assigned Machine Specs Card */}
        <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Truck className="w-5 h-5 text-amber-400" /> Assigned Equipment & Operational Controls
            </h3>
            <span className="px-2.5 py-0.5 rounded text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Active Operator License
            </span>
          </div>

          {mach ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-700/50 space-y-2">
                <div className="text-sm font-bold text-slate-100">{mach.modelNumber}</div>
                <div className="text-xs font-mono text-amber-400">Serial #: {mach.serialNumber}</div>
                <div className="text-xs text-slate-300">Category: {mach.category}</div>
                <div className="text-xs text-slate-300">Manufacture Year: {mach.manufactureYear}</div>
              </div>

              <div className="p-4 bg-slate-800/40 rounded-xl border border-slate-700/50 space-y-2">
                <h4 className="text-xs font-semibold uppercase text-slate-400">Telematics Specifications</h4>
                <div className="text-xs text-slate-300 font-mono bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  {typeof mach.specifications === "string"
                    ? mach.specifications
                    : JSON.stringify(mach.specifications)}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-400 text-xs">
              No machine currently assigned to your driver profile. Contact your fleet manager.
            </div>
          )}
        </div>

        {/* Benefits & Policy Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Coverage Summary */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-400" /> Coverage & Benefits Breakdown
            </h3>
            <ul className="space-y-2 text-xs text-slate-300">
              {data.benefits?.coverageItems?.map((item: any, idx: number) => (
                <li
                  key={idx}
                  className="p-3 bg-slate-800/40 rounded-xl border border-slate-700/40 flex items-center justify-between"
                >
                  <span>{item.name}</span>
                  <span className="font-bold text-emerald-400 font-mono">{item.limit}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Documents Tab Preview */}
          <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-400" /> Driver Documents & Certificates
            </h3>
            <div className="space-y-2 text-xs">
              <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-700/40 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-200">Insurance Certificate Policy PDF</div>
                  <div className="text-slate-400 font-mono">Policy: {op.policyNumber}.pdf</div>
                </div>
                <button
                  onClick={() => alert("Downloading Insurance Certificate PDF...")}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-lg border border-slate-700"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
              <div className="p-3 bg-slate-800/40 rounded-xl border border-slate-700/40 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-200">Heavy OEM Driver Certification</div>
                  <div className="text-slate-400">Expires 2027-12-31</div>
                </div>
                <button
                  onClick={() => alert("Downloading Heavy OEM Driver Certificate...")}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-lg border border-slate-700"
                >
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. AI ASSISTANT VIEW
  if (activeTab === "ai-assistant") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
            <Bot className="w-7 h-7 text-amber-400" /> Field AI Co-Pilot & Safety Guide
          </h1>
          <p className="text-xs text-slate-400">
            Ask questions about machine specifications, safety emergency procedures, or insurance benefits
          </p>
        </div>

        {/* Chat window */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl h-[480px] flex flex-col overflow-hidden shadow-xl">
          {/* Chat Messages scroll area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex gap-3 max-w-[85%] ${
                  m.sender === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${
                    m.sender === "user"
                      ? "bg-indigo-600 text-white"
                      : "bg-amber-500 text-slate-950 font-black"
                  }`}
                >
                  {m.sender === "user" ? "YOU" : "AI"}
                </div>
                <div
                  className={`p-3.5 rounded-2xl text-xs space-y-1 ${
                    m.sender === "user"
                      ? "bg-indigo-600 text-white rounded-tr-none"
                      : "bg-slate-800 border border-slate-700 text-slate-200 rounded-tl-none"
                  }`}
                >
                  <p className="leading-relaxed">{m.text}</p>
                  <span className="text-[9px] opacity-60 block text-right font-mono">
                    {m.timestamp}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Form bar */}
          <form
            onSubmit={handleSendChatMessage}
            className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2"
          >
            <input
              type="text"
              placeholder="Ask AI co-pilot about machine specs, oil pressures, or insurance coverage..."
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 text-slate-100 text-xs rounded-xl px-4 py-2.5 focus:outline-none focus:border-amber-500"
            />
            <button
              type="submit"
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition flex items-center gap-1"
            >
              <Send className="w-4 h-4" /> Send
            </button>
          </form>
        </div>
      </div>
    );
  }

  // 3. BENEFITS, NOTIFICATIONS, PROFILE
  return (
    <div className="space-y-6">
      <div className="p-6 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
        <h1 className="text-xl font-bold text-slate-100">{op.name} Driver Profile</h1>
        <p className="text-xs text-slate-400">Policy Number: {op.policyNumber}</p>
        <div className="text-xs text-slate-300 pt-3 border-t border-slate-800 space-y-1">
          <div>Mobile Phone: {op.mobile}</div>
          <div>Joining Date: {op.joiningDate}</div>
          <div>Assigned Machine: {mach?.modelNumber || "None"}</div>
        </div>
      </div>
    </div>
  );
}
