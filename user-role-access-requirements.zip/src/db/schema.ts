import { pgTable, text, integer, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";

export const customers = pgTable("customers", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  companyCode: text("company_code").notNull(),
  category: text("category").notNull().default("Gold OEM Client"), // e.g. Gold OEM Client, Platinum Fleet Partner
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  walletBalance: integer("wallet_balance").notNull().default(25000), // Loyalty wallet balance
  status: text("status").notNull().default("Active"), // Active, Inactive
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const machines = pgTable("machines", {
  id: text("id").primaryKey(),
  serialNumber: text("serial_number").notNull(),
  modelNumber: text("model_number").notNull(),
  category: text("category").notNull(),
  customerId: text("customer_id").notNull().references(() => customers.id),
  status: text("status").notNull().default("Active"), // Active, Maintenance, Idle, Decommissioned
  warrantyExpiry: text("warranty_expiry").notNull(),
  manufactureYear: integer("manufacture_year").notNull(),
  specifications: text("specifications").notNull(), // JSON string or descriptive string
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const operators = pgTable("operators", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  mobile: text("mobile").notNull(),
  email: text("email").notNull(),
  photoUrl: text("photo_url").notNull(),
  customerId: text("customer_id").notNull().references(() => customers.id),
  joiningDate: text("joining_date").notNull(),
  status: text("status").notNull().default("Active"), // Active, Suspended, On Leave
  policyNumber: text("policy_number").notNull(),
  coverageAmount: integer("coverage_amount").notNull().default(500000),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const assignments = pgTable("assignments", {
  id: text("id").primaryKey(),
  machineId: text("machine_id").notNull().references(() => machines.id),
  operatorId: text("operator_id").notNull().references(() => operators.id),
  assignedAt: timestamp("assigned_at").defaultNow().notNull(),
  endedAt: timestamp("ended_at"),
  status: text("status").notNull().default("Active"), // Active, Replaced, Ended
  notes: text("notes"),
});

export const serviceRequests = pgTable("service_requests", {
  id: text("id").primaryKey(),
  customerId: text("customer_id").notNull().references(() => customers.id),
  machineId: text("machine_id").notNull().references(() => machines.id),
  oldOperatorId: text("old_operator_id").notNull().references(() => operators.id),
  newOperatorId: text("new_operator_id"), // Optional at request time, or chosen when raising
  reason: text("reason").notNull(),
  remarks: text("remarks"),
  status: text("status").notNull().default("Pending Insurance Approval"), // Pending Insurance Approval, Pending Admin Approval, Approved, Rejected
  insuranceReviewedAt: timestamp("insurance_reviewed_at"),
  insuranceNotes: text("insurance_notes"),
  adminReviewedAt: timestamp("admin_reviewed_at"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: text("id").primaryKey(),
  targetRole: text("target_role").notNull(), // Admin, Customer, Insurance, Operator
  targetEntityId: text("target_entity_id"), // customerId or operatorId if applicable
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"), // info, warning, success, alert
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const activityLogs = pgTable("activity_logs", {
  id: text("id").primaryKey(),
  actorRole: text("actor_role").notNull(),
  actorName: text("actor_name").notNull(),
  action: text("action").notNull(),
  details: text("details").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const aiInsights = pgTable("ai_insights", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull(), // Maintenance, Risk, Efficiency, Warranty
  description: text("description").notNull(),
  recommendation: text("recommendation").notNull(),
  impact: text("impact").notNull().default("High"), // High, Medium, Low
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
