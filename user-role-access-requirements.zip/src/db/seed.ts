import { db } from "./index";
import {
  customers,
  machines,
  operators,
  assignments,
  serviceRequests,
  notifications,
  activityLogs,
  aiInsights,
} from "./schema";
import { count } from "drizzle-orm";

export async function seedDatabase() {
  try {
    const existingCustomers = await db.select({ value: count() }).from(customers);
    if (existingCustomers[0]?.value > 0) {
      console.log("Database already seeded.");
      return;
    }

    console.log("Seeding database with demo data...");

    // Seed Customers
    await db.insert(customers).values([
      {
        id: "cust_1",
        name: "Apex Infrastructure Ltd",
        companyCode: "APX-2024",
        category: "Platinum Fleet Partner",
        email: "contact@apexinfra.com",
        phone: "+1 (555) 234-5678",
        address: "100 Industrial Parkway, Chicago IL",
        walletBalance: 85000,
        status: "Active",
      },
      {
        id: "cust_2",
        name: "Titan Heavy Construction",
        companyCode: "TTN-1092",
        category: "Gold OEM Client",
        email: "ops@titanheavy.com",
        phone: "+1 (555) 876-5432",
        address: "45 Harbor Drive, Houston TX",
        walletBalance: 42500,
        status: "Active",
      },
      {
        id: "cust_3",
        name: "Aegis Mining Operations",
        companyCode: "AGS-9911",
        category: "Gold OEM Client",
        email: "fleets@aegismining.com",
        phone: "+1 (555) 345-6789",
        address: "88 Quarry Road, Denver CO",
        walletBalance: 31000,
        status: "Active",
      },
    ]);

    // Seed Machines
    await db.insert(machines).values([
      {
        id: "mach_1",
        serialNumber: "CAT-994K-8812",
        modelNumber: "Caterpillar 994K Wheel Loader",
        category: "Heavy Earthmoving",
        customerId: "cust_1",
        status: "Active",
        warrantyExpiry: "2027-11-30",
        manufactureYear: 2023,
        specifications: JSON.stringify({
          bucketCapacity: "17.4-24.7 m³",
          enginePower: "1739 HP CAT 3516E",
          operatingWeight: "242,600 kg",
          payloadLimit: "45.0 Ton",
        }),
      },
      {
        id: "mach_2",
        serialNumber: "KOM-PC1250-401",
        modelNumber: "Komatsu PC1250SP-11 Heavy Excavator",
        category: "Mining Excavator",
        customerId: "cust_1",
        status: "Active",
        warrantyExpiry: "2026-08-15",
        manufactureYear: 2022,
        specifications: JSON.stringify({
          bucketCapacity: "6.7 m³",
          enginePower: "775 HP Komatsu SAA6D170E-7",
          operatingWeight: "118,000 kg",
          diggingDepth: "8.7 m",
        }),
      },
      {
        id: "mach_3",
        serialNumber: "LIE-LTM1300-09",
        modelNumber: "Liebherr LTM 1300-6.2 Mobile Crane",
        category: "Lifting Crane",
        customerId: "cust_1",
        status: "Active",
        warrantyExpiry: "2028-03-20",
        manufactureYear: 2024,
        specifications: JSON.stringify({
          maxLiftCapacity: "300 Ton",
          boomLength: "78 m Telescopic Boom",
          enginePower: "612 HP Liebherr 8-Cyl Diesel",
        }),
      },
      {
        id: "mach_4",
        serialNumber: "CAT-797F-9921",
        modelNumber: "Caterpillar 797F Ultra Haul Truck",
        category: "Haulage Truck",
        customerId: "cust_1",
        status: "Maintenance",
        warrantyExpiry: "2026-05-10",
        manufactureYear: 2022,
        specifications: JSON.stringify({
          payloadCapacity: "400 Ton",
          enginePower: "4000 HP C175-20",
          topSpeed: "67.6 km/h",
        }),
      },
      {
        id: "mach_5",
        serialNumber: "VOL-A60H-3321",
        modelNumber: "Volvo A60H Articulated Hauler",
        category: "Articulated Dump Truck",
        customerId: "cust_2",
        status: "Active",
        warrantyExpiry: "2027-01-15",
        manufactureYear: 2023,
        specifications: JSON.stringify({
          payloadCapacity: "55 Ton",
          enginePower: "639 HP Volvo D16J",
          bodyVolume: "33.6 m³",
        }),
      },
      {
        id: "mach_6",
        serialNumber: "CAT-D11-5510",
        modelNumber: "Caterpillar D11 Heavy Dozer",
        category: "Earthmoving Dozer",
        customerId: "cust_2",
        status: "Active",
        warrantyExpiry: "2026-09-30",
        manufactureYear: 2022,
        specifications: JSON.stringify({
          bladeCapacity: "27.2 m³",
          enginePower: "850 HP C32 ACERT",
          operatingWeight: "104,236 kg",
        }),
      },
      {
        id: "mach_7",
        serialNumber: "HIT-EX3600-112",
        modelNumber: "Hitachi EX3600-7 Mining Shovel",
        category: "Mining Excavator",
        customerId: "cust_3",
        status: "Active",
        warrantyExpiry: "2028-06-01",
        manufactureYear: 2024,
        specifications: JSON.stringify({
          bucketCapacity: "22 m³",
          enginePower: "1920 HP Cummins QSK50-C",
          operatingWeight: "362,000 kg",
        }),
      },
    ]);

    // Seed Operators
    await db.insert(operators).values([
      {
        id: "op_1",
        name: "Marcus Vance",
        mobile: "+1 (555) 101-2020",
        email: "marcus.vance@apexinfra.com",
        photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300",
        customerId: "cust_1",
        joiningDate: "2021-04-12",
        status: "Active",
        policyNumber: "INS-2026-X892",
        coverageAmount: 500000,
      },
      {
        id: "op_2",
        name: "Elena Rostova",
        mobile: "+1 (555) 303-4040",
        email: "elena.r@apexinfra.com",
        photoUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300",
        customerId: "cust_1",
        joiningDate: "2022-09-01",
        status: "Active",
        policyNumber: "INS-2026-X893",
        coverageAmount: 500000,
      },
      {
        id: "op_3",
        name: "Devon Cole",
        mobile: "+1 (555) 505-6060",
        email: "devon.cole@apexinfra.com",
        photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300",
        customerId: "cust_1",
        joiningDate: "2023-01-15",
        status: "Active",
        policyNumber: "INS-2026-X894",
        coverageAmount: 500000,
      },
      {
        id: "op_4",
        name: "Sarah Jenkins",
        mobile: "+1 (555) 707-8080",
        email: "sarah.j@apexinfra.com",
        photoUrl: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300",
        customerId: "cust_1",
        joiningDate: "2023-08-20",
        status: "Active",
        policyNumber: "INS-2026-X895",
        coverageAmount: 500000,
      },
      {
        id: "op_5",
        name: "Carlos Mendez",
        mobile: "+1 (555) 909-1010",
        email: "carlos.m@apexinfra.com",
        photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300",
        customerId: "cust_1",
        joiningDate: "2024-02-10",
        status: "Active",
        policyNumber: "INS-2026-X896",
        coverageAmount: 500000,
      },
      {
        id: "op_6",
        name: "Tariq Al-Mansoor",
        mobile: "+1 (555) 212-3131",
        email: "tariq@titanheavy.com",
        photoUrl: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=300",
        customerId: "cust_2",
        joiningDate: "2022-03-10",
        status: "Active",
        policyNumber: "INS-2026-T101",
        coverageAmount: 500000,
      },
      {
        id: "op_7",
        name: "Jessica Liang",
        mobile: "+1 (555) 414-5151",
        email: "jessica@titanheavy.com",
        photoUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300",
        customerId: "cust_2",
        joiningDate: "2023-05-18",
        status: "Active",
        policyNumber: "INS-2026-T102",
        coverageAmount: 500000,
      },
      {
        id: "op_8",
        name: "David O'Connor",
        mobile: "+1 (555) 616-7171",
        email: "doconnor@aegismining.com",
        photoUrl: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300",
        customerId: "cust_3",
        joiningDate: "2021-11-05",
        status: "Active",
        policyNumber: "INS-2026-A301",
        coverageAmount: 500000,
      },
    ]);

    // Seed Active & Historical Assignments
    await db.insert(assignments).values([
      // Machine 1 has 3 active operators (Max Limit reached!)
      {
        id: "asgn_1",
        machineId: "mach_1",
        operatorId: "op_1",
        assignedAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
        status: "Active",
        notes: "Primary Lead Operator - Shift A",
      },
      {
        id: "asgn_2",
        machineId: "mach_1",
        operatorId: "op_2",
        assignedAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
        status: "Active",
        notes: "Secondary Operator - Shift B (Pending replacement request)",
      },
      {
        id: "asgn_3",
        machineId: "mach_1",
        operatorId: "op_3",
        assignedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        status: "Active",
        notes: "Night Shift Specialist - Shift C",
      },
      // Machine 2 has 1 active operator
      {
        id: "asgn_4",
        machineId: "mach_2",
        operatorId: "op_4",
        assignedAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000),
        status: "Active",
        notes: "Assigned for quarry expansion project",
      },
      // Machine 3 has 1 active operator
      {
        id: "asgn_5",
        machineId: "mach_3",
        operatorId: "op_5",
        assignedAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000),
        status: "Active",
        notes: "Mobile crane specialist assigned",
      },
      // Titan Heavy Assignments
      {
        id: "asgn_6",
        machineId: "mach_5",
        operatorId: "op_6",
        assignedAt: new Date(Date.now() - 120 * 24 * 60 * 60 * 1000),
        status: "Active",
        notes: "Volvo Articulated Hauler Senior Driver",
      },
      {
        id: "asgn_7",
        machineId: "mach_6",
        operatorId: "op_7",
        assignedAt: new Date(Date.now() - 80 * 24 * 60 * 60 * 1000),
        status: "Active",
        notes: "Heavy Dozer Earthmoving Lead",
      },
      // Aegis Mining Assignment
      {
        id: "asgn_8",
        machineId: "mach_7",
        operatorId: "op_8",
        assignedAt: new Date(Date.now() - 200 * 24 * 60 * 60 * 1000),
        status: "Active",
        notes: "Hitachi Excavator Chief Shovel Pilot",
      },
      // Historical ended assignment
      {
        id: "asgn_9_old",
        machineId: "mach_1",
        operatorId: "op_4",
        assignedAt: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000),
        endedAt: new Date(Date.now() - 95 * 24 * 60 * 60 * 1000),
        status: "Replaced",
        notes: "Replaced and transferred to Machine PC1250",
      },
    ]);

    // Seed Service Requests (Replacement Requests)
    await db.insert(serviceRequests).values([
      {
        id: "req_101",
        customerId: "cust_1",
        machineId: "mach_1",
        oldOperatorId: "op_2", // Elena Rostova
        newOperatorId: "op_5", // Carlos Mendez
        reason: "Medical Shift Transfer & Health Leave",
        remarks: "Operator requested medical leave; proposing Carlos Mendez as interim lead operator.",
        status: "Pending Insurance Approval",
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        id: "req_102",
        customerId: "cust_1",
        machineId: "mach_2",
        oldOperatorId: "op_4", // Sarah Jenkins
        newOperatorId: "op_3", // Devon Cole
        reason: "Quarry Relocation & Equipment Swap",
        remarks: "Insurance verified eligibility on 2026-03-28. Awaiting OEM Admin confirmation.",
        status: "Pending Admin Approval",
        insuranceReviewedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
        insuranceNotes: "Verified operator compliance & background safety index 98/100. Approved for replacement.",
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      },
      {
        id: "req_103",
        customerId: "cust_2",
        machineId: "mach_5",
        oldOperatorId: "op_6",
        newOperatorId: "op_7",
        reason: "Certification Upgrade & Site Rotation",
        remarks: "Smooth transition completed.",
        status: "Approved",
        insuranceReviewedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        insuranceNotes: "Policy risk index low. Approved.",
        adminReviewedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
        adminNotes: "OEM replacement approved and dispatched.",
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      },
    ]);

    // Seed Notifications
    await db.insert(notifications).values([
      {
        id: "notif_1",
        targetRole: "Admin",
        title: "Replacement Request Pending Review",
        message: "Service request REQ-102 for CAT Excavator requires your final OEM authorization.",
        type: "warning",
        isRead: false,
      },
      {
        id: "notif_2",
        targetRole: "Insurance",
        title: "New Insurance Clearance Request",
        message: "Apex Infrastructure Ltd submitted operator replacement request REQ-101 for CAT-994K-8812.",
        type: "alert",
        isRead: false,
      },
      {
        id: "notif_3",
        targetRole: "Customer",
        targetEntityId: "cust_1",
        title: "Operator Capacity Warning",
        message: "Machine CAT-994K-8812 has reached the 3-operator maximum limit. Operator assignment disabled.",
        type: "info",
        isRead: false,
      },
      {
        id: "notif_4",
        targetRole: "Operator",
        targetEntityId: "op_1",
        title: "Insurance Benefits Upgraded",
        message: "Your $500,000 Group Health & Equipment Protection Policy renewal active for 2026.",
        type: "success",
        isRead: false,
      },
    ]);

    // Seed AI Insights
    await db.insert(aiInsights).values([
      {
        id: "ai_1",
        title: "Operator Utilization Limit Reached",
        category: "Operator Risk",
        description: "CAT 994K Wheel Loader has reached max active capacity (3/3 operators). Operating at high duty cycles.",
        recommendation: "Review driver shift rotations and monitor hydraulic temperatures to prevent downtime.",
        impact: "High",
      },
      {
        id: "ai_2",
        title: "Predictive Hydraulic Filter Maintenance",
        category: "Maintenance",
        description: "Telematics telemetry on Komatsu PC1250 detects oil pressure variance under heavy load.",
        recommendation: "Schedule preventive oil filter flush during upcoming off-shift window.",
        impact: "Medium",
      },
      {
        id: "ai_3",
        title: "Fleet Insurance Claim Rating Exceptional",
        category: "Warranty",
        description: "Zero incident claims reported across all active operators in Q1 2026.",
        recommendation: "Apex Infrastructure is eligible for a 5% loyalty wallet bonus next billing period.",
        impact: "Low",
      },
    ]);

    // Seed Activity Logs
    await db.insert(activityLogs).values([
      {
        id: "act_1",
        actorRole: "Customer",
        actorName: "Apex Infrastructure Ltd",
        action: "Submitted Replacement Request",
        details: "Requested replacement for operator Elena Rostova on CAT 994K Wheel Loader.",
      },
      {
        id: "act_2",
        actorRole: "Insurance Coordinator",
        actorName: "Insurance Policy Desk",
        action: "Insurance Cleared Request REQ-102",
        details: "Passed risk assessment for Sarah Jenkins -> Devon Cole transition.",
      },
      {
        id: "act_3",
        actorRole: "Admin",
        actorName: "OEM Global Admin",
        action: "Added Machine Liebherr LTM 1300",
        details: "Registered new serial LIE-LTM1300-09 to Apex Infrastructure Ltd.",
      },
      {
        id: "act_4",
        actorRole: "Customer",
        actorName: "Apex Infrastructure Ltd",
        action: "Created Operator",
        details: "Added Carlos Mendez to active operator workforce.",
      },
    ]);

    console.log("Database seeded successfully!");
  } catch (err) {
    console.error("Database seed error:", err);
  }
}
